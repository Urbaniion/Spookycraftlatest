import json, random, os, sys
sys.path.insert(0, "/home/claude/gen")
from nbtlib_min import dumps, loads, Byte

DATA = "/home/claude/SpookyCraft/src/main/resources/data/spookycraft/"
DATA_VERSION = 3465   # Minecraft 1.20.1
HOUSE_LOOT = "spookycraft:chests/halloween_house"
STRUCT_LOOT = "spookycraft:chests/halloween_structure"

def mc(n): return n if ":" in n else "minecraft:" + n

SOLID_HINTS = ("planks","stem","bricks","blackstone","stone","cobble","deepslate","log","wood","hay_block",
               "pumpkin","bookshelf","concrete","terracotta","wool","dirt","soul_soil","podzol","nether_brick","brick")
NOT_SOLID = ("stairs","slab","fence","door","lantern","candle","carpet","button","torch","ladder","bed","cobweb","pane","_wall","air","jigsaw","skull","bars","chest")

def is_solid(name):
    n = name.replace("minecraft:","")
    if any(h in n for h in NOT_SOLID): return False
    return any(h in n for h in SOLID_HINTS)

class T:
    def __init__(self, sx, sy, sz, air=True):
        self.size = (sx, sy, sz); self.air = air
        self.b = {}; self.entities = []
    def set(self, x, y, z, name, **p):
        assert 0 <= x < self.size[0] and 0 <= y < self.size[1] and 0 <= z < self.size[2], (x,y,z,name,self.size)
        self.b[(x,y,z)] = [mc(name), {k:str(v) for k,v in p.items()}, None]
    def get(self, x,y,z): return self.b.get((x,y,z))
    def fill(self, x1,y1,z1,x2,y2,z2, name, **p):
        for x in range(min(x1,x2), max(x1,x2)+1):
            for y in range(min(y1,y2), max(y1,y2)+1):
                for z in range(min(z1,z2), max(z1,z2)+1):
                    self.set(x,y,z,name,**p)
    def jigsaw(self, x,y,z, orientation, name, target, pool, final, joint="rollable"):
        self.b[(x,y,z)] = ["minecraft:jigsaw", {"orientation": orientation},
            {"id":"minecraft:jigsaw","name":name,"target":target,"pool":pool,"final_state":final,"joint":joint}]
    def chest(self, x,y,z, facing, loot=HOUSE_LOOT):
        self.b[(x,y,z)] = ["minecraft:chest", {"facing":facing,"type":"single","waterlogged":"false"},
            {"id":"minecraft:chest","LootTable":loot}]
    def villager(self, x, y, z):
        self.entities.append({"pos":[x+0.5, float(y), z+0.5], "blockPos":[x,y,z],
            "nbt":{"id":"spookycraft:trick_or_treat_villager","PersistenceRequired":Byte(1)}})
    def _connect(self):
        for (x,y,z),(name,props,nbt) in list(self.b.items()):
            n = name.replace("minecraft:","")
            is_fence = n.endswith("_fence"); is_pane = n.endswith("_pane") or n == "iron_bars"
            if not (is_fence or is_pane): continue
            for key,(dx,dz) in {"north":(0,-1),"south":(0,1),"west":(-1,0),"east":(1,0)}.items():
                o = self.b.get((x+dx,y,z+dz))
                if not o: continue
                on = o[0].replace("minecraft:","")
                ok = (on == n) or is_solid(o[0]) if is_fence else (on.endswith("_pane") or on == "iron_bars" or is_solid(o[0]))
                if ok: props[key] = "true"
    def save(self, path):
        self._connect()
        sx,sy,sz = self.size
        cells = dict(self.b)
        if self.air:
            for x in range(sx):
                for y in range(sy):
                    for z in range(sz):
                        if (x,y,z) not in cells: cells[(x,y,z)] = ["minecraft:air", {}, None]
        palette, index, blocks = [], {}, []
        for (x,y,z),(name,props,nbt) in sorted(cells.items(), key=lambda kv:(kv[0][1],kv[0][0],kv[0][2])):
            key = (name, tuple(sorted(props.items())))
            if key not in index:
                index[key] = len(palette)
                e = {"Name": name}
                if props: e["Properties"] = dict(props)
                palette.append(e)
            blk = {"state": index[key], "pos":[x,y,z]}
            if nbt: blk["nbt"] = nbt
            blocks.append(blk)
        root = {"size":[sx,sy,sz], "entities": self.entities, "blocks": blocks, "palette": palette, "DataVersion": DATA_VERSION}
        os.makedirs(os.path.dirname(path), exist_ok=True)
        open(path,"wb").write(dumps(root))
        return len(blocks), len(palette)

STREET = ("minecraft:street","minecraft:street","spookycraft:town/streets")
ENTR = "minecraft:building_entrance"

def stairs(t,x,y,z,name,facing,half="bottom"):
    t.set(x,y,z,name,facing=facing,half=half,shape="straight",waterlogged="false")

def slab(t,x,y,z,name,typ="bottom"):
    t.set(x,y,z,name,type=typ,waterlogged="false")

def lantern(t,x,y,z,hanging=False,soul=False):
    t.set(x,y,z,"soul_lantern" if soul else "lantern",hanging=str(hanging).lower(),waterlogged="false")

def candle(t,x,y,z,n=3):
    t.set(x,y,z,"candle",candles=str(n),lit="true",waterlogged="false")

def gable_roof(t, xa, xb, za, zb, ybase, stair, slab_name, wall, gx):
    """ridge along x, slopes along z (z extent must be an odd number of cells). returns ridge height offset"""
    n = zb - za + 1; mid = (n-1)//2
    for i in range(n):
        z = za + i; k = min(i, n-1-i)
        for x in range(xa, xb+1):
            if k < mid: stairs(t,x,ybase+k,z,stair,"south" if i < mid else "north")
            else: slab(t,x,ybase+mid,z,slab_name)
        if k >= 2:
            for g in gx:
                for y in range(ybase+1, ybase+k): t.set(g,y,z,wall)
    return mid

def pyramid_roof(t, x0, x1, z0, z1, y, stair, top_block, cap=None):
    """stepped pointed roof over a square footprint x0..x1 / z0..z1, starting at height y"""
    k = 0
    while x1 - x0 >= 2 and z1 - z0 >= 2:
        for x in range(x0, x1+1):
            for z in range(z0, z1+1):
                edge = x in (x0,x1) or z in (z0,z1)
                if edge:
                    if z == z0: f = "south"
                    elif z == z1: f = "north"
                    elif x == x0: f = "east"
                    else: f = "west"
                    stairs(t,x,y+k,z,stair,f)
                else:
                    t.set(x,y+k,z,top_block)
        x0 += 1; x1 -= 1; z0 += 1; z1 -= 1; k += 1
    # remaining 1 or 2 cells wide centre
    for x in range(x0, x1+1):
        for z in range(z0, z1+1):
            t.set(x,y+k,z,top_block)
    if cap: t.set((x0+x1)//2, y+k+1, (z0+z1)//2, cap[0], **cap[1])
    return y+k

def house(W, D, H, wall, corner, beam, roof, roof_slab, plinth, bed, villagers,
          floors=1, door="crimson_door", pillars=False, cobwebs=True, extra=None, seed=1, jig=True,
          chest=True, loot=HOUSE_LOOT):
    rnd = random.Random(seed)
    bx, bz = 1, 1
    fz = bz + D - 1
    SX, SZ = W + 2, D + 4
    n = D + 2; mid = (n - 1) // 2
    SY = H + mid + 2
    t = T(SX, SY, SZ)
    cx = bx + W // 2
    for x in range(SX):
        for z in range(SZ):
            t.set(x,0,z,"podzol" if rnd.random()<0.7 else "coarse_dirt")
    for x in range(bx, bx+W):
        for z in range(bz, bz+D):
            edge = x in (bx, bx+W-1) or z in (bz, fz)
            t.set(x,0,z, plinth if edge else "dark_oak_planks")
    t.set(cx,0,fz+1,"dirt_path"); t.set(cx,0,SZ-1,"dirt_path")
    for y in range(1, H+1):
        for x in range(bx, bx+W):
            for z in range(bz, bz+D):
                if x in (bx, bx+W-1) or z in (bz, fz):
                    t.set(x,y,z, plinth if y == 1 else wall)
    for (x,z) in [(bx,bz),(bx+W-1,bz),(bx,fz),(bx+W-1,fz)]:
        for y in range(1,H+1): t.set(x,y,z,corner,axis="y")
    if pillars:
        for x in range(bx+3, bx+W-3, 4):
            for y in range(2,H+1):
                t.set(x,y,bz,corner,axis="y"); t.set(x,y,fz,corner,axis="y")
    for y in [H] + ([H//2] if floors==2 else []):
        for x in range(bx+1, bx+W-1):
            t.set(x,y,bz,beam,axis="x"); t.set(x,y,fz,beam,axis="x")
        for z in range(bz+1, fz):
            t.set(bx,y,z,beam,axis="z"); t.set(bx+W-1,y,z,beam,axis="z")
    for y in [H] + ([H//2] if floors==2 else []):
        for x in range(bx+1,bx+W-1):
            for z in range(bz+1,fz):
                t.set(x,y,z,"dark_oak_planks")
    for half,y in (("lower",1),("upper",2)):
        t.set(cx,y,fz,door,facing="north",half=half,hinge="left",open="false",powered="false")
    t.set(cx+1,2,fz+1,"spookycraft:doorbell",facing="south")
    wy = [3] if floors==1 else [3,H-1]
    glass = "purple_stained_glass_pane"
    for y in wy:
        zc = bz + D//2
        for z in {zc, bz+2, fz-2}:
            if bz < z < fz: t.set(bx,y,z,glass); t.set(bx+W-1,y,z,glass)
        t.set(cx,y,bz,glass)
        if W >= 7 and y > 2:
            for x in (cx-2, cx+2):
                if bx < x < bx+W-1: t.set(x,y,fz,glass)
    gable_roof(t, bx-1, bx+W, bz-1, fz+1, H, roof, roof_slab, wall, (bx, bx+W-1))
    if floors == 2:
        lx, lz = bx+1, bz+1
        t.set(lx, H//2, lz, "air")
        for y in range(1, H//2+2):
            t.set(lx,y,lz,"ladder",facing="south",waterlogged="false")
    f1 = 1
    if floors == 1:
        t.set(bx+1,f1,bz+2,bed,facing="north",occupied="false",part="foot")
        t.set(bx+1,f1,bz+1,bed,facing="north",occupied="false",part="head")
        t.set(bx+W-2,f1,bz+1,"cauldron")
        t.set(bx+W-3,f1,bz+1,"brewing_stand")
        t.set(cx,f1,bz+1,"bookshelf"); t.set(cx,f1+1,bz+1,"bookshelf")
        t.set(cx-1,f1,bz+1,"crafting_table")
        t.set(bx+1,f1,fz-1,"jack_o_lantern",facing="east")
        lantern(t,cx,H-1,bz+D//2,hanging=True)
        if chest: t.chest(bx+W-2,f1,bz+D//2+1,"west",loot)
    else:
        t.set(bx+W-2,f1,bz+1,"cauldron")
        t.set(cx,f1,bz+1,"bookshelf"); t.set(cx,f1+1,bz+1,"bookshelf")
        t.set(bx+W-2,f1,fz-1,"jack_o_lantern",facing="west")
        lantern(t,cx,H//2-1,bz+D//2,hanging=True)
        up = H//2 + 1
        t.set(bx+W-2,up,bz+2,bed,facing="north",occupied="false",part="foot")
        t.set(bx+W-2,up,bz+1,bed,facing="north",occupied="false",part="head")
        t.set(bx+2,up,fz-1,"jack_o_lantern",facing="east")
        lantern(t,cx,H-1,bz+D//2,hanging=True)
        if chest: t.chest(bx+W-2,up,bz+D//2+1,"west",loot)
    if cobwebs:
        for (x,z) in [(bx+1,bz+1),(bx+W-2,bz+1),(bx+1,fz-1),(bx+W-2,fz-1)]:
            if t.get(x,H-1,z) is None and rnd.random()<0.8: t.set(x,H-1,z,"cobweb")
    t.set(cx-2,1,fz+1,"jack_o_lantern",facing="south")
    t.set(cx+2,1,fz+1,"carved_pumpkin",facing="south")
    lantern(t,cx,H-1,fz+1,hanging=True)
    t.set(bx,1,SZ-2,"hay_block",axis="x"); t.set(bx,2,SZ-2,"pumpkin")
    t.set(bx+1,1,SZ-2,"pumpkin")
    t.set(bx+W-1,1,SZ-1,"jack_o_lantern",facing="south")
    if extra: extra(t, dict(bx=bx,bz=bz,fz=fz,W=W,D=D,H=H,cx=cx))
    for (vx,vz) in villagers:
        t.villager(bx+vx, 1, bz+vz)
    if jig:
        t.jigsaw(cx,0,SZ-1,"south_up",ENTR,ENTR,"minecraft:empty","minecraft:dirt_path")
    return t
