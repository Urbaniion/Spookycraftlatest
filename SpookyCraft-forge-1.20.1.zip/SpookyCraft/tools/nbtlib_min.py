import struct, gzip

class Byte(int): pass

def _name(buf, s):
    b = s.encode("utf-8"); buf += struct.pack(">H", len(b)) + b

def _tid(v):
    if isinstance(v, Byte): return 1
    if isinstance(v, bool): raise TypeError("bool not allowed")
    if isinstance(v, int): return 3
    if isinstance(v, float): return 6
    if isinstance(v, str): return 8
    if isinstance(v, list): return 9
    if isinstance(v, dict): return 10
    raise TypeError(type(v))

def _payload(buf, v):
    t = _tid(v)
    if t == 1: buf += struct.pack(">b", int(v))
    elif t == 3: buf += struct.pack(">i", v)
    elif t == 6: buf += struct.pack(">d", v)
    elif t == 8: _name(buf, v)
    elif t == 9:
        if not v: buf += bytes([0]) + struct.pack(">i", 0)
        else:
            et = _tid(v[0]); buf += bytes([et]) + struct.pack(">i", len(v))
            for x in v:
                assert _tid(x) == et
                _payload(buf, x)
    elif t == 10:
        for k, x in v.items():
            buf += bytes([_tid(x)]); _name(buf, k); _payload(buf, x)
        buf += b"\x00"

def dumps(root):
    buf = bytearray(); buf += bytes([10]); _name(buf, ""); _payload(buf, root)
    return gzip.compress(bytes(buf))

# ---- minimal reader, only used to validate what we wrote ----
def loads(data):
    b = gzip.decompress(data); pos = [0]
    def rd(fmt):
        n = struct.calcsize(fmt); v = struct.unpack_from(fmt, b, pos[0]); pos[0] += n; return v[0]
    def rname():
        n = rd(">H"); s = b[pos[0]:pos[0]+n].decode(); pos[0] += n; return s
    def payload(t):
        if t == 1: return rd(">b")
        if t == 3: return rd(">i")
        if t == 6: return rd(">d")
        if t == 8: return rname()
        if t == 9:
            et = rd(">B"); n = rd(">i"); return [payload(et) for _ in range(n)]
        if t == 10:
            d = {}
            while True:
                tt = rd(">B")
                if tt == 0: return d
                k = rname(); d[k] = payload(tt)
    assert rd(">B") == 10; rname()
    return payload(10)
