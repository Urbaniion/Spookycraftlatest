from PIL import Image
from collections import deque
import statistics

SRC = "/mnt/user-data/uploads/"
RES = "/home/claude/SpookyCraft/src/main/resources/assets/spookycraft/textures/"
names = {"dallas":"DallasMask.png","wolf":"WolfMask.png","houston":"HoustonMask.png",
         "hoxton":"HoxtonMask.png","chains":"ChainsMask.png"}

def edge_color(im):
    """median color of the outer ring of an opaque mask (its rim)"""
    from PIL import ImageFilter
    a = im.getchannel('A').point(lambda v:255 if v>200 else 0)
    inner = a.filter(ImageFilter.MinFilter(9))
    px = im.load(); ap = a.load(); ip = inner.load(); cols=[]
    for y in range(im.height):
        for x in range(im.width):
            if ap[x,y] and not ip[x,y]:
                cols.append(px[x,y][:3])
    print("rim samples:", len(cols))
    return tuple(int(statistics.median(c[i] for c in cols)) for i in range(3))

def fix_rim(im, rim, depth=9):
    """turn the black OUTER outline (<= depth px from the edge) into the gray rim the other masks have"""
    px = im.load(); w,h = im.size
    def dark(x,y):
        r,g,b,a = px[x,y]; return a>60 and (r+g+b)/3 < 75
    # chessboard distance from transparent pixels
    dist = {}
    q = deque()
    for y in range(h):
        for x in range(w):
            if px[x,y][3] < 60:
                dist[(x,y)] = 0; q.append((x,y))
    while q:
        x,y = q.popleft()
        d = dist[(x,y)]
        if d >= depth: continue
        for dx in (-1,0,1):
            for dy in (-1,0,1):
                nx,ny = x+dx,y+dy
                if 0<=nx<w and 0<=ny<h and (nx,ny) not in dist:
                    dist[(nx,ny)] = d+1; q.append((nx,ny))
    out = im.copy(); op = out.load(); n=0
    for (x,y),d in dist.items():
        if d>0 and dark(x,y):
            op[x,y] = (rim[0],rim[1],rim[2],px[x,y][3]); n+=1
    return out, n

def crop(im):
    return im.crop(im.getchannel('A').point(lambda v:255 if v>60 else 0).getbbox())

def hard_alpha(im, thr=110):
    px = im.load()
    for y in range(im.height):
        for x in range(im.width):
            r,g,b,a = px[x,y]
            px[x,y] = (r,g,b,255) if a>=thr else (0,0,0,0)
    return im

chains = Image.open(SRC+names["chains"]).convert("RGBA")
rim = edge_color(chains)
print("rim color from Chains:", rim)

for key,fn in names.items():
    im = Image.open(SRC+fn).convert("RGBA")
    if key == "houston":
        im, n = fix_rim(im, rim)
        print("houston outline pixels recolored:", n)
        im.save("/home/claude/gen/houston_fixed.png")
    c = crop(im)
    # item icon: fit into 16x16 keeping aspect ratio
    s = min(16/c.width, 16/c.height)
    icon = c.resize((max(1,round(c.width*s)), max(1,round(c.height*s))), Image.LANCZOS)
    icon = hard_alpha(icon)
    canvas = Image.new("RGBA",(16,16),(0,0,0,0))
    canvas.paste(icon,((16-icon.width)//2,(16-icon.height)//2), icon)
    canvas.save(RES+f"item/mask_{key}.png")
    # armor texture (128x64 = 2x the 64x32 layout); front of the head is at (16,16)-(32,32)
    face = hard_alpha(c.resize((16,16), Image.LANCZOS))
    tex = Image.new("RGBA",(128,64),(0,0,0,0))
    tex.paste(face,(16,16),face)
    import os
    os.makedirs(RES+"models/armor", exist_ok=True)
    tex.save(RES+f"models/armor/mask_{key}_layer_1.png")
    tex.save(RES+f"models/armor/mask_{key}_layer_2.png")
print("done")
