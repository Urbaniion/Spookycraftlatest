"""Generates custom entity models (Java) + their textures from one description, so UVs always match."""
import random, math, os
from PIL import Image

RES = "/home/claude/SpookyCraft/src/main/resources/assets/spookycraft/textures/entity/"
JAVA = "/home/claude/SpookyCraft/src/main/java/com/urbanion/spookycraft/client/"

def C(h, a=255):
    h = h.lstrip('#'); return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), a)
def shade(c, k): return (max(0,min(255,int(c[0]*k))), max(0,min(255,int(c[1]*k))), max(0,min(255,int(c[2]*k))), 255)

class Cube:
    def __init__(s, x,y,z,w,h,d, paint, mirror=False, inflate=0.0, uv_from=None):
        s.x,s.y,s.z,s.w,s.h,s.d = x,y,z,w,h,d
        s.paint, s.mirror, s.inflate, s.uv_from = paint, mirror, inflate, uv_from
        s.u = s.v = None; s.cid = None

class Part:
    def __init__(s, name, parent, pivot, rot, cubes):
        s.name, s.parent, s.pivot, s.rot, s.cubes = name, parent, pivot, rot, cubes

def region(c):
    wi, hi, di = math.ceil(c.w), math.ceil(c.h), math.ceil(c.d)
    return 2*(di+wi), di+hi

def pack(parts, W, H):
    cubes = [(p.name, i, c) for p in parts for i, c in enumerate(p.cubes)]
    for n,i,c in cubes: c.cid = f"{n}:{i}"
    real = [c for n,i,c in cubes if c.uv_from is None]
    real.sort(key=lambda c: (-region(c)[1], -region(c)[0]))
    x = y = rowh = 0
    for c in real:
        rw, rh = region(c)
        if x + rw > W: x = 0; y += rowh; rowh = 0
        c.u, c.v = x, y; x += rw; rowh = max(rowh, rh)
        assert y + rh <= H, "texture atlas too small"
    byid = {c.cid: c for n,i,c in cubes}
    for n,i,c in cubes:
        if c.uv_from: o = byid[c.uv_from]; c.u, c.v = o.u, o.v
    return cubes

def paint_cube(img, c, rnd):
    wi, hi, di = math.ceil(c.w), math.ceil(c.h), math.ceil(c.d)
    u, v = c.u, c.v
    faces = {'top':(u+di, v, wi, di), 'bottom':(u+di+wi, v, wi, di),
             'right':(u, v+di, di, hi), 'front':(u+di, v+di, wi, hi),
             'left':(u+di+wi, v+di, di, hi), 'back':(u+2*di+wi, v+di, wi, hi)}
    for face,(x0,y0,fw,fh) in faces.items():
        for yy in range(fh):
            for xx in range(fw):
                col = c.paint(face, xx, yy, fw, fh, rnd)
                if col is not None: img.putpixel((x0+xx, y0+yy), col)

def face_origin(c, face):
    wi, hi, di = math.ceil(c.w), math.ceil(c.h), math.ceil(c.d)
    return {'front':(c.u+di, c.v+di)}[face]

def f(x): return f"{float(x)}F"

def java_layer(parts, W, H):
    out = []
    names = {None: "root"}
    for p in parts:
        var = p.name
        names[p.name] = var
        lines = ["CubeListBuilder.create()"]
        for c in p.cubes:
            call = f".texOffs({c.u}, {c.v})"
            if c.mirror: call += ".mirror()"
            if c.inflate:
                call += f".addBox({f(c.x)}, {f(c.y)}, {f(c.z)}, {f(c.w)}, {f(c.h)}, {f(c.d)}, new CubeDeformation({f(c.inflate)}))"
            else:
                call += f".addBox({f(c.x)}, {f(c.y)}, {f(c.z)}, {f(c.w)}, {f(c.h)}, {f(c.d)})"
            if c.mirror: call += ".mirror(false)"
            lines.append(call)
        rx, ry, rz = p.rot; px, py, pz = p.pivot
        pose = f"PartPose.offsetAndRotation({f(px)}, {f(py)}, {f(pz)}, {f(rx)}, {f(ry)}, {f(rz)})"
        parent = names[p.parent]
        out.append(f'        PartDefinition {var} = {parent}.addOrReplaceChild("{p.name}",\n                ' +
                   "\n                ".join(lines) + f",\n                {pose});")
    return "\n".join(out)

def java_fields(parts):
    decl = "\n".join(f"    private final ModelPart {p.name};" for p in parts)
    init = []
    for p in parts:
        par = "root" if p.parent is None else p.parent
        init.append(f'        this.{p.name} = {par}.getChild("{p.name}");')
    return decl, "\n".join(init).replace("= root.getChild", "= root.getChild")

# ===========================================================================================
# WEREWOLF
# ===========================================================================================
fur  = C("58402e"); fur_d = C("3a2a1e"); fur_l = C("86654a"); belly = C("a07e60")
claw = C("e4dfd0"); nose = C("0d0908"); pink = C("b0646b"); white = C("f4f1e6"); dark = C("120c08")

def noisy(base, spread=0.12):
    def fn(face,x,y,w,h,r): return shade(base, 1+r.uniform(-spread,spread))
    return fn

def p_skull(face,x,y,w,h,r):
    c = shade(fur, 1+r.uniform(-.12,.12))
    if face == 'top': return shade(fur_d, 1+r.uniform(-.1,.1))
    if face == 'front':
        if y in (2,) and x in (0,1,2,5,6,7): c = fur_d              # heavy brow
        if y == 3 and x in (1,2,5,6): c = dark                       # eye sockets
        if y >= 4 and 2 <= x <= 5: c = shade(belly, 0.9)
        if x in (0,7) and y >= 3: c = fur_l
    return c
def p_snout(face,x,y,w,h,r):
    c = shade(belly, 1+r.uniform(-.07,.07))
    if face == 'front':
        if y == 0 and 1 <= x <= w-2: c = nose
        if y == h-1 and x in (0, w-1): c = white
    if face == 'bottom':
        c = white if x % 2 == 0 else pink
    if face == 'top': c = shade(fur, 1+r.uniform(-.08,.08))
    return c
def p_jaw(face,x,y,w,h,r):
    c = shade(belly, 0.9+r.uniform(-.06,.06))
    if face == 'top': c = white if x % 2 == 1 else pink
    return c
def p_ear(face,x,y,w,h,r):
    c = shade(fur_d, 1+r.uniform(-.1,.1))
    if face == 'front' and 0 < x < w-1 and y > 0: c = pink
    return c
def p_mane(face,x,y,w,h,r):
    c = shade(fur_l, 1+r.uniform(-.14,.14))
    if face in ('front','back','left','right') and y > h*0.6: c = shade(fur, 1+r.uniform(-.1,.1))
    return c
def p_chest(face,x,y,w,h,r):
    c = shade(fur, 1+r.uniform(-.12,.12))
    if face == 'front':
        if abs(x-(w-1)/2) < 3.2 and y > 2: c = shade(belly, 0.85+r.uniform(-.06,.06))
        if y in (3,4) and (x < 5 or x > w-6): c = shade(fur_d, 1.0)    # pec line
    if y == h-1: c = shade(c, 0.8)
    return c
def p_abdomen(face,x,y,w,h,r):
    c = shade(fur_d, 1+r.uniform(-.1,.1))
    if face == 'front' and abs(x-(w-1)/2) < 2.5: c = shade(belly, 0.7+r.uniform(-.05,.05))
    return c
def p_upperarm(face,x,y,w,h,r):
    c = shade(fur, 1+r.uniform(-.12,.12))
    if (x+y*2) % 7 == 0: c = shade(fur_d, 1)
    return c
def p_forearm(face,x,y,w,h,r):
    c = shade(fur_d, 1+r.uniform(-.1,.1))
    if y % 3 == 0 and r.random() < .5: c = shade(fur_l, .9)
    return c
def p_hand(face,x,y,w,h,r):
    c = shade(fur_d, 1+r.uniform(-.08,.08))
    if face == 'bottom': c = shade(pink, .55)
    return c
def p_claw(face,x,y,w,h,r): return shade(claw, 1+r.uniform(-.05,.05))
def p_thigh(face,x,y,w,h,r):
    c = shade(fur, 1+r.uniform(-.12,.12))
    if face in ('front','back') and y > h*.7: c = shade(fur_d, 1)
    return c
def p_shin(face,x,y,w,h,r): return shade(fur_d, 1+r.uniform(-.1,.1))
def p_foot(face,x,y,w,h,r):
    c = shade(fur_d, 1+r.uniform(-.08,.08))
    if face == 'bottom': c = shade(pink, .5)
    return c
def p_tail(face,x,y,w,h,r):
    c = shade(fur, 1+r.uniform(-.12,.12))
    return c
def p_tailtip(face,x,y,w,h,r):
    return shade(fur_l, 1+r.uniform(-.1,.1)) if face != 'back' else shade(fur_l, 1)

W_PARTS = [
    Part("body", None, (0, 6.8, 0), (0,0,0), [Cube(-5,-8,-3,10,8,6, p_abdomen)]),
    Part("chest", "body", (0,-8,0), (0.38,0,0), [
        Cube(-7,-10,-4,14,10,8, p_chest),
        Cube(-6,-13,-3.5,12,4,7, p_mane)]),
    Part("head", "chest", (0,-10,-1.5), (-0.3,0,0), [Cube(-4,-7,-5,8,7,8, p_skull)]),
    Part("snout", "head", (0,0,0), (0,0,0), [Cube(-2.5,-4,-10,5,4,5, p_snout)]),
    Part("jaw", "head", (0,-0.5,-5), (0.12,0,0), [Cube(-2,0,-5,4,1.5,5, p_jaw)]),
    Part("ear_l", "head", (0,0,0), (0,0,0.15), [Cube(1.5,-10.5,-2,2.5,3.5,1.5, p_ear)]),
    Part("ear_r", "head", (0,0,0), (0,0,-0.15), [Cube(-4,-10.5,-2,2.5,3.5,1.5, p_ear, mirror=True, uv_from="ear_l:0")]),
    Part("arm_r", "chest", (-9,-8,0), (0,0,0.08), [Cube(-3,-2,-3,6,10,6, p_upperarm)]),
    Part("forearm_r", "arm_r", (0,8,0), (-0.5,0,0), [Cube(-2.5,0,-2.5,5,9,5, p_forearm)]),
    Part("hand_r", "forearm_r", (0,9,0), (0,0,0), [Cube(-3,0,-3,6,4,6, p_hand),
        Cube(-2.5,4,-3.2,1,3,1, p_claw), Cube(-0.5,4,-3.2,1,3,1, p_claw, uv_from="hand_r:1"),
        Cube(1.5,4,-3.2,1,3,1, p_claw, uv_from="hand_r:1")]),
    Part("arm_l", "chest", (9,-8,0), (0,0,-0.08), [Cube(-3,-2,-3,6,10,6, p_upperarm, mirror=True, uv_from="arm_r:0")]),
    Part("forearm_l", "arm_l", (0,8,0), (-0.5,0,0), [Cube(-2.5,0,-2.5,5,9,5, p_forearm, mirror=True, uv_from="forearm_r:0")]),
    Part("hand_l", "forearm_l", (0,9,0), (0,0,0), [Cube(-3,0,-3,6,4,6, p_hand, mirror=True, uv_from="hand_r:0"),
        Cube(-2.5,4,-3.2,1,3,1, p_claw, uv_from="hand_r:1"), Cube(-0.5,4,-3.2,1,3,1, p_claw, uv_from="hand_r:1"),
        Cube(1.5,4,-3.2,1,3,1, p_claw, uv_from="hand_r:1")]),
    Part("tail", "body", (0,-1.5,3), (0.5,0,0), [Cube(-1.8,-1.8,0,3.6,3.6,9, p_tail)]),
    Part("tail_tip", "tail", (0,0,9), (-0.25,0,0), [Cube(-1.4,-1.4,0,2.8,2.8,6, p_tailtip)]),
    Part("thigh_r", "body", (-3.6,0,0), (-0.55,0,0), [Cube(-2.5,-1,-3,5,9,6, p_thigh)]),
    Part("shin_r", "thigh_r", (0,8,0), (1.0,0,0), [Cube(-2,-1,-2.5,4,9,5, p_shin)]),
    Part("foot_r", "shin_r", (0,8,0), (-0.55,0,0), [Cube(-2.5,0,-6,5,3,8, p_foot),
        Cube(-2.5,1,-7,1,2,1, p_claw, uv_from="hand_r:1"), Cube(-0.5,1,-7,1,2,1, p_claw, uv_from="hand_r:1"),
        Cube(1.5,1,-7,1,2,1, p_claw, uv_from="hand_r:1")]),
    Part("thigh_l", "body", (3.6,0,0), (-0.55,0,0), [Cube(-2.5,-1,-3,5,9,6, p_thigh, mirror=True, uv_from="thigh_r:0")]),
    Part("shin_l", "thigh_l", (0,8,0), (1.0,0,0), [Cube(-2,-1,-2.5,4,9,5, p_shin, mirror=True, uv_from="shin_r:0")]),
    Part("foot_l", "shin_l", (0,8,0), (-0.55,0,0), [Cube(-2.5,0,-6,5,3,8, p_foot, mirror=True, uv_from="foot_r:0"),
        Cube(-2.5,1,-7,1,2,1, p_claw, uv_from="hand_r:1"), Cube(-0.5,1,-7,1,2,1, p_claw, uv_from="hand_r:1"),
        Cube(1.5,1,-7,1,2,1, p_claw, uv_from="hand_r:1")]),
]

WEREWOLF_JAVA = '''package com.urbanion.spookycraft.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.urbanion.spookycraft.entity.Werewolf;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Fully custom werewolf model (generated together with its texture by tools/modelgen.py). */
public class WerewolfModel extends HierarchicalModel<Werewolf> {
    private final ModelPart root;
@@FIELDS@@
    private static final float HIPS_Y = 6.8F;

    public WerewolfModel(ModelPart root) {
        this.root = root;
@@INIT@@
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
@@LAYER@@
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(Werewolf entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        float s = limbSwing * 0.55F;
        float a = Math.min(1.0F, limbSwingAmount * 1.4F);
        float run = Mth.cos(s);

        // look direction
        head.yRot = Mth.clamp(netHeadYaw, -50.0F, 50.0F) * ((float) Math.PI / 180F) * 0.8F;
        head.xRot += headPitch * ((float) Math.PI / 180F) * 0.8F;

        // gallop: legs swing opposite, knees bend, body bobs
        thigh_r.xRot += run * 0.95F * a;
        thigh_l.xRot -= run * 0.95F * a;
        shin_r.xRot += Math.max(0.0F, -run) * 0.9F * a;
        shin_l.xRot += Math.max(0.0F, run) * 0.9F * a;
        foot_r.xRot -= Math.max(0.0F, -run) * 0.5F * a;
        foot_l.xRot -= Math.max(0.0F, run) * 0.5F * a;
        body.y = HIPS_Y - Math.abs(run) * 1.4F * a;
        body.xRot += 0.08F * a;
        chest.yRot = run * 0.12F * a;
        chest.xRot += Mth.sin(ageInTicks * 0.08F) * 0.025F;

        // arms
        if (entity.isAggressive()) {
            float swing = Mth.sin(entity.getAttackAnim(0.0F) * (float) Math.PI);
            arm_r.xRot = -1.35F - swing * 0.9F + run * 0.15F * a;
            arm_l.xRot = -1.35F - swing * 0.9F - run * 0.15F * a;
            arm_r.zRot = 0.18F;
            arm_l.zRot = -0.18F;
            forearm_r.xRot = -0.25F;
            forearm_l.xRot = -0.25F;
            jaw.xRot = 0.55F + Mth.sin(ageInTicks * 0.6F) * 0.06F;
        } else {
            arm_r.xRot += -run * 0.8F * a;
            arm_l.xRot += run * 0.8F * a;
            jaw.xRot = 0.1F + Mth.sin(ageInTicks * 0.1F) * 0.02F;
        }

        // ears twitch, tail wags
        ear_l.zRot += Mth.sin(ageInTicks * 0.13F) * 0.05F;
        ear_r.zRot -= Mth.sin(ageInTicks * 0.11F) * 0.05F;
        tail.yRot = Mth.sin(ageInTicks * 0.1F) * 0.12F + Mth.cos(s) * 0.3F * a;
        tail_tip.yRot = Mth.sin(ageInTicks * 0.1F - 0.8F) * 0.25F;
    }
}
'''

# ===========================================================================================
# BIG RANDY
# ===========================================================================================
skin = C("4a3024"); skin_d = C("372319"); skin_l = C("5e4132")
pinkc = C("e279b0"); pink_d = C("c0588f"); pink_l = C("f19ac8")
yel = C("dcc24c"); yel_d = C("b79d34"); lace = C("ffffff")
hairc = C("b9b9bf"); hair_d = C("8d8d95")
shoe = C("e9e9ee"); shoe_d = C("a3a3aa"); sole = C("55555c")
bucket = C("4d5d7e"); bucket_d = C("37445f"); candy_cols = [C("ff4040"), C("ffa020"), C("40c0ff"), C("a0ff50"), C("ff60d0")]

def r_head(face,x,y,w,h,r):
    c = shade(skin, 1+r.uniform(-.07,.07))
    if face == 'top': return shade(skin_d, 1)
    if face == 'front':
        if y == 2 and 0 < x < w-1: c = shade(skin_d, 0.8)                  # heavy brow
        if y in (3,4) and 1 <= x <= 3: c = C("26201c") if (y == 3 or x in (1,3)) else c      # left glass frame
        if y in (3,4) and 6 <= x <= 8: c = C("26201c") if (y == 3 or x in (6,8)) else c      # right glass frame
        if y == 4 and x == 2: c = C("e8f6ff")
        if y == 4 and x == 7: c = C("e8f6ff")
        if y == 4 and x in (4,5): c = shade(skin_d, 1)                      # nose bridge
        if y == 5 and x in (4,5): c = shade(skin_d, .85)                    # nose
        if y >= 6 and y <= 8 and x >= 1 and x <= w-2:
            c = white if (y == 7 and x % 2 == 1) or (y in (6,8) and x % 2 == 0) else C("251a16")   # wide grin
        if y == 9: c = shade(skin_d, .8)
    if face in ('left','right') and y in (4,5) and x in (4,5): c = shade(skin_l, 1)   # ear
    return c
def r_hair(face,x,y,w,h,r):
    c = shade(hairc, 1+r.uniform(-.14,.14))
    if r.random() < .22: c = shade(hair_d, 1)
    return c
def r_torso(face,x,y,w,h,r):
    c = shade(pinkc, 1+r.uniform(-.06,.06))
    if face == 'front':
        mid = (w-1)/2
        if abs(x-mid) < 3.6: c = shade(yel, 1+r.uniform(-.05,.05))                    # dress V
        if abs(abs(x-mid) - 3.6) < 0.7: c = C("2a1d1a")                                # jacket trim
        if y == 0 and abs(x-mid) < 3.6: c = shade(skin, 1)                              # neckline
        if y in (1,2) and abs(x-mid) < 1.8: c = shade(skin_d, 1)                        # chest hair patch
    if face in ('left','right','back') and r.random() < .1: c = shade(pink_d, 1)
    if y == h-1: c = shade(yel, .9)
    return c
def r_upper_arm(face,x,y,w,h,r):
    c = shade(pinkc, 1+r.uniform(-.07,.07))
    if (x*3+y) % 5 == 0: c = shade(pink_l, 1)
    return c
def r_forearm(face,x,y,w,h,r): return shade(skin, 1+r.uniform(-.08,.08)) if y > 0 else shade(pink_d, 1)
def r_hand(face,x,y,w,h,r):
    c = shade(skin, 1+r.uniform(-.06,.06))
    if face == 'front' and y == h-1 and x % 2 == 1: c = shade(skin_d, 1)
    return c
def r_dress_up(face,x,y,w,h,r):
    c = shade(yel, 1+r.uniform(-.06,.06))
    if (x + y) % 6 == 0: c = shade(yel_d, 1)
    return c
def r_dress_low(face,x,y,w,h,r):
    c = shade(yel, 1+r.uniform(-.07,.07))
    if x % 4 == 0 and face in ('front','back','left','right'): c = shade(yel_d, 1)
    if face in ('front','back','left','right') and y == h-1: c = lace
    if face == 'bottom': c = shade(yel_d, .7)
    return c
def r_leg(face,x,y,w,h,r): return shade(skin, .95+r.uniform(-.05,.05))
def r_shoe(face,x,y,w,h,r):
    c = shade(shoe, 1+r.uniform(-.04,.04))
    if face == 'bottom': return sole
    if face in ('front','left','right','back') and y == h-1: c = sole
    if face == 'top' and x in (2,3) : c = shade(shoe_d, 1)
    return c
def r_bucket(face,x,y,w,h,r):
    c = shade(bucket, 1+r.uniform(-.06,.06))
    if face == 'top': return candy_cols[(x*3+y*5) % len(candy_cols)] if (x+y) % 3 else shade(bucket_d,1)
    if face == 'front' and y in (3,4) and 1 <= x <= w-2: c = C("c7d3ea") if (x % 2 == 0) else c   # "ANDY" lettering band
    if y == 0: c = shade(bucket_d, 1)
    return c
def r_handle(face,x,y,w,h,r): return C("2c2c30")

R_PARTS = [
    Part("body", None, (0, 2, 0), (0,0,0), [Cube(-6,-1,-4,12,3,8, r_dress_up)]),   # waist block
    Part("dress", "body", (0,0,0), (0,0,0), [
        Cube(-9,0,-5.5,18,9,11, r_dress_up),
        Cube(-10.5,8,-6.5,21,5,13, r_dress_low)]),
    Part("torso", "body", (0,0,0), (0,0,0), [Cube(-10,-16,-5.5,20,16,11, r_torso)]),
    Part("head", "torso", (0,-16,0), (0,0,0), [Cube(-5,-10,-5,10,10,10, r_head)]),
    Part("hair", "head", (0,0,0), (0,0,0), [
        Cube(-5,-10,-5,10,5,10, r_hair, inflate=0.7),
        Cube(5.3,-6,-3,2,6,6, r_hair, uv_from="hair:0"),
        Cube(-7.3,-6,-3,2,6,6, r_hair, uv_from="hair:0"),
        Cube(-5,-8,5.3,10,8,2, r_hair, uv_from="hair:0")]),
    Part("arm_r", "torso", (-13,-13,0), (0,0,0.1), [Cube(-4,-2,-4,8,12,8, r_upper_arm)]),
    Part("forearm_r", "arm_r", (0,10,0), (-0.15,0,0), [Cube(-3.5,0,-3.5,7,12,7, r_forearm)]),
    Part("hand_r", "forearm_r", (0,12,0), (0,0,0), [Cube(-3.5,0,-3.5,7,5,7, r_hand)]),
    Part("bucket", "hand_r", (0,4,0), (0,0,0), [
        Cube(-5,2,-5,10,8,10, r_bucket),
        Cube(-0.5,-4,-4,1,6,8, r_handle)]),
    Part("arm_l", "torso", (13,-13,0), (0,0,-0.1), [Cube(-4,-2,-4,8,12,8, r_upper_arm, mirror=True, uv_from="arm_r:0")]),
    Part("forearm_l", "arm_l", (0,10,0), (-0.15,0,0), [Cube(-3.5,0,-3.5,7,12,7, r_forearm, mirror=True, uv_from="forearm_r:0")]),
    Part("hand_l", "forearm_l", (0,12,0), (0,0,0), [Cube(-3.5,0,-3.5,7,5,7, r_hand, mirror=True, uv_from="hand_r:0")]),
    Part("leg_r", "body", (-4.5,0,0), (0,0,0), [Cube(-2.5,0,-2.5,5,18,5, r_leg)]),
    Part("shoe_r", "leg_r", (0,18,0), (0,0,0), [Cube(-3,0,-6,6,4,9, r_shoe)]),
    Part("leg_l", "body", (4.5,0,0), (0,0,0), [Cube(-2.5,0,-2.5,5,18,5, r_leg, mirror=True, uv_from="leg_r:0")]),
    Part("shoe_l", "leg_l", (0,18,0), (0,0,0), [Cube(-3,0,-6,6,4,9, r_shoe, mirror=True, uv_from="shoe_r:0")]),
]

RANDY_JAVA = '''package com.urbanion.spookycraft.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.urbanion.spookycraft.entity.BigRandy;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Fully custom Big Randy model with his own heavy walk animation (generated by tools/modelgen.py). */
public class BigRandyModel extends HierarchicalModel<BigRandy> {
    private final ModelPart root;
@@FIELDS@@
    private static final float HIPS_Y = 2.0F;

    public BigRandyModel(ModelPart root) {
        this.root = root;
@@INIT@@
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
@@LAYER@@
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(BigRandy entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        float s = limbSwing * 0.42F;          // slow, heavy stride
        float a = Math.min(1.0F, limbSwingAmount * 1.6F);
        float step = Mth.cos(s);
        float stomp = Math.abs(Mth.sin(s));    // two stomps per cycle

        head.yRot = Mth.clamp(netHeadYaw, -45.0F, 45.0F) * ((float) Math.PI / 180F) * 0.7F;
        head.xRot = headPitch * ((float) Math.PI / 180F) * 0.6F;

        // each step: whole body drops into the stomp, then sways onto the other side
        body.y = HIPS_Y + stomp * 1.6F * a;
        body.zRot = Mth.sin(s) * 0.07F * a;
        torso.yRot = step * 0.16F * a;
        torso.zRot = -Mth.sin(s) * 0.05F * a;
        torso.xRot = 0.05F * a + Mth.sin(ageInTicks * 0.07F) * 0.015F;     // slight forward lean + breathing
        head.zRot = -Mth.sin(s) * 0.05F * a;
        dress.xRot = stomp * 0.05F * a;
        dress.zRot = Mth.sin(s) * 0.05F * a;

        leg_r.xRot = step * 0.7F * a;
        leg_l.xRot = -step * 0.7F * a;
        shoe_r.xRot = -Math.max(0.0F, step) * 0.35F * a;
        shoe_l.xRot = -Math.max(0.0F, -step) * 0.35F * a;

        if (entity.isAggressive()) {
            float swing = Mth.sin(entity.getAttackAnim(0.0F) * (float) Math.PI);
            arm_r.xRot = -1.5F - swing * 1.2F;
            arm_l.xRot = -1.5F - swing * 1.2F;
            arm_r.zRot = 0.2F;
            arm_l.zRot = -0.2F;
            forearm_r.xRot = -0.5F;
            forearm_l.xRot = -0.5F;
            torso.xRot += 0.15F + swing * 0.25F;
        } else {
            arm_r.xRot += -step * 0.55F * a;
            arm_l.xRot += step * 0.55F * a;
            arm_r.zRot += 0.08F * a + Mth.sin(s) * 0.04F * a;
            arm_l.zRot -= 0.08F * a + Mth.sin(s) * 0.04F * a;
            forearm_r.xRot -= (0.2F + stomp * 0.3F) * a;
            forearm_l.xRot -= (0.2F + stomp * 0.3F) * a;
        }
        // the candy bucket swings
        bucket.xRot = Mth.sin(s + 0.6F) * 0.35F * a + Mth.sin(ageInTicks * 0.09F) * 0.03F;
        bucket.zRot = Mth.cos(s) * 0.15F * a;
    }
}
'''

def build(name, parts, java_tpl, java_name, tex_name, seed):
    cubes = pack(parts, 128, 128)
    rnd = random.Random(seed)
    img = Image.new("RGBA", (128,128), (0,0,0,0))
    for n,i,c in cubes:
        if c.uv_from is None: paint_cube(img, c, rnd)
    os.makedirs(RES+name, exist_ok=True)
    img.save(RES+f"{name}/{tex_name}.png")
    fields, init = java_fields(parts)
    layer = java_layer(parts, 128, 128)
    java = java_tpl.replace("@@FIELDS@@", fields).replace("@@INIT@@", init).replace("@@LAYER@@", layer)
    open(JAVA+java_name, "w").write(java)
    return cubes

def eyes_layer(name, tex_name, cubes, spec):
    img = Image.new("RGBA", (128,128), (0,0,0,0))
    byid = {c.cid: c for n,i,c in cubes}
    for cid, pixels in spec:
        c = byid[cid]; ox, oy = face_origin(c, 'front')
        for (x,y,col) in pixels: img.putpixel((ox+x, oy+y), col)
    img.save(RES+f"{name}/{tex_name}.png")

wc = build("werewolf", W_PARTS, WEREWOLF_JAVA, "WerewolfModel.java", "werewolf", 77)
eyes_layer("werewolf", "werewolf_eyes", wc, [("head:0", [(1,3,C("ffe14a")),(2,3,C("ffcf2a")),(5,3,C("ffcf2a")),(6,3,C("ffe14a")),(2,2,C("fff6a8")),(5,2,C("fff6a8"))])])
rc = build("big_randy", R_PARTS, RANDY_JAVA, "BigRandyModel.java", "big_randy", 91)
eyes_layer("big_randy", "big_randy_eyes", rc, [("head:0", [(2,4,C("f2fbff")),(2,3,C("dff3ff")),(7,4,C("f2fbff")),(7,3,C("dff3ff"))])])
print("models generated")
