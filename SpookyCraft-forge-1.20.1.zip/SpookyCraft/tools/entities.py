from PIL import Image
import random

OUT = "/home/claude/SpookyCraft/src/main/resources/assets/spookycraft/textures/entity/"

def hexc(h, a=255):
    h = h.lstrip('#'); return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), a)

def shade(c, k):
    return (max(0,min(255,int(c[0]*k))), max(0,min(255,int(c[1]*k))), max(0,min(255,int(c[2]*k))), c[3] if len(c)>3 else 255)

class Tex:
    def __init__(self, w=64, h=64):
        self.im = Image.new("RGBA",(w,h),(0,0,0,0)); self.px = self.im.load()
    def box(self, u, v, w, h, d, fn):
        faces = {'top':(u+d,v,w,d), 'bottom':(u+d+w,v,w,d),
                 'right':(u,v+d,d,h), 'front':(u+d,v+d,w,h),
                 'left':(u+d+w,v+d,d,h), 'back':(u+2*d+w,v+d,w,h)}
        for name,(x0,y0,fw,fh) in faces.items():
            for yy in range(fh):
                for xx in range(fw):
                    c = fn(name,xx,yy,fw,fh)
                    if c is not None:
                        self.px[x0+xx,y0+yy] = c
    def clear(self, x0,y0,x1,y1):
        for y in range(y0,y1):
            for x in range(x0,x1): self.px[x,y]=(0,0,0,0)
    def save(self, path): self.im.save(path)

def solid(c, rim=None, noise=0, seed=1):
    rnd = random.Random(seed)
    def fn(face,x,y,w,h):
        col = c
        if noise:
            k = 1 + rnd.uniform(-noise,noise); col = shade(c,k)
        return col
    return fn

# villager model part layouts (64x64):
# head (0,0, 8x10x8) hat (32,0, 8x10x8) nose (24,0, 2x4x2) body (16,20, 8x12x6)
# jacket (0,38, 8x20x6) arms (44,22, 4x8x4) + (40,38, 8x4x4) legs (0,22, 4x12x4)
HEAD=(0,0,8,10,8); HAT=(32,0,8,10,8); NOSE=(24,0,2,4,2); BODY=(16,20,8,12,6)
JACKET=(0,38,8,20,6); ARM=(44,22,4,8,4); ARMBAR=(40,38,8,4,4); LEG=(0,22,4,12,4)

def put(t, region, fn): t.box(*region, fn)

def front_only(inner):
    """apply inner(x,y) only on the 'front' face"""
    def fn(face,x,y,w,h):
        return inner(x,y,w,h) if face=='front' else None
    return fn

# ---------------- 0: Ghost ----------------
def ghost():
    t = Tex(); rnd = random.Random(7)
    sheet = hexc("f2f2fa"); shd = hexc("d4d4e6"); dark = hexc("15101c")
    def sheet_fn(face,x,y,w,h):
        c = sheet if (x+y)%7 else shd
        if face in ('left','right') and x in (0,w-1): c = shd
        return c
    def hat_fn(face,x,y,w,h):
        c = sheet_fn(face,x,y,w,h)
        if face=='front':
            if (x in (1,2) and y in (3,4,5)) or (x in (5,6) and y in (3,4,5)): c = dark      # eyes
            if x in (3,4) and y in (7,8,9): c = dark                                          # "oooh" mouth
        return c
    put(t, HAT, hat_fn); put(t, HEAD, sheet_fn)
    put(t, BODY, sheet_fn)
    def jacket_fn(face,x,y,w,h):
        c = sheet_fn(face,x,y,w,h)
        if y >= h-2 and (x+y)%3==0: return None      # tattered hem
        return c
    put(t, JACKET, jacket_fn)
    put(t, ARM, sheet_fn); put(t, ARMBAR, sheet_fn); put(t, LEG, sheet_fn)
    t.clear(24,0,32,6)   # hide the nose
    return t

# ---------------- 1: Frankenstein ----------------
def frank():
    t = Tex(); skin = hexc("7fb069"); skin_d = hexc("5f8f4e"); hair = hexc("16161c")
    suit = hexc("2c2c36"); suit_l = hexc("45455a"); shirt = hexc("cfcfd8"); bolt = hexc("9a9aa6"); scar = hexc("3b3b2f")
    def head_fn(face,x,y,w,h):
        c = skin if (x*3+y*5)%11 else skin_d
        if face in ('top','bottom'): return hair if face=='top' else skin_d
        if y <= 2: return hair                                            # flat hair
        if face=='front':
            if y==3: c = scar if x%2==0 else skin                          # stitched forehead
            if y==4 and x in (1,2,5,6): c = hexc("f2f2f2")                  # eyes
            if y==4 and x in (2,5): c = hexc("101010")
            if y==3 and x in (0,7): c = skin_d
            if y==7 and 1<=x<=6: c = scar                                   # mouth stitches
            if y==7 and x in (2,4,6): c = hexc("111111")
        if face in ('left','right') and y in (6,7) and x in (3,4): c = bolt  # neck bolts
        return c
    put(t, HEAD, head_fn)
    def hat_fn(face,x,y,w,h):               # flat-top hair block
        if face=='top': return hair
        if y<=2: return hair
        return None
    put(t, HAT, hat_fn); put(t, NOSE, solid(skin_d))
    def body_fn(face,x,y,w,h):
        c = suit if (x+y)%5 else suit_l
        if face=='front' and 2<=x<=5 and y<=6: c = shirt
        if face=='front' and x in (3,4) and y<=6: c = hexc("c2c2cc")
        return c
    put(t, BODY, body_fn)
    def jacket_fn(face,x,y,w,h):
        c = suit if (x+y)%5 else suit_l
        if face=='front' and x in (3,4): c = hexc("20202a")
        if y>=h-1: c = hexc("1a1a22")
        return c
    put(t, JACKET, jacket_fn)
    def arm_fn(face,x,y,w,h): return skin if y>=6 else suit
    put(t, ARM, arm_fn); put(t, ARMBAR, solid(suit)); put(t, LEG, solid(hexc("3a3a48"),noise=0.05))
    return t

# ---------------- 2: Vampire ----------------
def vampire():
    t = Tex(); skin = hexc("e8dcd6"); skin_d = hexc("cbbab5"); hair = hexc("0e0b12")
    cape = hexc("17101f"); red = hexc("8b1020"); red_d = hexc("5e0a16")
    def head_fn(face,x,y,w,h):
        c = skin if (x+y)%6 else skin_d
        if face=='top': return hair
        if face=='back': return hair
        if y<=1: return hair
        if face=='front':
            if y==2 and (x<=1 or x>=6): c = hair                           # widow's peak
            if y==4 and x in (1,2,5,6): c = hexc("ffffff")
            if y==4 and x in (2,5): c = hexc("d0101e")                       # red eyes
            if y==3 and 1<=x<=2: c = hair
            if y==3 and 5<=x<=6: c = hair
            if y==8 and 2<=x<=5: c = red                                     # lips
            if y==9 and x in (2,5): c = hexc("ffffff")                       # fangs
        if face in ('left','right') and y<=3: c = hair
        return c
    put(t, HEAD, head_fn); put(t, NOSE, solid(skin_d))
    def hat_fn(face,x,y,w,h):               # slicked hair + tall collar behind
        if face=='top': return hair
        if y<=1 and face!='front': return hair
        return None
    put(t, HAT, hat_fn)
    def body_fn(face,x,y,w,h):
        c = cape
        if face=='front' and 3<=x<=4: c = hexc("e9e9ee") if y<=5 else cape  # shirt front
        if face=='front' and y==0: c = red
        return c
    put(t, BODY, body_fn)
    def jacket_fn(face,x,y,w,h):
        c = cape if (x+y)%4 else hexc("1e1429")
        if face=='front' and x in (3,4): c = red if y>3 else red_d          # red lining opening
        if face=='back' and y<3: c = red
        if y>=h-2: c = hexc("0f0916")
        return c
    put(t, JACKET, jacket_fn)
    put(t, ARM, lambda f,x,y,w,h: skin if y>=6 else cape); put(t, ARMBAR, solid(cape)); put(t, LEG, solid(hexc("120d18")))
    return t

# ---------------- 3: Mummy ----------------
def mummy():
    t = Tex(); rnd = random.Random(11)
    a = hexc("ddd2b4"); b = hexc("c2b592"); c3 = hexc("efe6cc"); dark = hexc("3a3223")
    def wrap(face,x,y,w,h):
        band = ((y + (x//3 if face in ('front','back') else 0)) % 4)
        col = [a,b,a,c3][band]
        if (x*7+y*3) % 13 == 0: col = shade(col,0.9)
        return col
    def head_fn(face,x,y,w,h):
        c = wrap(face,x,y,w,h)
        if face=='front':
            if y in (4,5) and 1<=x<=6: c = dark                              # eye gap
            if y==4 and x in (2,5): c = hexc("e9fbff")                       # glowing eyes
        return c
    put(t, HEAD, head_fn); put(t, NOSE, lambda f,x,y,w,h: wrap(f,x,y,w,h))
    put(t, BODY, wrap)
    def jacket_fn(face,x,y,w,h):
        if y>=h-4 and (x*5+y)%3==0: return None                              # hanging rags
        return wrap(face,x,y,w,h)
    put(t, JACKET, jacket_fn)
    put(t, ARM, wrap); put(t, ARMBAR, wrap); put(t, LEG, wrap)
    return t

# ---------------- 4: Pumpkin head ----------------
def pumpkin():
    t = Tex(); o = hexc("e8841a"); o_d = hexc("b85f0c"); o_l = hexc("f6a233"); glow = hexc("ffd23f"); face = hexc("2a1204")
    stem = hexc("4a6b2a"); cloak = hexc("201028"); trim = hexc("e8841a")
    def hat_fn(f,x,y,w,h):
        if f=='top':
            if 3<=x<=4 and 3<=y<=4: return stem
            return o_l if (x+y)%3 else o
        c = o if x%4 else o_d                                                # pumpkin ribs
        if f=='front':
            if (x in (1,2) and y in (3,4,5)) or (x in (5,6) and y in (3,4,5)):
                c = glow if y>=4 else face                                    # triangle-ish eyes
            if y in (7,8) and 1<=x<=6: c = glow if (x+y)%2 else face       # toothy grin
            if y==3 and x in (1,6): c = o
        return c
    put(t, HAT, hat_fn); put(t, HEAD, solid(hexc("1a0f22")))
    t.clear(24,0,32,6)   # no nose poking through the pumpkin
    def body_fn(f,x,y,w,h):
        c = cloak
        if f=='front' and y==0: c = trim
        return c
    put(t, BODY, body_fn)
    def jacket_fn(f,x,y,w,h):
        c = cloak if (x+y)%4 else hexc("2a1636")
        if y>=h-3: c = trim if y==h-3 else c
        if f=='front' and x in (3,4): c = hexc("33194a")
        return c
    put(t, JACKET, jacket_fn)
    put(t, ARM, lambda f,x,y,w,h: o if y>=6 else cloak); put(t, ARMBAR, solid(cloak)); put(t, LEG, solid(hexc("160c1c")))
    return t

for i,fn in enumerate([ghost, frank, vampire, mummy, pumpkin]):
    fn().save(OUT+f"trick_or_treat_villager/costume_{i}.png")

# ---------------- Werewolf (64x64 humanoid layout + snout/ears) ----------------
def werewolf():
    t = Tex(); rnd = random.Random(21)
    fur = hexc("5b4030"); fur_d = hexc("3e2a1f"); fur_l = hexc("7a5a43"); belly = hexc("8a6b52"); claw = hexc("d9d4c4")
    def furfn(base, spread=0.12):
        def fn(face,x,y,w,h):
            k = 1 + rnd.uniform(-spread, spread)
            return shade(base,k)
        return fn
    # head 0,0 8x8x8
    def head_fn(face,x,y,w,h):
        c = shade(fur, 1+rnd.uniform(-0.12,0.12))
        if face=='front':
            if y in (3,) and x in (1,2,5,6): c = hexc("120a06")             # dark eye sockets (eyes layer glows on top)
            if y==2 and x in (1,2,5,6): c = fur_d                             # heavy brow
            if y>=5 and 2<=x<=5: c = belly
        if face=='top': c = fur_d if rnd.random()<0.4 else fur
        return c
    t.box(0,0,8,8,8, head_fn)
    # snout 32,0 4x3x3: lighter, black nose, fangs
    def snout_fn(face,x,y,w,h):
        c = shade(belly, 1+rnd.uniform(-0.08,0.08))
        if face=='front':
            if y==0 and 1<=x<=2: c = hexc("0b0807")                         # nose
            if y==2 and x in (0,3): c = hexc("f4f1e6")                       # fangs
        return c
    t.box(32,0,4,3,3, snout_fn)
    # ears 48,0 2x3x1
    def ear_fn(face,x,y,w,h):
        c = fur_d
        if face=='front' and y>=1: c = hexc("b0696b")
        return c
    t.box(48,0,2,3,1, ear_fn)
    # body 16,16 8x12x4
    def body_fn(face,x,y,w,h):
        c = shade(fur_d, 1+rnd.uniform(-0.1,0.1))
        if face=='front' and 2<=x<=5 and y<=8: c = shade(belly, 0.8+rnd.uniform(-0.06,0.06))
        return c
    t.box(16,16,8,12,4, body_fn)
    # arms 40,16 4x12x4
    def arm_fn(face,x,y,w,h):
        c = shade(fur, 1+rnd.uniform(-0.12,0.12))
        if y>=10: c = claw if (x+y)%2==0 else fur_d
        return c
    t.box(40,16,4,12,4, arm_fn)
    # left arm (separate area in case of non-mirrored use) and legs
    t.box(32,48,4,12,4, arm_fn)
    def leg_fn(face,x,y,w,h):
        c = shade(fur_d, 1+rnd.uniform(-0.1,0.1))
        if y>=10: c = fur_d if (x+y)%2 else hexc("2a1c14")
        return c
    t.box(0,16,4,12,4, leg_fn); t.box(16,48,4,12,4, leg_fn)
    return t

werewolf().save(OUT+"werewolf/werewolf.png")

# glowing eyes layer: only the eye pixels on the head front (8,8)-(16,16)
eyes = Tex()
for (x,y) in [(1,3),(2,3),(5,3),(6,3)]:
    eyes.px[8+x, 8+y] = hexc("ffe14a")
for (x,y) in [(2,3),(5,3)]:
    eyes.px[8+x, 8+y] = hexc("ffffff")
eyes.save(OUT+"werewolf/werewolf_eyes.png")

# preview sheet
sheet = Image.new("RGBA",(64*5*3+40, 64*3*2+20),(70,70,80,255))
names = [f"trick_or_treat_villager/costume_{i}.png" for i in range(5)] + ["werewolf/werewolf.png"]
for i,n in enumerate(names):
    im = Image.open(OUT+n).resize((192,192),Image.NEAREST)
    sheet.paste(im,((i%5)*200+5,(i//5)*200+5),im)
sheet.save("/home/claude/gen/entities_sheet.png")
print("ok")
