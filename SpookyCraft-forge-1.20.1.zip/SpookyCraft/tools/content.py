import json, os
R = "/home/claude/SpookyCraft/src/main/resources/"
A = R + "assets/spookycraft/"
D = R + "data/spookycraft/"
M = R + "data/minecraft/"
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    json.dump(obj, open(path,"w"), indent=2)

# ------------------------------------------------------------------ item models
for n in ["hallowite_sword","hallowite_pickaxe","hallowite_axe","hallowite_shovel","hallowite_hoe"]:
    wj(A+f"models/item/{n}.json", {"parent":"minecraft:item/handheld","textures":{"layer0":f"spookycraft:item/{n}"}})
for n in ["hallowite_ingot","raw_hallowite","hallowite_helmet","hallowite_chestplate","hallowite_leggings","hallowite_boots",
          "gummy_bat","caramel_apple","ghost_marshmallow","black_licorice","sour_worms","apple_flavored_chocolate_piece",
          "pumpkin_bed","witch_bed","frankenstein_bed","ghost_bed"]:
    wj(A+f"models/item/{n}.json", {"parent":"minecraft:item/generated","textures":{"layer0":f"spookycraft:item/{n}"}})
for n in ["hallowite_block","chocolate_log","chocolate_leaves"]:
    wj(A+f"models/item/{n}.json", {"parent":f"spookycraft:block/{n}"})
wj(A+"models/item/big_randy_spawn_egg.json", {"parent":"minecraft:item/template_spawn_egg"})

# ------------------------------------------------------------------ simple blocks
wj(A+"models/block/hallowite_block.json", {"parent":"minecraft:block/cube_all","textures":{"all":"spookycraft:block/hallowite_block"}})
wj(A+"blockstates/hallowite_block.json", {"variants":{"":{"model":"spookycraft:block/hallowite_block"}}})
wj(A+"models/block/chocolate_log.json", {"parent":"minecraft:block/cube_column","textures":{"end":"spookycraft:block/chocolate_log_top","side":"spookycraft:block/chocolate_log"}})
wj(A+"blockstates/chocolate_log.json", {"variants":{
    "axis=y":{"model":"spookycraft:block/chocolate_log"},
    "axis=z":{"model":"spookycraft:block/chocolate_log","x":90},
    "axis=x":{"model":"spookycraft:block/chocolate_log","x":90,"y":90}}})
wj(A+"models/block/chocolate_leaves.json", {"parent":"minecraft:block/cube_all","render_type":"minecraft:cutout_mipped",
    "textures":{"all":"spookycraft:block/chocolate_leaves"}})
wj(A+"blockstates/chocolate_leaves.json", {"variants":{"":{"model":"spookycraft:block/chocolate_leaves"}}})

# ------------------------------------------------------------------ beds
WOOD=[0,0,4,4]; TOP=[4,0,12,8]; SIDE=[12,0,16,4]; BLACK=[12,4,16,8]; PILLOW=[4,8,12,12]; GRAY=[0,4,4,8]
def box(frm, to, up, side, down=None, tex="#bed"):
    down = down or WOOD
    return {"from":frm,"to":to,"faces":{
        "north":{"uv":side,"texture":tex},"south":{"uv":side,"texture":tex},
        "east":{"uv":side,"texture":tex},"west":{"uv":side,"texture":tex},
        "up":{"uv":up,"texture":tex},"down":{"uv":down,"texture":tex}}}
def wood(frm,to): return box(frm,to,WOOD,WOOD)
def pumpkin_box(frm,to):
    return {"from":frm,"to":to,"faces":{
        "north":{"uv":[0,0,16,16],"texture":"#ps"},"south":{"uv":[0,0,16,16],"texture":"#pc"},
        "east":{"uv":[0,0,16,16],"texture":"#ps"},"west":{"uv":[0,0,16,16],"texture":"#ps"},
        "up":{"uv":[0,0,16,16],"texture":"#pt"},"down":{"uv":[0,0,16,16],"texture":"#pt"}}}
def flat(frm,to,tex,uv=[0,0,16,16]):
    return {"from":frm,"to":to,"faces":{f:{"uv":uv,"texture":tex} for f in ["north","south","east","west","up","down"]}}

def bed_models(name):
    short = name.replace("_bed","")
    tex = {"bed":f"spookycraft:block/bed_{short}","particle":f"spookycraft:block/bed_{short}"}
    foot = [wood([0,0,13],[3,3,16]), wood([13,0,13],[16,3,16]), wood([0,3,0],[16,6,16]),
            box([0,6,0],[16,9,14],TOP,SIDE), wood([0,6,14],[16,12,16])]
    head = [wood([0,0,0],[3,3,3]), wood([13,0,0],[16,3,3]), wood([0,3,0],[16,6,16]),
            box([0,6,2],[16,9,16],TOP,SIDE), wood([0,6,0],[16,16,2]), box([3,9,3],[13,11,9],PILLOW,PILLOW,PILLOW)]
    if name == "pumpkin_bed":
        tex.update({"ps":"minecraft:block/pumpkin_side","pt":"minecraft:block/pumpkin_top","pc":"minecraft:block/carved_pumpkin","stem":"minecraft:block/moss_block"})
        foot.append(pumpkin_box([4,9,3],[12,15,11])); foot.append(flat([7,15,6],[9,17,8],"#stem"))
    if name == "witch_bed":
        foot += [box([4,9,4],[12,10,12],BLACK,BLACK,BLACK), box([6,10,6],[10,13,10],BLACK,BLACK,BLACK), box([7.5,13,7.5],[8.5,15,8.5],BLACK,BLACK,BLACK)]
    if name == "frankenstein_bed":
        head += [box([1,16,0.5],[3,18,1.5],GRAY,GRAY,GRAY), box([13,16,0.5],[15,18,1.5],GRAY,GRAY,GRAY)]
    wj(A+f"models/block/{name}_foot.json", {"textures":tex,"elements":foot})
    wj(A+f"models/block/{name}_head.json", {"textures":tex,"elements":head})
    rot = {"north":0,"east":90,"south":180,"west":270}
    variants = {}
    for f,y in rot.items():
        for occ in ("false","true"):
            for part in ("foot","head"):
                v = {"model":f"spookycraft:block/{name}_{part}"}
                if y: v["y"] = y
                variants[f"facing={f},occupied={occ},part={part}"] = v
    wj(A+f"blockstates/{name}.json", {"variants":variants})
for b in ["pumpkin_bed","witch_bed","frankenstein_bed","ghost_bed"]: bed_models(b)

# ------------------------------------------------------------------ loot tables
def self_drop(block, extra_conditions=None):
    conds = (extra_conditions or []) + [{"condition":"minecraft:survives_explosion"}]
    return {"type":"minecraft:block","pools":[{"rolls":1.0,"bonus_rolls":0.0,
        "entries":[{"type":"minecraft:item","name":f"spookycraft:{block}"}],"conditions":conds}]}
for b in ["hallowite_block","chocolate_log"]:
    wj(D+f"loot_tables/blocks/{b}.json", self_drop(b))
for b in ["pumpkin_bed","witch_bed","frankenstein_bed","ghost_bed"]:
    wj(D+f"loot_tables/blocks/{b}.json", self_drop(b, [{"condition":"minecraft:block_state_property","block":f"spookycraft:{b}","properties":{"part":"head"}}]))
shears_or_silk = {"condition":"minecraft:alternative","terms":[
    {"condition":"minecraft:match_tool","predicate":{"items":["minecraft:shears"]}},
    {"condition":"minecraft:match_tool","predicate":{"enchantments":[{"enchantment":"minecraft:silk_touch","levels":{"min":1}}]}}]}
wj(D+"loot_tables/blocks/chocolate_leaves.json", {"type":"minecraft:block","pools":[{"rolls":1.0,"bonus_rolls":0.0,"entries":[
    {"type":"minecraft:alternatives","children":[
        {"type":"minecraft:item","name":"spookycraft:chocolate_leaves","conditions":[shears_or_silk]},
        {"type":"minecraft:item","name":"spookycraft:apple_flavored_chocolate_piece","conditions":[
            {"condition":"minecraft:survives_explosion"},
            {"condition":"minecraft:table_bonus","enchantment":"minecraft:fortune","chances":[0.12,0.16,0.22,0.3,0.4]}]}]}]}]})

def item_entry(name, weight, lo=1, hi=1):
    e = {"type":"minecraft:item","name":name,"weight":weight}
    if hi > 1 or lo > 1:
        e["functions"] = [{"function":"minecraft:set_count","count":{"type":"minecraft:uniform","min":lo,"max":hi}}]
    return e
CANDIES = ["candy_corn","chocolate_bar","lollipop","gummy_bat","caramel_apple","ghost_marshmallow","black_licorice","sour_worms"]
MASKS = ["mask_dallas","mask_wolf","mask_houston","mask_hoxton","mask_chains"]
def chest_table(rolls_lo, rolls_hi, mask_chance, hallowite_chance, rich=False):
    entries = [item_entry(f"spookycraft:{c}", 6, 1, 4) for c in CANDIES]
    entries += [item_entry("minecraft:pumpkin",5,1,3), item_entry("minecraft:carved_pumpkin",3,1,2),
                item_entry("minecraft:jack_o_lantern",2,1,2), item_entry("minecraft:bone",6,1,4),
                item_entry("minecraft:rotten_flesh",5,1,4), item_entry("minecraft:spider_eye",3,1,2),
                item_entry("minecraft:cobweb",3,1,3), item_entry("minecraft:candle",3,1,2),
                item_entry("minecraft:pumpkin_pie",4,1,2), item_entry("minecraft:pumpkin_seeds",4,2,6),
                item_entry("minecraft:string",3,1,3), item_entry("minecraft:soul_lantern",1,1,1)]
    if rich:
        entries += [item_entry("minecraft:gold_ingot",4,1,4), item_entry("minecraft:iron_ingot",4,2,5),
                    item_entry("minecraft:emerald",2,1,3), item_entry("minecraft:diamond",1,1,1),
                    item_entry("minecraft:ender_pearl",1,1,2)]
    entries.append({"type":"minecraft:empty","weight":10})
    return {"type":"minecraft:chest","pools":[
        {"rolls":{"type":"minecraft:uniform","min":rolls_lo,"max":rolls_hi},"bonus_rolls":0.0,"entries":entries},
        {"rolls":1,"bonus_rolls":0.0,"conditions":[{"condition":"minecraft:random_chance","chance":mask_chance}],
         "entries":[item_entry(f"spookycraft:{m}",1) for m in MASKS]},
        {"rolls":1,"bonus_rolls":0.0,"conditions":[{"condition":"minecraft:random_chance","chance":hallowite_chance}],
         "entries":[item_entry("spookycraft:raw_hallowite",1,1,2)]}]}
wj(D+"loot_tables/chests/halloween_house.json", chest_table(2,4,0.10,0.015))
wj(D+"loot_tables/chests/halloween_structure.json", chest_table(4,7,0.30,0.06,rich=True))
wj(D+"loot_tables/entities/big_randy.json", {"type":"minecraft:entity","pools":[
    {"rolls":{"type":"minecraft:uniform","min":3,"max":6},"bonus_rolls":0.0,"entries":[item_entry(f"spookycraft:{c}",1,1,3) for c in CANDIES]},
    {"rolls":1,"bonus_rolls":0.0,"conditions":[{"condition":"minecraft:random_chance","chance":0.4}],"entries":[item_entry(f"spookycraft:{m}",1) for m in MASKS]},
    {"rolls":1,"bonus_rolls":0.0,"conditions":[{"condition":"minecraft:random_chance","chance":0.15}],"entries":[item_entry("spookycraft:raw_hallowite",1,1,2)]}]})

# ------------------------------------------------------------------ recipes
def shaped(name, pattern, key, result, count=1, category="equipment"):
    wj(D+f"recipes/{name}.json", {"type":"minecraft:crafting_shaped","category":category,"pattern":pattern,"key":key,
        "result":{"item":result,"count":count}})
I = {"I":{"item":"spookycraft:hallowite_ingot"}}
S = {"S":{"item":"minecraft:stick"}}
shaped("hallowite_sword",["I","I","S"],{**I,**S},"spookycraft:hallowite_sword")
shaped("hallowite_pickaxe",["III"," S "," S "],{**I,**S},"spookycraft:hallowite_pickaxe")
shaped("hallowite_axe",["II","IS"," S"],{**I,**S},"spookycraft:hallowite_axe")
shaped("hallowite_shovel",["I","S","S"],{**I,**S},"spookycraft:hallowite_shovel")
shaped("hallowite_hoe",["II"," S"," S"],{**I,**S},"spookycraft:hallowite_hoe")
shaped("hallowite_helmet",["III","I I"],I,"spookycraft:hallowite_helmet")
shaped("hallowite_chestplate",["I I","III","III"],I,"spookycraft:hallowite_chestplate")
shaped("hallowite_leggings",["III","I I","I I"],I,"spookycraft:hallowite_leggings")
shaped("hallowite_boots",["I I","I I"],I,"spookycraft:hallowite_boots")
shaped("hallowite_block",["III","III","III"],I,"spookycraft:hallowite_block",category="building")
wj(D+"recipes/hallowite_ingot_from_block.json", {"type":"minecraft:crafting_shapeless","category":"misc",
    "ingredients":[{"item":"spookycraft:hallowite_block"}],"result":{"item":"spookycraft:hallowite_ingot","count":9}})
wj(D+"recipes/hallowite_ingot_smelting.json", {"type":"minecraft:smelting","category":"misc","ingredient":{"item":"spookycraft:raw_hallowite"},
    "result":"spookycraft:hallowite_ingot","experience":2.0,"cookingtime":200})
wj(D+"recipes/hallowite_ingot_blasting.json", {"type":"minecraft:blasting","category":"misc","ingredient":{"item":"spookycraft:raw_hallowite"},
    "result":"spookycraft:hallowite_ingot","experience":2.0,"cookingtime":100})
for bed,(deco,wool) in {"pumpkin_bed":("minecraft:carved_pumpkin","minecraft:orange_wool"),"witch_bed":("minecraft:spider_eye","minecraft:purple_wool"),
                        "frankenstein_bed":("minecraft:lightning_rod","minecraft:green_wool"),"ghost_bed":("minecraft:phantom_membrane","minecraft:white_wool")}.items():
    shaped(bed,["DWW","PPP"],{"D":{"item":deco},"W":{"item":wool},"P":{"tag":"minecraft:planks"}},f"spookycraft:{bed}",category="misc")
wj(D+"recipes/doorbell.json", {"type":"minecraft:crafting_shapeless","category":"redstone","ingredients":[
    {"tag":"minecraft:planks"},{"item":"minecraft:stone_button"},{"item":"minecraft:copper_ingot"}],"result":{"item":"spookycraft:doorbell"}})

# ------------------------------------------------------------------ tags
def tag(path, values): wj(path, {"replace":False,"values":values})
BEDS = [f"spookycraft:{b}" for b in ["pumpkin_bed","witch_bed","frankenstein_bed","ghost_bed"]]
tag(M+"tags/blocks/beds.json", BEDS); tag(M+"tags/items/beds.json", BEDS)
tag(M+"tags/blocks/logs.json", ["spookycraft:chocolate_log"])
tag(M+"tags/blocks/leaves.json", ["spookycraft:chocolate_leaves"]); tag(M+"tags/items/leaves.json", ["spookycraft:chocolate_leaves"])
tag(M+"tags/blocks/mineable/axe.json", ["spookycraft:doorbell","spookycraft:chocolate_log"] + BEDS)
tag(M+"tags/blocks/mineable/hoe.json", ["spookycraft:chocolate_leaves"])
tag(M+"tags/blocks/mineable/pickaxe.json", ["spookycraft:hallowite_block"])
tag(M+"tags/blocks/needs_diamond_tool.json", ["spookycraft:hallowite_block"])
tag(M+"tags/blocks/beacon_base_blocks.json", ["spookycraft:hallowite_block"]); tag(M+"tags/items/beacon_payment_items.json", ["spookycraft:hallowite_ingot"])

# ------------------------------------------------------------------ sounds + lang
wj(A+"sounds.json", {
    "doorbell":{"sounds":["spookycraft:doorbell"],"subtitle":"subtitles.spookycraft.doorbell"},
    "big_randy_song":{"sounds":[{"name":"spookycraft:big_randy_song","stream":True,"attenuation_distance":15}],"subtitle":"subtitles.spookycraft.big_randy_song"}})
lang = {
 "block.spookycraft.doorbell":"Doorbell","block.spookycraft.hallowite_block":"Block of Hallowite",
 "block.spookycraft.chocolate_log":"Chocolate Log","block.spookycraft.chocolate_leaves":"Chocolate Apple Leaves",
 "block.spookycraft.pumpkin_bed":"Pumpkin Bed","block.spookycraft.witch_bed":"Witch Bed",
 "block.spookycraft.frankenstein_bed":"Frankenstein Bed","block.spookycraft.ghost_bed":"Ghost Bed",
 "item.spookycraft.candy_corn":"Candy Corn","item.spookycraft.chocolate_bar":"Chocolate Bar","item.spookycraft.lollipop":"Lollipop",
 "item.spookycraft.gummy_bat":"Gummy Bat","item.spookycraft.caramel_apple":"Caramel Apple","item.spookycraft.ghost_marshmallow":"Ghost Marshmallow",
 "item.spookycraft.black_licorice":"Black Licorice","item.spookycraft.sour_worms":"Sour Worms",
 "item.spookycraft.apple_flavored_chocolate_piece":"Apple Flavored Chocolate Piece",
 "item.spookycraft.mask_dallas":"Dallas Mask","item.spookycraft.mask_wolf":"Wolf Mask","item.spookycraft.mask_houston":"Houston Mask",
 "item.spookycraft.mask_hoxton":"Hoxton Mask","item.spookycraft.mask_chains":"Chains Mask",
 "item.spookycraft.raw_hallowite":"Raw Hallowite","item.spookycraft.hallowite_ingot":"Hallowite Ingot",
 "item.spookycraft.hallowite_sword":"Hallowite Sword","item.spookycraft.hallowite_pickaxe":"Hallowite Pickaxe",
 "item.spookycraft.hallowite_axe":"Hallowite Axe","item.spookycraft.hallowite_shovel":"Hallowite Shovel","item.spookycraft.hallowite_hoe":"Hallowite Hoe",
 "item.spookycraft.hallowite_helmet":"Hallowite Helmet","item.spookycraft.hallowite_chestplate":"Hallowite Chestplate",
 "item.spookycraft.hallowite_leggings":"Hallowite Leggings","item.spookycraft.hallowite_boots":"Hallowite Boots",
 "item.spookycraft.trick_or_treat_villager_spawn_egg":"Trick or Treat Villager Spawn Egg",
 "item.spookycraft.werewolf_spawn_egg":"Werewolf Spawn Egg","item.spookycraft.big_randy_spawn_egg":"Big Randy Spawn Egg",
 "entity.spookycraft.trick_or_treat_villager":"Trick or Treat Villager","entity.spookycraft.werewolf":"Werewolf","entity.spookycraft.big_randy":"Big Randy",
 "itemGroup.spookycraft":"Urbanion's SpookyCraft",
 "subtitles.spookycraft.doorbell":"Doorbell rings","subtitles.spookycraft.big_randy_song":"Big Randy's song plays",
 "biome.minecraft.dark_forest":"Halloween Forest"}
wj(A+"lang/en_us.json", lang)

# ------------------------------------------------------------------ Halloween forest features
def patch(tries, spread, provider, soil):
    return {"type":"minecraft:random_patch","config":{"tries":tries,"xz_spread":spread,"y_spread":2,"feature":{"feature":{
        "type":"minecraft:simple_block","config":{"to_place":provider}},"placement":[{"type":"minecraft:block_predicate_filter","predicate":soil}]}}}
ON_GRASS = {"type":"minecraft:all_of","predicates":[{"type":"minecraft:matching_blocks","blocks":"minecraft:air"},
    {"type":"minecraft:matching_blocks","blocks":["minecraft:grass_block","minecraft:podzol","minecraft:dirt","minecraft:coarse_dirt"],"offset":[0,-1,0]}]}
state = lambda n, **p: {"Name":n, **({"Properties":p} if p else {})}
wj(D+"worldgen/configured_feature/halloween_pumpkin_patch.json", patch(20, 6, {"type":"minecraft:weighted_state_provider","entries":[
    {"weight":6,"data":state("minecraft:pumpkin")},{"weight":2,"data":state("minecraft:jack_o_lantern",facing="north")},
    {"weight":2,"data":state("minecraft:jack_o_lantern",facing="east")},{"weight":1,"data":state("minecraft:carved_pumpkin",facing="south")},
    {"weight":1,"data":state("minecraft:hay_block",axis="y")}]}, ON_GRASS))
wj(D+"worldgen/configured_feature/cobweb_patch.json", patch(14, 5, {"type":"minecraft:simple_state_provider","state":state("minecraft:cobweb")},
    {"type":"minecraft:all_of","predicates":[{"type":"minecraft:matching_blocks","blocks":"minecraft:air"},{"type":"minecraft:not","predicate":{"type":"minecraft:matching_blocks","blocks":"minecraft:air","offset":[0,-1,0]}}]}))
wj(D+"worldgen/configured_feature/tombstones.json", patch(3, 3, {"type":"minecraft:simple_state_provider","state":state("minecraft:polished_blackstone_brick_wall")}, ON_GRASS))
wj(D+"worldgen/configured_feature/chocolate_apple_tree.json", {"type":"minecraft:tree","config":{
    "ignore_vines":True,"force_dirt":False,
    "minimum_size":{"type":"minecraft:two_layers_feature_size","limit":1,"lower_size":0,"upper_size":1},
    "dirt_provider":{"type":"minecraft:simple_state_provider","state":state("minecraft:dirt")},
    "trunk_provider":{"type":"minecraft:simple_state_provider","state":state("spookycraft:chocolate_log",axis="y")},
    "foliage_provider":{"type":"minecraft:simple_state_provider","state":state("spookycraft:chocolate_leaves")},
    "trunk_placer":{"type":"minecraft:straight_trunk_placer","base_height":4,"height_rand_a":2,"height_rand_b":0},
    "foliage_placer":{"type":"minecraft:blob_foliage_placer","radius":2,"offset":0,"height":3},
    "decorators":[]}})
def placed(name, extra_filters, rarity):
    wj(D+f"worldgen/placed_feature/{name}.json", {"feature":f"spookycraft:{name}","placement":
        [{"type":"minecraft:rarity_filter","chance":rarity},{"type":"minecraft:in_square"},{"type":"minecraft:heightmap","heightmap":"WORLD_SURFACE_WG"}]
        + extra_filters + [{"type":"minecraft:biome"}]})
placed("halloween_pumpkin_patch", [], 2)
placed("cobweb_patch", [], 3)
placed("tombstones", [], 4)
placed("chocolate_apple_tree", [{"type":"minecraft:block_predicate_filter","predicate":{"type":"minecraft:would_survive",
    "state":{"Name":"minecraft:oak_sapling","Properties":{"stage":"0"}}}}], 50)
wj(D+"forge/biome_modifier/halloween_forest_features.json", {"type":"forge:add_features","biomes":"minecraft:dark_forest",
    "features":["spookycraft:halloween_pumpkin_patch","spookycraft:cobweb_patch","spookycraft:tombstones","spookycraft:chocolate_apple_tree"],
    "step":"vegetal_decoration"})
wj(D+"forge/biome_modifier/halloween_forest_look.json", {"type":"spookycraft:halloween_forest"})
print("content ok")
