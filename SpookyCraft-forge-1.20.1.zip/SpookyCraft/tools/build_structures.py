import sys, json, os, random
sys.path.insert(0, "/home/claude/gen")
from structlib import *

PUMPKIN_BED = "spookycraft:pumpkin_bed"; WITCH_BED = "spookycraft:witch_bed"
FRANK_BED = "spookycraft:frankenstein_bed"; GHOST_BED = "spookycraft:ghost_bed"

def bed(t, x, y, z, name, facing="north"):
    # foot at (x,z); head one step in 'facing' direction
    dx, dz = {"north":(0,-1),"south":(0,1),"west":(-1,0),"east":(1,0)}[facing]
    t.set(x,y,z,name,facing=facing,occupied="false",part="foot")
    t.set(x+dx,y,z+dz,name,facing=facing,occupied="false",part="head")

# ----------------------------------------------------------------------- town houses
def witch_extra(t, L):
    bx, bz, fz, W, D, H = L["bx"], L["bz"], L["fz"], L["W"], L["D"], L["H"]
    for (x,z) in [(bx+2,bz+1),(bx+1,bz+3),(bx+3,fz-1)]:
        if t.get(x,2,z) is None: t.set(x,2,z,"cobweb")
    t.set(bx+W-2,1,bz+2,"soul_campfire",facing="west",lit="true",signal_fire="false",waterlogged="false")

def mansion_extra(t, L):
    bx, bz, fz, W, D, H = L["bx"], L["bz"], L["fz"], L["W"], L["D"], L["H"]
    bed(t, bx+W-2, 1, bz+2, "spookycraft:witch_bed", "north")
    for (x,z) in [(bx+4,fz-2),(bx+5,fz-2),(bx+6,fz-2)]:
        t.set(x,1,z,"crimson_fence"); candle(t,x,2,z,3)
    lantern(t,bx+W//2,H-1,bz+2,hanging=True)

pieces = {}
pieces["house_crimson"] = house(7,7,4,"crimson_planks","stripped_crimson_stem","stripped_crimson_stem",
    "blackstone_stairs","blackstone_slab","polished_blackstone_bricks",PUMPKIN_BED,[(3,3)], seed=1)
pieces["house_warped"] = house(7,5,4,"warped_planks","stripped_warped_stem","stripped_warped_stem",
    "polished_blackstone_brick_stairs","polished_blackstone_brick_slab","blackstone",WITCH_BED,[(3,2)], door="warped_door", seed=2)
pieces["house_tower"] = house(5,5,8,"warped_planks","stripped_crimson_stem","stripped_crimson_stem",
    "nether_brick_stairs","nether_brick_slab","polished_blackstone_bricks",GHOST_BED,[(2,2),(2,3)], floors=2, seed=3)
pieces["house_mansion"] = house(11,9,5,"crimson_planks","stripped_warped_stem","stripped_crimson_stem",
    "blackstone_stairs","blackstone_slab","polished_blackstone_bricks",FRANK_BED,[(4,4),(7,3),(5,6)],
    pillars=True, extra=mansion_extra, seed=4)
pieces["house_witch"] = house(5,5,4,"warped_planks","warped_stem","stripped_warped_stem",
    "crimson_stairs","crimson_slab","blackstone",WITCH_BED,[(2,3)], extra=witch_extra, seed=5)

def graveyard():
    SX, SY, SZ = 11, 5, 9
    t = T(SX,SY,SZ); rnd = random.Random(5)
    for x in range(SX):
        for z in range(SZ): t.set(x,0,z,"podzol" if rnd.random()<0.6 else "coarse_dirt")
    for x in range(SX):
        for z in (0,SZ-1):
            if not (z == SZ-1 and x in (4,5,6)): t.set(x,1,z,"nether_brick_fence")
    for z in range(SZ):
        for x in (0,SX-1): t.set(x,1,z,"nether_brick_fence")
    for (x,z) in [(0,0),(SX-1,0),(0,SZ-1),(SX-1,SZ-1),(4,SZ-1),(6,SZ-1)]:
        t.set(x,2,z,"nether_brick_fence"); lantern(t,x,3,z,soul=True)
    for (x,z) in [(2,2),(4,2),(6,2),(8,2),(3,5),(7,5)]:
        t.set(x,1,z,"polished_blackstone_brick_wall"); slab(t,x,2,z,"polished_blackstone_brick_slab")
    t.chest(5,1,3,"south",STRUCT_LOOT)
    for (x,z) in [(2,4),(8,4),(5,6),(9,6)]: t.set(x,1,z,"cobweb")
    t.set(1,1,6,"dead_bush"); t.set(9,1,2,"dead_bush")
    t.set(5,1,1,"jack_o_lantern",facing="south"); t.set(1,1,1,"carved_pumpkin",facing="east")
    for z in range(4,SZ): t.set(5,0,z,"dirt_path")
    t.jigsaw(5,0,SZ-1,"south_up",ENTR,ENTR,"minecraft:empty","minecraft:dirt_path")
    return t

def pumpkin_patch():
    SX, SY, SZ = 11, 6, 9
    t = T(SX,SY,SZ); rnd = random.Random(9)
    for x in range(SX):
        for z in range(SZ): t.set(x,0,z,"podzol" if (x+z)%3 else "coarse_dirt")
    for x in range(1,SX-1):
        for z in range(1,6):
            if x == 5: continue
            r = rnd.random()
            if r < 0.30: t.set(x,1,z,"pumpkin")
            elif r < 0.45: t.set(x,1,z,"jack_o_lantern",facing=rnd.choice(["north","south","east","west"]))
            elif r < 0.55: t.set(x,1,z,"hay_block",axis="y")
    t.set(5,1,2,"hay_block",axis="y"); t.set(5,2,2,"hay_block",axis="y")
    t.set(5,3,2,"carved_pumpkin",facing="south")
    t.set(4,2,2,"crimson_fence"); t.set(6,2,2,"crimson_fence")
    for z in range(3,SZ): t.set(5,0,z,"dirt_path")
    for (x,z) in [(0,SZ-2),(SX-1,SZ-2)]:
        t.set(x,1,z,"crimson_fence"); t.set(x,2,z,"crimson_fence"); lantern(t,x,3,z)
    t.jigsaw(5,0,SZ-1,"south_up",ENTR,ENTR,"minecraft:empty","minecraft:dirt_path")
    return t

def street_straight():
    t = T(13,4,3,air=False)
    for x in range(13):
        for z in range(3): t.set(x,0,z,"dirt_path" if z==1 or x%3 else "coarse_dirt")
    for (x,z) in [(2,0),(10,2)]:
        t.set(x,1,z,"crimson_fence"); t.set(x,2,z,"crimson_fence"); lantern(t,x,3,z)
    t.set(8,1,0,"jack_o_lantern",facing="south"); t.set(4,1,2,"carved_pumpkin",facing="north")
    t.jigsaw(0,0,1,"west_up",*STREET,"minecraft:dirt_path")
    t.jigsaw(12,0,1,"east_up",*STREET,"minecraft:dirt_path")
    t.jigsaw(6,0,0,"north_up",ENTR,ENTR,"spookycraft:town/houses","minecraft:dirt_path")
    t.jigsaw(6,0,2,"south_up",ENTR,ENTR,"spookycraft:town/houses","minecraft:dirt_path")
    return t

def street_crossing():
    t = T(3,3,3,air=False)
    for x in range(3):
        for z in range(3): t.set(x,0,z,"dirt_path")
    t.set(1,1,1,"crimson_fence"); lantern(t,1,2,1,soul=True)
    t.jigsaw(1,0,0,"north_up",*STREET,"minecraft:dirt_path")
    t.jigsaw(1,0,2,"south_up",*STREET,"minecraft:dirt_path")
    t.jigsaw(0,0,1,"west_up",*STREET,"minecraft:dirt_path")
    t.jigsaw(2,0,1,"east_up",*STREET,"minecraft:dirt_path")
    return t

def street_end():
    t = T(3,4,3,air=False)
    for x in range(3):
        for z in range(3): t.set(x,0,z,"dirt_path")
    t.set(2,1,1,"crimson_fence"); t.set(2,2,1,"crimson_fence"); t.set(2,3,1,"jack_o_lantern",facing="west")
    t.jigsaw(0,0,1,"west_up","minecraft:street","minecraft:street","minecraft:empty","minecraft:dirt_path")
    return t

CASTLE_J = "spookycraft:castle"; CHURCH_J = "spookycraft:church"

def town_center():
    S = 15
    t = T(S,7,S); rnd = random.Random(3)
    for x in range(S):
        for z in range(S):
            edge = x in (0,S-1) or z in (0,S-1)
            c = "blackstone" if (x+z)%2==0 else "polished_blackstone_bricks"
            t.set(x,0,z,"dirt_path" if edge else c)
    for x in range(6,9):
        for z in range(6,9):
            t.set(x,1,z,"pumpkin"); t.set(x,2,z,"pumpkin")
    for (x,z,f) in [(7,6,"north"),(7,8,"south"),(6,7,"west"),(8,7,"east")]:
        t.set(x,1,z,"jack_o_lantern",facing=f); t.set(x,2,z,"jack_o_lantern",facing=f)
    t.set(7,3,7,"warped_stem",axis="y"); t.set(7,4,7,"warped_stem",axis="y")
    for (x,z) in [(6,6),(8,8),(6,8),(8,6)]: candle(t,x,3,z,4)
    for (x,z) in [(4,4),(10,4),(4,10),(10,10)]:
        t.set(x,1,z,"soul_campfire",facing="north",lit="true",signal_fire="false",waterlogged="false")
    for (x,z) in [(2,2),(12,2),(2,12),(12,12)]:
        for y in (1,2,3): t.set(x,y,z,"crimson_fence")
        lantern(t,x,4,z)
    for (x,z,f) in [(3,7,"east"),(11,7,"west")]:
        t.set(x,1,z,"hay_block",axis="y"); t.set(x,2,z,"hay_block",axis="y"); t.set(x,3,z,"carved_pumpkin",facing=f)
    for (x,z) in [(2,6),(2,8),(12,6),(12,8),(6,12),(8,12),(6,2),(8,2)]:
        t.set(x,1,z,rnd.choice(["pumpkin","jack_o_lantern"]) , **({"facing":"south"} if False else {}))
    for (x,z) in [(5,2),(9,12),(2,10),(12,4)]: t.set(x,1,z,"cobweb")
    # streets west, east, south; castle to the north; church to the north-west corner
    t.jigsaw(7,0,S-1,"south_up",*STREET,"minecraft:dirt_path")
    t.jigsaw(0,0,7,"west_up",*STREET,"minecraft:dirt_path")
    t.jigsaw(S-1,0,7,"east_up",*STREET,"minecraft:dirt_path")
    t.jigsaw(7,0,0,"north_up",CASTLE_J,CASTLE_J,"spookycraft:town/castles","minecraft:dirt_path")
    t.jigsaw(0,0,1,"west_up",CHURCH_J,CHURCH_J,"spookycraft:town/churches","minecraft:dirt_path")
    return t

# ----------------------------------------------------------------------- church (1 per town)
def church():
    SX, SY, SZ = 17, 19, 9
    t = T(SX,SY,SZ); rnd = random.Random(21)
    cz = 4
    DB, PB = "deepslate_bricks", "polished_blackstone_bricks"
    for x in range(SX):
        for z in range(SZ): t.set(x,0,z,"podzol" if rnd.random()<0.6 else "coarse_dirt")
    for x in range(1,16):
        for z in range(1,8): t.set(x,0,z,"dark_oak_planks")
    t.set(0,0,cz,"dirt_path")
    # tower (x1..5, z2..6) and nave (x5..15, z1..7)
    def walls(x0,x1,z0,z1,top):
        for y in range(1,top+1):
            for x in range(x0,x1+1):
                for z in range(z0,z1+1):
                    if x in (x0,x1) or z in (z0,z1):
                        t.set(x,y,z, PB if y == 1 else DB)
    walls(1,5,2,6,13); walls(5,15,1,7,7)
    for x in range(2,5):
        for z in range(3,6): t.set(x,13,z,"dark_oak_planks")
    for x in range(1,6):
        for z in (2,6): t.set(x,13,z,PB)
    for z in range(2,7):
        for x in (1,5): t.set(x,13,z,PB)
    # arch between tower and nave
    for y in (1,2,3):
        for z in (3,4,5): t.set(5,y,z,"air")
    t.set(5,4,4,"air")
    # door + doorbell
    for half,y in (("lower",1),("upper",2)):
        t.set(1,y,cz,"dark_oak_door",facing="east",half=half,hinge="left",open="false",powered="false")
    t.set(0,2,cz+1,"spookycraft:doorbell",facing="west")
    t.set(0,1,2,"jack_o_lantern",facing="west"); t.set(0,1,6,"jack_o_lantern",facing="west")
    lantern(t,0,3,cz-1,hanging=False)
    # tower windows, bell
    for y in (8,9):
        t.set(3,y,2,"purple_stained_glass_pane"); t.set(3,y,6,"purple_stained_glass_pane")
        t.set(1,y,cz,"orange_stained_glass_pane")
    t.set(3,12,4,"bell",facing="north",attachment="ceiling",powered="false")
    # nave: buttresses, windows
    for x in (7,9,11,13):
        for z in (0,8):
            for y in range(1,6): t.set(x,y,z,DB)
            slab(t,x,6,z,"deepslate_brick_slab")
    for i,x in enumerate((8,10,12,14)):
        for y in (3,4,5):
            for z in (1,7): t.set(x,y,z,"purple_stained_glass_pane" if i%2==0 else "orange_stained_glass_pane")
    for y in (3,4,5,6):
        t.set(15,y,3,"purple_stained_glass_pane"); t.set(15,y,5,"purple_stained_glass_pane")
        t.set(15,y,4,"orange_stained_glass_pane")
    # roof
    pyramid_roof(t, 0, 6, 1, 7, 14, "deepslate_tile_stairs", "deepslate_tiles", cap=("lantern", {"hanging":"false","waterlogged":"false"}))
    gable_roof(t, 6, 16, 0, 8, 7, "deepslate_tile_stairs", "deepslate_tile_slab", DB, (15,))
    # interior
    for x in range(6,14): t.set(x,1,4,"purple_carpet")
    for x in (7,9,11):
        for z in (2,3,5,6): stairs(t,x,1,z,"dark_oak_stairs","west")
    for z in (3,4,5): t.set(14,1,z,PB)
    candle(t,14,2,3,3); candle(t,14,2,5,3)
    t.set(14,2,4,"lectern",facing="west",has_book="false",powered="false")
    t.chest(14,1,2,"west",STRUCT_LOOT); t.chest(14,1,6,"west",STRUCT_LOOT)
    lantern(t,8,10,4,hanging=True,soul=True); lantern(t,12,10,4,hanging=True,soul=True)
    for (x,y,z) in [(6,6,2),(6,6,6),(14,6,2),(14,6,6),(3,12,3)]: t.set(x,y,z,"cobweb")
    t.villager(10,1,4)
    t.jigsaw(0,0,cz,"west_up",CHURCH_J,CHURCH_J,"minecraft:empty","minecraft:dirt_path")
    return t

# ----------------------------------------------------------------------- castle (1 per town)
def castle():
    SX, SY, SZ = 15, 20, 16
    t = T(SX,SY,SZ); rnd = random.Random(33)
    DB, PB = "deepslate_bricks", "polished_blackstone_bricks"
    for x in range(SX):
        for z in range(SZ): t.set(x,0,z,PB if (x+z)%2 else "blackstone")
    for z in range(10,16):
        for x in (7,): t.set(x,0,z,"dirt_path")
    t.set(7,0,11,"dirt_path")
    # curtain walls
    for y in range(1,9):
        for x in range(SX):
            for z in (0,14): t.set(x,y,z, PB if y%4 else DB)
        for z in range(15):
            for x in (0,14): t.set(x,y,z, PB if y%4 else DB)
    for x in range(SX):
        for z in (0,14):
            if (x+z)%2 == 0: t.set(x,9,z,DB)
    for z in range(15):
        for x in (0,14):
            if (x+z)%2 == 0: t.set(x,9,z,DB)
    # corner towers 3x3
    for (tx,tz) in [(0,0),(12,0),(0,12),(12,12)]:
        for y in range(1,13):
            for x in range(tx,tx+3):
                for z in range(tz,tz+3):
                    if not (x == tx+1 and z == tz+1): t.set(x,y,z, DB)
        t.set(tx+1,12,tz+1,DB)
        ox = tx if tx == 0 else tx+2; oz = tz if tz == 0 else tz+2
        for y in (5,6): t.set(tx+1,y,oz,"iron_bars"); t.set(ox,y,tz+1,"iron_bars")
        pyramid_roof(t, tx, tx+2, tz, tz+2, 13, "deepslate_tile_stairs", "deepslate_tiles",
                     cap=("soul_lantern", {"hanging":"false","waterlogged":"false"}))
    # gate with a raised portcullis
    for y in range(1,5):
        for x in (6,7,8): t.set(x,y,14,"air")
    for x in (6,7,8): t.set(x,4,14,"iron_bars")
    for y in (6,7): t.set(7,y,14,"purple_stained_glass_pane")
    lantern(t,5,4,15,hanging=False); lantern(t,9,4,15,hanging=False)
    t.set(5,1,15,"crimson_fence"); t.set(5,2,15,"crimson_fence"); t.set(5,3,15,"crimson_fence")
    t.set(9,1,15,"crimson_fence"); t.set(9,2,15,"crimson_fence"); t.set(9,3,15,"crimson_fence")
    # keep x4..10, z5..11, wall height 8
    for y in range(1,9):
        for x in range(4,11):
            for z in range(5,12):
                if x in (4,10) or z in (5,11): t.set(x,y,z, PB if y == 1 else DB)
    for (x,z) in [(4,5),(10,5),(4,11),(10,11)]:
        for y in range(1,9): t.set(x,y,z,PB)
    for x in range(5,10):
        for z in range(6,11): t.set(x,0,z,"dark_oak_planks")
    for x in range(4,11):
        for z in (5,11): t.set(x,8,z,PB)
    for z in range(6,11):
        for x in (4,10): t.set(x,8,z,PB)
    for x in range(5,10):
        for z in range(6,11): t.set(x,8,z,"dark_oak_planks")
    for half,y in (("lower",1),("upper",2)):
        t.set(7,y,11,"crimson_door",facing="north",half=half,hinge="left",open="false",powered="false")
    t.set(8,2,12,"spookycraft:doorbell",facing="south")
    for y in (4,5):
        for z in (6,8,10): t.set(4,y,z,"purple_stained_glass_pane"); t.set(10,y,z,"purple_stained_glass_pane")
        for x in (6,8): t.set(x,y,5,"orange_stained_glass_pane")
    gable_roof(t, 3, 11, 4, 12, 8, "deepslate_tile_stairs", "deepslate_tile_slab", DB, (4,10))
    # throne room
    for z in range(8,11): t.set(7,1,z,"purple_carpet")
    stairs(t,7,1,7,"deepslate_brick_stairs","south")
    for x in (6,8):
        t.set(x,1,7,"polished_blackstone_brick_wall"); candle(t,x,2,7,4)
    t.chest(5,1,6,"east",STRUCT_LOOT); t.chest(9,1,6,"west",STRUCT_LOOT)
    lantern(t,7,7,8,hanging=True,soul=True)
    for (x,z) in [(5,6),(9,10),(5,10)]: t.set(x,6,z,"cobweb")
    t.villager(6,1,9); t.villager(8,1,9)
    # courtyard
    for (x,z) in [(2,6),(2,9),(12,6),(12,9),(3,13),(11,13)]:
        t.set(x,1,z,"jack_o_lantern",facing="south")
    for (x,z) in [(2,3),(12,3)]:
        t.set(x,1,z,"hay_block",axis="y"); t.set(x,2,z,"carved_pumpkin",facing="south")
    for (x,z) in [(3,4),(11,4)]: t.set(x,1,z,"soul_campfire",facing="north",lit="true",signal_fire="false",waterlogged="false")
    t.jigsaw(7,0,15,"south_up",CASTLE_J,CASTLE_J,"minecraft:empty","minecraft:dirt_path")
    return t

# ----------------------------------------------------------------------- standalone structures
def haunted_mansion():
    def extra(t, L):
        bx,bz,fz,W,D,H = L["bx"],L["bz"],L["fz"],L["W"],L["D"],L["H"]
        t.chest(bx+2,1,bz+D//2+1,"east",STRUCT_LOOT)
        for (x,z) in [(bx+3,bz+2),(bx+W-4,bz+2),(bx+W//2,fz-2)]:
            t.set(x,1,z,"crimson_fence"); candle(t,x,2,z,4)
        for (x,y,z) in [(bx+2,3,bz+2),(bx+W-3,3,bz+3),(bx+5,2,bz+4),(bx+8,5,bz+2)]:
            if t.get(x,y,z) is None: t.set(x,y,z,"cobweb")
        bed(t, bx+W-3, 1, bz+D-3, GHOST_BED, "north")
    return house(13,11,8,"deepslate_bricks","polished_blackstone_bricks","polished_blackstone_bricks",
                 "deepslate_tile_stairs","deepslate_tile_slab","polished_blackstone_bricks",FRANK_BED,
                 [], floors=2, door="dark_oak_door", pillars=True, extra=extra, seed=8, jig=False, loot=STRUCT_LOOT)

def large_graveyard():
    SX, SY, SZ = 21, 9, 15
    t = T(SX,SY,SZ); rnd = random.Random(14)
    for x in range(SX):
        for z in range(SZ): t.set(x,0,z,"podzol" if rnd.random()<0.55 else "coarse_dirt")
    for x in range(SX):
        for z in (0,SZ-1):
            if not (z == SZ-1 and x in (9,10,11)): t.set(x,1,z,"nether_brick_fence")
    for z in range(SZ):
        for x in (0,SX-1): t.set(x,1,z,"nether_brick_fence")
    for (x,z) in [(0,0),(SX-1,0),(0,SZ-1),(SX-1,SZ-1),(9,SZ-1),(11,SZ-1)]:
        t.set(x,2,z,"nether_brick_fence"); lantern(t,x,3,z,soul=True)
    for z in range(7,SZ): t.set(10,0,z,"dirt_path")
    for row,z in enumerate((8,11)):
        for x in range(2,19,3):
            if x in (9,10,11): continue
            t.set(x,1,z,"polished_blackstone_brick_wall"); slab(t,x,2,z,"polished_blackstone_brick_slab")
            if rnd.random()<0.35: t.set(x,1,z+1,"cobweb")
    for (x,z) in [(3,3),(17,3)]:
        for y in range(1,6): t.set(x,y,z,"stripped_dark_oak_log",axis="y")
        t.set(x+1,4,z,"stripped_dark_oak_log",axis="x"); t.set(x-1,5,z,"stripped_dark_oak_log",axis="x")
        t.set(x,4,z+1,"stripped_dark_oak_log",axis="z"); t.set(x,6,z-1,"stripped_dark_oak_log",axis="z")
    # mausoleum x8..12, z1..5
    for y in range(1,6):
        for x in range(8,13):
            for z in range(1,6):
                if x in (8,12) or z in (1,5): t.set(x,y,z,"stone_bricks" if rnd.random()<.7 else "mossy_stone_bricks")
    for x in range(7,14):
        for z in range(0,7): slab(t,x,6,z,"stone_brick_slab")
    for y in (1,2,3):
        t.set(10,y,5,"air")
    t.set(10,4,5,"stone_brick_stairs",facing="south",half="top",shape="straight",waterlogged="false")
    t.chest(10,1,3,"south",STRUCT_LOOT)
    t.set(9,1,2,"polished_blackstone_brick_wall"); candle(t,9,2,2,4)
    t.set(11,1,2,"polished_blackstone_brick_wall"); candle(t,11,2,2,4)
    t.set(9,5,3,"cobweb"); t.set(11,5,3,"cobweb")
    t.set(10,1,6,"jack_o_lantern",facing="south")
    for (x,z) in [(5,6),(15,6),(5,13),(15,13)]: t.set(x,1,z,"jack_o_lantern",facing="south")
    return t

def swamp_hut():
    SX, SY, SZ = 11, 15, 14
    t = T(SX,SY,SZ); rnd = random.Random(17)
    for (x,z) in [(2,2),(8,2),(2,8),(8,8)]:
        for y in range(0,5): t.set(x,y,z,"warped_stem",axis="y")
    for x in range(2,9):
        for z in range(2,10): t.set(x,4,z,"spruce_planks")
    for y in range(5,9):
        for x in range(2,9):
            for z in range(2,9):
                if x in (2,8) or z in (2,8): t.set(x,y,z,"warped_planks")
    for (x,z) in [(2,2),(8,2),(2,8),(8,8)]:
        for y in range(5,9): t.set(x,y,z,"stripped_warped_stem",axis="y")
    for x in range(3,8):
        for z in range(3,8): t.set(x,8,z,"spruce_planks")
    for half,y in (("lower",5),("upper",6)):
        t.set(5,y,8,"warped_door",facing="north",half=half,hinge="left",open="false",powered="false")
    t.set(6,6,9,"spookycraft:doorbell",facing="south")
    for y in (6,7):
        t.set(2,y,5,"purple_stained_glass_pane"); t.set(8,y,5,"purple_stained_glass_pane"); t.set(5,y,2,"purple_stained_glass_pane")
    for x in range(2,9):
        if x != 5: t.set(x,5,9,"crimson_fence")
    t.set(2,5,9,"crimson_fence"); t.set(8,5,9,"crimson_fence")
    for i,(y,z) in enumerate([(1,13),(2,12),(3,11),(4,10)]):
        stairs(t,5,y,z,"spruce_stairs","north")
    gable_roof(t, 1, 9, 1, 9, 8, "crimson_stairs", "crimson_slab", "warped_planks", (2,8))
    t.set(7,5,3,"cauldron"); t.set(6,5,3,"brewing_stand"); t.set(3,5,3,"crafting_table")
    t.chest(3,5,4,"east",STRUCT_LOOT)
    bed(t, 7, 5, 7, WITCH_BED, "north")
    for (x,y,z) in [(3,7,3),(7,7,3),(3,7,7),(5,7,5)]: t.set(x,y,z,"cobweb")
    candle(t,5,5,3,3)
    lantern(t,5,7,5,hanging=True,soul=True)
    t.set(3,5,7,"jack_o_lantern",facing="east")
    t.set(1,1,1,"red_mushroom"); t.set(9,1,11,"brown_mushroom")
    return t

def pumpkin_farm():
    SX, SY, SZ = 17, 10, 19
    t = T(SX,SY,SZ); rnd = random.Random(23)
    for x in range(SX):
        for z in range(SZ): t.set(x,0,z,"podzol" if (x*3+z)%5 else "coarse_dirt")
    # barn x4..12, z1..7
    for y in range(1,6):
        for x in range(4,13):
            for z in range(1,8):
                if x in (4,12) or z in (1,7): t.set(x,y,z,"crimson_planks" if y > 1 else "polished_blackstone_bricks")
    for (x,z) in [(4,1),(12,1),(4,7),(12,7)]:
        for y in range(1,6): t.set(x,y,z,"stripped_crimson_stem",axis="y")
    for half,y in (("lower",1),("upper",2)):
        t.set(8,y,7,"crimson_door",facing="north",half=half,hinge="left",open="false",powered="false")
    t.set(9,2,8,"spookycraft:doorbell",facing="south")
    for x in range(5,12):
        for z in range(2,7): t.set(x,0,z,"dark_oak_planks")
    for y in (3,):
        for x in (6,10): t.set(x,y,7,"orange_stained_glass_pane")
        for z in (3,5): t.set(4,y,z,"orange_stained_glass_pane"); t.set(12,y,z,"orange_stained_glass_pane")
    gable_roof(t, 3, 13, 0, 8, 5, "blackstone_stairs", "blackstone_slab", "crimson_planks", (4,12))
    for (x,z) in [(5,2),(5,3),(6,2),(11,2),(11,3),(10,2)]:
        t.set(x,1,z,"hay_block",axis="y")
        if rnd.random()<.6: t.set(x,2,z,"hay_block",axis="y")
    t.chest(11,1,5,"west",STRUCT_LOOT); t.chest(5,1,5,"east",STRUCT_LOOT)
    lantern(t,8,4,4,hanging=True)
    t.set(6,4,2,"cobweb"); t.set(10,4,2,"cobweb")
    # field x1..15, z10..17 with fence
    for x in range(0,SX):
        for z in (9,SZ-1):
            if not (z == 9 and x in (7,8,9)): t.set(x,1,z,"crimson_fence")
    for z in range(9,SZ):
        for x in (0,SX-1): t.set(x,1,z,"crimson_fence")
    for x in range(1,SX-1):
        for z in range(10,SZ-1):
            if x in (8,): t.set(x,0,z,"dirt_path"); continue
            r = rnd.random()
            if r < .38: t.set(x,1,z,"pumpkin")
            elif r < .5: t.set(x,1,z,"jack_o_lantern",facing=rnd.choice(["north","south","east","west"]))
            elif r < .56: t.set(x,1,z,"hay_block",axis="y")
    for (x,z,f) in [(4,13,"south"),(12,13,"south"),(8,16,"north")]:
        t.set(x,1,z,"hay_block",axis="y"); t.set(x,2,z,"hay_block",axis="y"); t.set(x,3,z,"carved_pumpkin",facing=f)
        t.set(x-1,2,z,"crimson_fence"); t.set(x+1,2,z,"crimson_fence")
    for (x,z) in [(0,9),(SX-1,9),(0,SZ-1),(SX-1,SZ-1)]:
        t.set(x,2,z,"crimson_fence"); lantern(t,x,3,z)
    return t

def spooky_tower():
    SX, SY, SZ = 11, 30, 11
    t = T(SX,SY,SZ); rnd = random.Random(29)
    DB = "deepslate_bricks"
    for x in range(SX):
        for z in range(SZ): t.set(x,0,z,"podzol" if rnd.random()<.6 else "coarse_dirt")
    for y in range(1,21):
        for x in range(2,9):
            for z in range(2,9):
                if x in (2,8) or z in (2,8):
                    t.set(x,y,z,"polished_blackstone_bricks" if y==1 else (DB if rnd.random()>.1 or y<10 else "cracked_deepslate_bricks"))
    for x in range(3,8):
        for z in range(3,8):
            t.set(x,0,z,"dark_oak_planks")
    for fy in (7,13,19):
        for x in range(3,8):
            for z in range(3,8):
                if not (x == 3 and z == 3): t.set(x,fy,z,"dark_oak_planks")
    for y in range(1,20):
        t.set(3,y,3,"ladder",facing="east",waterlogged="false")
    for y in (4,5,10,11,16,17):
        for (x,z) in [(5,2),(5,8),(2,5),(8,5)]: t.set(x,y,z,"purple_stained_glass_pane")
    for half,y in (("lower",1),("upper",2)):
        t.set(5,y,8,"dark_oak_door",facing="north",half=half,hinge="left",open="false",powered="false")
    t.set(6,2,9,"spookycraft:doorbell",facing="south")
    for x in range(2,9):
        for z in (2,8): t.set(x,21,z,DB if (x+z)%2 else "polished_blackstone_bricks")
    for z in range(2,9):
        for x in (2,8): t.set(x,21,z,DB if (x+z)%2 else "polished_blackstone_bricks")
    pyramid_roof(t, 1, 9, 1, 9, 22, "deepslate_tile_stairs", "deepslate_tiles", cap=("soul_lantern", {"hanging":"false","waterlogged":"false"}))
    t.chest(7,8,7,"north",STRUCT_LOOT); t.chest(7,14,4,"west",STRUCT_LOOT); t.chest(6,20,6,"north",STRUCT_LOOT)
    for (x,y,z) in [(4,6,4),(7,6,7),(4,12,7),(7,18,3),(4,18,7),(6,12,3)]: t.set(x,y,z,"cobweb")
    for fy in (8,14,20):
        candle(t,4,fy,7,3); t.set(7,fy,4 if fy != 14 else 6,"jack_o_lantern",facing="west")
    t.set(1,1,9,"jack_o_lantern",facing="south"); t.set(9,1,9,"jack_o_lantern",facing="south")
    return t

pieces.update({
    "decor_graveyard": graveyard(), "decor_pumpkin_patch": pumpkin_patch(),
    "street_straight": street_straight(), "street_crossing": street_crossing(), "street_end": street_end(),
    "town_center": town_center(), "church": church(), "castle": castle(),
    "haunted_mansion": haunted_mansion(), "large_graveyard": large_graveyard(), "swamp_hut": swamp_hut(),
    "pumpkin_farm": pumpkin_farm(), "spooky_tower": spooky_tower(),
})

for name,t in pieces.items():
    nb, npal = t.save(DATA + f"structures/town/{name}.nbt")
    back = loads(open(DATA + f"structures/town/{name}.nbt","rb").read())
    assert back["size"] == list(t.size) and len(back["blocks"]) == nb
    chests = sum(1 for v in t.b.values() if v[0]=="minecraft:chest")
    print(f"{name:20s} size={t.size} blocks={nb:5d} palette={npal:3d} entities={len(t.entities)} chests={chests}")

# ----------------------------------------------------------------------- worldgen JSON
def wj(path, obj):
    os.makedirs(os.path.dirname(DATA+path), exist_ok=True)
    json.dump(obj, open(DATA+path,"w"), indent=2)

def el(loc, weight, proj="rigid"):
    return {"weight": weight, "element": {"element_type":"minecraft:legacy_single_pool_element",
            "location": "spookycraft:town/"+loc, "processors":"minecraft:empty", "projection": proj}}

wj("worldgen/template_pool/town/town_centers.json", {"name":"spookycraft:town/town_centers","fallback":"minecraft:empty","elements":[el("town_center",1)]})
wj("worldgen/template_pool/town/streets.json", {"name":"spookycraft:town/streets","fallback":"spookycraft:town/terminators",
    "elements":[el("street_straight",6,"terrain_matching"), el("street_crossing",1,"terrain_matching")]})
wj("worldgen/template_pool/town/terminators.json", {"name":"spookycraft:town/terminators","fallback":"minecraft:empty","elements":[el("street_end",1,"terrain_matching")]})
wj("worldgen/template_pool/town/houses.json", {"name":"spookycraft:town/houses","fallback":"minecraft:empty",
    "elements":[el("house_crimson",3), el("house_warped",3), el("house_tower",2), el("house_mansion",1),
                el("house_witch",2), el("decor_graveyard",1), el("decor_pumpkin_patch",2)]})
wj("worldgen/template_pool/town/castles.json", {"name":"spookycraft:town/castles","fallback":"minecraft:empty","elements":[el("castle",1)]})
wj("worldgen/template_pool/town/churches.json", {"name":"spookycraft:town/churches","fallback":"minecraft:empty","elements":[el("church",1)]})

wj("worldgen/structure/trick_or_treat_town.json", {
    "type":"minecraft:jigsaw","biomes":"#spookycraft:has_structure/trick_or_treat_town","step":"surface_structures",
    "terrain_adaptation":"beard_thin","spawn_overrides":{},"start_pool":"spookycraft:town/town_centers","size":6,
    "start_height":{"absolute":0},"project_start_to_heightmap":"WORLD_SURFACE_WG","max_distance_from_center":80,"use_expansion_hack":True})
wj("worldgen/structure_set/trick_or_treat_towns.json", {"structures":[{"structure":"spookycraft:trick_or_treat_town","weight":1}],
    "placement":{"type":"minecraft:random_spread","spacing":20,"separation":8,"salt":1307719234}})
LAND = ["minecraft:plains","minecraft:sunflower_plains","minecraft:meadow","minecraft:forest","minecraft:flower_forest",
        "minecraft:birch_forest","minecraft:dark_forest","minecraft:taiga","minecraft:snowy_plains","minecraft:savanna"]
wj("tags/worldgen/biome/has_structure/trick_or_treat_town.json", {"values": LAND})
wj("tags/worldgen/biome/has_structure/halloween_land.json", {"values": LAND + ["minecraft:old_growth_pine_taiga","minecraft:snowy_taiga"]})
wj("tags/worldgen/biome/has_structure/halloween_swamp.json", {"values": ["minecraft:swamp","minecraft:mangrove_swamp"]})
wj("tags/worldgen/structure/trick_or_treat_town.json", {"values":["spookycraft:trick_or_treat_town"]})

standalone = [  # name, template, biome tag, spacing, separation, salt
    ("haunted_mansion","haunted_mansion","halloween_land",40,14,873110247),
    ("large_graveyard","large_graveyard","halloween_land",28,10,873110248),
    ("pumpkin_farm","pumpkin_farm","halloween_land",30,10,873110249),
    ("spooky_tower","spooky_tower","halloween_land",36,12,873110250),
    ("witch_swamp_hut","swamp_hut","halloween_swamp",32,10,873110251),
]
for name, tmpl, tag, spacing, sep, salt in standalone:
    wj(f"worldgen/template_pool/standalone/{name}.json", {"name":f"spookycraft:standalone/{name}","fallback":"minecraft:empty",
        "elements":[{"weight":1,"element":{"element_type":"minecraft:legacy_single_pool_element","location":f"spookycraft:town/{tmpl}",
                     "processors":"minecraft:empty","projection":"rigid"}}]})
    wj(f"worldgen/structure/{name}.json", {"type":"minecraft:jigsaw","biomes":f"#spookycraft:has_structure/{tag}","step":"surface_structures",
        "terrain_adaptation":"beard_thin","spawn_overrides":{},"start_pool":f"spookycraft:standalone/{name}","size":1,
        "start_height":{"absolute":0},"project_start_to_heightmap":"WORLD_SURFACE_WG","max_distance_from_center":80,"use_expansion_hack":False})
    wj(f"worldgen/structure_set/{name}.json", {"structures":[{"structure":f"spookycraft:{name}","weight":1}],
        "placement":{"type":"minecraft:random_spread","spacing":spacing,"separation":sep,"salt":salt}})
print("worldgen json ok")
