from PIL import Image, ImageDraw
import random, math, os

RES = "/home/claude/SpookyCraft/src/main/resources/assets/spookycraft/textures/"
def C(h, a=255):
    h = h.lstrip('#'); return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), a)
def shade(c, k): return (max(0,min(255,int(c[0]*k))), max(0,min(255,int(c[1]*k))), max(0,min(255,int(c[2]*k))), 255)

K=C("1e0a37"); P1=C("58229a"); P2=C("8c46d2"); P3=C("b46ef0"); O1=C("e66e14"); O2=C("ffa032"); O3=C("ffd778"); WH=C("fff5cd")
H1=C("5c3c1e"); H2=C("8c6234")

def new(): return Image.new("RGBA",(16,16),(0,0,0,0))
def put(im, pts, col):
    for (x,y) in pts:
        if 0 <= x < 16 and 0 <= y < 16: im.putpixel((x,y), col)
def outline(im, col=K):
    px = im.load(); src = [(x,y) for y in range(16) for x in range(16) if px[x,y][3] > 0]
    s = set(src)
    for (x,y) in src:
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
            nx,ny = x+dx,y+dy
            if 0<=nx<16 and 0<=ny<16 and (nx,ny) not in s: px[nx,ny] = col
    return im
def save(im, rel): os.makedirs(os.path.dirname(RES+rel), exist_ok=True); im.save(RES+rel)
def rect(im,x0,y0,x1,y1,col):
    for y in range(y0,y1+1):
        for x in range(x0,x1+1): im.putpixel((x,y),col)

# ---------------------------------------------------------------- hallowite items
def handle(im, n=9):
    for i in range(n):
        put(im, [(3+i, 13-i)], H2 if i%2 else H1)

def sword():
    im = new()
    for i in range(2,11):
        put(im,[(4+i,11-i)],P2); 
        if i<10: put(im,[(5+i,11-i)],P1)
        if i>2: put(im,[(4+i,10-i)],O3 if i%2 else WH)
    put(im,[(15,0)],P2)
    put(im,[(3+j,8+j) for j in range(5)],O2); put(im,[(4+j,8+j) for j in range(4)],O1)
    put(im,[(4,11),(3,12),(2,13)],H1); put(im,[(1,14)],O2)
    return outline(im)
def pickaxe():
    im = new(); handle(im,9)
    put(im,[(5,3),(6,2),(7,2),(8,2),(9,2),(10,2),(11,3),(12,4),(13,5),(13,6),(14,7)],P2)
    put(im,[(6,3),(7,3),(8,3),(9,3),(10,3),(11,4),(12,5),(12,6),(13,7)],P1)
    put(im,[(7,2),(8,2),(9,2)],O3); put(im,[(5,4),(14,8)],P1)
    return outline(im)
def axe():
    im = new(); handle(im,9)
    rows = {2:(8,11),3:(7,12),4:(7,13),5:(8,13),6:(9,12)}
    for y,(a,b) in rows.items():
        for x in range(a,b+1): put(im,[(x,y)],P2 if y<5 else P1)
    put(im,[(13,4),(13,5),(12,3),(12,6)],O3); put(im,[(8,2),(9,2),(10,2)],P3)
    return outline(im)
def shovel():
    im = new(); handle(im,8)
    for y in range(16):
        for x in range(16):
            if ((x-12)/2.7)**2 + ((y-3)/3.3)**2 <= 1.0: put(im,[(x,y)],P2)
    put(im,[(10,4),(11,5),(13,5),(12,6),(14,3)],P1); put(im,[(11,1),(12,1),(10,2)],O3)
    return outline(im)
def hoe():
    im = new(); handle(im,8)
    put(im,[(x,3) for x in range(8,14)],P2); put(im,[(x,4) for x in range(9,14)],P1)
    put(im,[(8,4),(8,5),(9,5)],P2); put(im,[(9,3),(10,3),(11,3)],O3)
    return outline(im)
def ingot():
    im = new(); d = ImageDraw.Draw(im)
    d.polygon([(3,6),(6,3),(14,3),(11,6)], fill=P3)
    d.rectangle((3,6,11,10), fill=P2)
    d.polygon([(11,6),(14,3),(14,7),(11,10)], fill=P1)
    put(im,[(x,4) for x in range(7,13)],O3); put(im,[(4,7),(5,7),(4,8)],O2); put(im,[(x,10) for x in range(3,12)],P1)
    return outline(im)
def raw():
    im = new(); d = ImageDraw.Draw(im)
    d.polygon([(4,5),(8,3),(12,5),(13,9),(10,12),(5,12),(3,9)], fill=P1)
    d.polygon([(5,6),(8,4),(11,6),(10,9),(6,9)], fill=P2)
    put(im,[(6,6),(9,5),(10,8),(7,10),(11,10),(5,9)],O2); put(im,[(7,7),(9,9)],O3); put(im,[(4,9),(12,7)],P3)
    return outline(im)
def helmet():
    im = new()
    for y,(a,b) in {3:(5,10),4:(4,11),5:(3,12),6:(3,12),7:(3,12)}.items(): rect(im,a,y,b,y,P2)
    for y in (8,9): rect(im,3,y,5,y,P2); rect(im,10,y,12,y,P2)
    rect(im,3,10,4,10,P2); rect(im,11,10,12,10,P2)
    put(im,[(x,7) for x in range(3,13)],P1); rect(im,6,8,9,9,K)
    put(im,[(x,3) for x in range(5,11)],P3); put(im,[(7,4),(8,4)],O2); put(im,[(7,5),(8,5)],O3)
    put(im,[(3,5),(12,5),(3,6),(12,6)],O2)
    return outline(im)
def chestplate():
    im = new()
    rect(im,4,3,11,13,P2); rect(im,1,3,14,5,P2); rect(im,1,6,3,9,P2); rect(im,12,6,14,9,P2)
    rect(im,6,3,9,3,(0,0,0,0)); put(im,[(x,3) for x in range(4,6)],P3); put(im,[(x,3) for x in range(10,12)],P3)
    put(im,[(x,13) for x in range(4,12)],P1); put(im,[(x,9) for x in range(1,4)],P1); put(im,[(x,9) for x in range(12,15)],P1)
    put(im,[(x,10) for x in range(4,12)],O2); rect(im,7,6,8,8,O2); put(im,[(7,7),(8,7)],O3)
    put(im,[(1,5),(14,5),(4,5),(11,5)],O1)
    return outline(im)
def leggings():
    im = new()
    rect(im,3,2,12,5,P2); rect(im,3,6,6,13,P2); rect(im,9,6,12,13,P2)
    put(im,[(x,3) for x in range(3,13)],O2); put(im,[(7,2),(8,2),(7,4),(8,4)],O3)
    put(im,[(x,13) for x in range(3,7)],P1); put(im,[(x,13) for x in range(9,13)],P1)
    put(im,[(x,5) for x in range(3,13)],P1); put(im,[(4,8),(11,8),(4,10),(11,10)],P3)
    return outline(im)
def boots():
    im = new()
    rect(im,3,8,6,10,P2); rect(im,2,11,7,13,P2); rect(im,10,8,13,10,P2); rect(im,8,11,13,13,P2)
    put(im,[(x,8) for x in range(3,7)],O2); put(im,[(x,8) for x in range(10,14)],O2)
    put(im,[(x,13) for x in range(2,8)],P1); put(im,[(x,13) for x in range(8,14)],P1)
    put(im,[(4,11),(11,11)],O3)
    return outline(im)

for name,fn in [("hallowite_sword",sword),("hallowite_pickaxe",pickaxe),("hallowite_axe",axe),("hallowite_shovel",shovel),
                ("hallowite_hoe",hoe),("hallowite_ingot",ingot),("raw_hallowite",raw),("hallowite_helmet",helmet),
                ("hallowite_chestplate",chestplate),("hallowite_leggings",leggings),("hallowite_boots",boots)]:
    save(fn(), f"item/{name}.png")

# ---------------------------------------------------------------- candies
def gummy_bat():
    im = new(); d = ImageDraw.Draw(im); g = C("62d24a"); gd = C("3a9a30")
    d.polygon([(7,6),(1,3),(2,8),(4,7),(5,11),(7,9)], fill=g); d.polygon([(9,6),(15,3),(14,8),(12,7),(11,11),(9,9)], fill=g)
    d.ellipse((6,5,9,11), fill=g); put(im,[(6,4),(9,4),(6,3),(9,3)],g)
    put(im,[(2,5),(3,6),(13,6),(14,5),(4,9),(11,9)],gd); put(im,[(7,7),(8,7)],C("ff3030")); put(im,[(7,9),(8,9)],gd)
    put(im,[(5,5),(10,5)],C("b8ffa8"))
    return outline(im, C("1b4a18"))
def caramel_apple():
    im = new(); d = ImageDraw.Draw(im); red = C("cc2a38"); car = C("b87a28"); card = C("8a5418")
    d.ellipse((3,5,12,14), fill=red); d.ellipse((3,5,12,9), fill=car)
    for x in (4,7,10): put(im,[(x,10),(x,11)],car)
    put(im,[(5,6),(8,7),(10,6),(6,8),(11,8)],card); put(im,[(4,9),(9,9),(11,9)],car)
    put(im,[(5,12),(6,11)],C("ff7a80")); put(im,[(8,1),(8,2),(8,3),(8,4)],H1); put(im,[(9,2)],C("4c8c2c"))
    return outline(im, C("3c1a10"))
def ghost_marshmallow():
    im = new(); d = ImageDraw.Draw(im); w = C("f6f6ff"); ws = C("c8c8e2")
    d.ellipse((3,2,12,10), fill=w); d.rectangle((3,6,12,13), fill=w)
    put(im,[(3,14),(5,14),(7,14),(9,14),(11,14)],w); put(im,[(4,13),(8,13),(11,13)],ws)
    put(im,[(x,12) for x in range(3,13)],ws); put(im,[(5,5),(6,5),(5,6),(6,6),(9,5),(10,5),(9,6),(10,6)],C("1a1a28"))
    put(im,[(7,8),(8,8),(7,9),(8,9)],C("1a1a28")); put(im,[(5,3),(6,3)],WH)
    return outline(im, C("55557a"))
def black_licorice():
    im = new(); blk = C("1c1620"); hl = C("5b4c68")
    pts = []
    for i in range(0, 24):
        t = i/23.0; x = 2 + t*12; y = 8 + math.sin(t*math.pi*2.2)*4.3
        pts.append((round(x), round(y)))
    for (x,y) in pts:
        put(im,[(x,y),(x,y+1)],blk)
    for i,(x,y) in enumerate(pts):
        if i%3==0: put(im,[(x,y)],hl)
    put(im,[(1,pts[0][1]),(14,pts[-1][1])],blk)
    return outline(im, C("08060a"))
def sour_worms():
    im = new()
    def worm(col, light, pts):
        for (x,y) in pts: put(im,[(x,y)],col)
        for i,(x,y) in enumerate(pts):
            if i%2==0: put(im,[(x,y-1 if y>0 else y)],light) if False else None
    g = C("58d040"); o = C("ff9a20")
    put(im,[(2,5),(3,4),(4,4),(5,5),(6,6),(7,6),(8,5),(9,4),(10,4)],g)
    put(im,[(3,5),(4,5),(5,6),(6,7),(7,7),(8,6),(9,5),(10,5)],C("3a9a28"))
    put(im,[(5,10),(6,9),(7,9),(8,10),(9,11),(10,11),(11,10),(12,9),(13,9)],o)
    put(im,[(6,10),(7,10),(8,11),(9,12),(10,12),(11,11),(12,10),(13,10)],C("d46c10"))
    for (x,y) in [(3,3),(8,4),(6,8),(11,9),(5,11),(12,12),(2,6),(10,6)]: put(im,[(x,y)],WH)
    return outline(im, C("2a2a1a"))
def choco_piece():
    im = new(); b = C("6a3a20"); bl = C("8a5232"); bd = C("4a2614")
    rect(im,3,3,12,12,b); 
    for x in (6,9): put(im,[(x,y) for y in range(3,13)],bd)
    for y in (6,9): put(im,[(x,y) for x in range(3,13)],bd)
    put(im,[(4,4),(7,4),(10,4),(4,7),(7,7),(4,10),(10,7)],bl)
    d = ImageDraw.Draw(im); d.ellipse((8,8,12,12), fill=C("d02a34")); put(im,[(10,7)],C("4c8c2c")); put(im,[(9,9)],C("ff8a90"))
    return outline(im, C("2a1409"))
for name,fn in [("gummy_bat",gummy_bat),("caramel_apple",caramel_apple),("ghost_marshmallow",ghost_marshmallow),
                ("black_licorice",black_licorice),("sour_worms",sour_worms),("apple_flavored_chocolate_piece",choco_piece)]:
    save(fn(), f"item/{name}.png")

# ---------------------------------------------------------------- bed icons + bed block textures
BEDS = {
 "pumpkin_bed":     dict(blanket=C("e6781a"), blanket2=C("b85a0c"), pillow=C("fff1d0"), wood=C("5a3a1e")),
 "witch_bed":       dict(blanket=C("6a2fa6"), blanket2=C("46207a"), pillow=C("cdb4ee"), wood=C("32204a")),
 "frankenstein_bed":dict(blanket=C("5e9a50"), blanket2=C("3e6e36"), pillow=C("b4b4be"), wood=C("3c3c46")),
 "ghost_bed":       dict(blanket=C("ececf8"), blanket2=C("bcbcd6"), pillow=C("ffffff"), wood=C("8c8ca4")),
}
for name,p in BEDS.items():
    im = new()
    rect(im,1,9,14,11,p["wood"]); rect(im,1,12,2,14,p["wood"]); rect(im,13,12,14,14,p["wood"])
    rect(im,1,6,14,9,p["blanket"]); rect(im,6,6,14,7,p["blanket2"]); rect(im,2,4,5,6,p["pillow"]); rect(im,1,3,1,9,p["wood"]); rect(im,14,5,14,9,p["wood"])
    if name == "pumpkin_bed":
        d = ImageDraw.Draw(im); d.ellipse((7,2,12,7), fill=C("f09a20")); put(im,[(9,1)],C("4c8c2c")); put(im,[(8,4),(11,4)],C("402008"))
    if name == "witch_bed": put(im,[(8,3),(9,2),(10,3),(9,4),(11,5)],C("111018")); put(im,[(9,3)],C("111018"))
    if name == "frankenstein_bed": put(im,[(1,2),(1,1),(14,2),(14,1)],C("a0a0aa"))
    if name == "ghost_bed": put(im,[(9,4),(11,4),(10,6)],C("1a1a28"))
    save(outline(im, C("1c1220")), f"item/{name}.png")

    # 16x16 bed texture with regions: wood(0,0,4,4) top(4,0,12,8) side(12,0,16,4) black(12,4,16,8) pillow(4,8,12,12) gray(0,4,4,8)
    tx = Image.new("RGBA",(16,16),(0,0,0,255)); r = random.Random(hash(name) & 0xffff)
    def fill(x0,y0,x1,y1,col,noise=0.06):
        for y in range(y0,y1):
            for x in range(x0,x1): tx.putpixel((x,y), shade(col, 1+r.uniform(-noise,noise)))
    fill(0,0,4,4,p["wood"]); fill(0,4,4,8,C("8a8a96")); fill(12,4,16,8,C("121018"),0.02)
    fill(4,0,12,8,p["blanket"]); fill(12,0,16,4,p["blanket2"]); fill(4,8,12,12,p["pillow"],0.04)
    for y in range(8,16): 
        for x in range(0,16):
            if x<4 or x>=12 or y>=12: tx.putpixel((x,y), shade(p["wood"],0.9))
    if name == "pumpkin_bed":
        for x in range(4,12): tx.putpixel((x,3),p["blanket2"]); tx.putpixel((x,6),p["blanket2"])
        for y in range(0,8): tx.putpixel((7,y),p["blanket2"])
    if name == "witch_bed":
        for (x,y) in [(5,1),(10,2),(6,5),(9,6),(11,4)]: tx.putpixel((x,y),C("ffd23f")); tx.putpixel((x+1 if x<11 else x,y),C("ffd23f"))
        for x in range(4,12): tx.putpixel((x,0),C("3aa05a"))
    if name == "frankenstein_bed":
        for x in range(4,12): tx.putpixel((x,3),C("14201a")) if x%2==0 else None
        for y in range(1,8): tx.putpixel((7,y),C("14201a")) if y%2==1 else None
        for (x,y) in [(5,5),(10,2)]: tx.putpixel((x,y),C("a0a0aa"))
    if name == "ghost_bed":
        for (x,y) in [(6,2),(7,2),(9,2),(10,2),(6,3),(10,3)]: tx.putpixel((x,y),C("181828"))
        for (x,y) in [(7,5),(8,5),(7,6),(8,6)]: tx.putpixel((x,y),C("181828"))
    save(tx, f"block/bed_{name.replace('_bed','')}.png")

# ---------------------------------------------------------------- blocks
r = random.Random(5)
# hallowite block: purple tiles with glowing orange cores
tx = Image.new("RGBA",(16,16)); 
for y in range(16):
    for x in range(16):
        base = C("46207a"); c = shade(base, 1+r.uniform(-.12,.12))
        if x%8 in (0,7) or y%8 in (0,7): c = shade(C("2a1050"), 1+r.uniform(-.08,.08))
        elif x%8 in (1,) or y%8 in (1,): c = shade(C("6a35aa"), 1+r.uniform(-.08,.08))
        tx.putpixel((x,y), c)
for (cx,cy) in [(3,3),(11,3),(3,11),(11,11)]:
    for dx in (0,1):
        for dy in (0,1): tx.putpixel((cx+dx,cy+dy), O2)
    tx.putpixel((cx,cy),WH); tx.putpixel((cx+1,cy+1),O1)
save(tx,"block/hallowite_block.png")
# chocolate log
side = Image.new("RGBA",(16,16)); top = Image.new("RGBA",(16,16))
for y in range(16):
    for x in range(16):
        c = shade(C("5a2e1c"), 1+r.uniform(-.08,.08))
        if x%4 == 0: c = shade(C("3e1e12"), 1+r.uniform(-.06,.06))
        if y%8 == 0: c = shade(C("7a4630"), 1)
        if y%8 == 1 and x%4 != 0: c = shade(C("6a3a26"), 1)
        side.putpixel((x,y), c)
for y in range(16):
    for x in range(16):
        d = max(abs(x-7.5), abs(y-7.5))
        c = C("3e1e12") if d > 6.5 else (C("6a3a26") if d > 4.5 else (C("85523a") if d > 2.5 else C("c89066")))
        if d <= 1.5: c = C("f2d9b0")
        top.putpixel((x,y), shade(c,1+r.uniform(-.04,.04)))
save(side,"block/chocolate_log.png"); save(top,"block/chocolate_log_top.png")
# chocolate leaves with apple spots (transparent holes like real leaves)
lv = Image.new("RGBA",(16,16),(0,0,0,0))
for y in range(16):
    for x in range(16):
        if r.random() < 0.82:
            c = shade(C("6a3a22"), 1+r.uniform(-.2,.2))
            if r.random() < .25: c = shade(C("84502e"), 1+r.uniform(-.1,.1))
            lv.putpixel((x,y), c)
for (x,y) in [(3,3),(10,2),(6,9),(12,11),(2,12)]:
    for dx,dy in ((0,0),(1,0),(0,1),(1,1)): lv.putpixel((x+dx,y+dy), C("c62a34"))
    lv.putpixel((x,y), C("ff7078")); lv.putpixel((x+1,y-1 if y>0 else y), C("3c7a2c"))
save(lv,"block/chocolate_leaves.png")

# ---------------------------------------------------------------- hallowite armor (vanilla 64x32 layout)
def armor_box(img, u, v, w, h, d, fn):
    faces = {'top':(u+d, v, w, d), 'bottom':(u+d+w, v, w, d), 'right':(u, v+d, d, h), 'front':(u+d, v+d, w, h),
             'left':(u+d+w, v+d, d, h), 'back':(u+2*d+w, v+d, w, h)}
    for face,(x0,y0,fw,fh) in faces.items():
        for yy in range(fh):
            for xx in range(fw):
                c = fn(face,xx,yy,fw,fh)
                if c is not None: img.putpixel((x0+xx,y0+yy), c)
def metal(face,x,y,w,h):
    c = shade(P2, 1+r.uniform(-.08,.08))
    if (x+y*2) % 7 == 0: c = shade(P1, 1)
    if x == 0 or y == 0: c = shade(P3, 1)
    if y == h-1: c = shade(P1, .9)
    return c
def helm(face,x,y,w,h):
    c = metal(face,x,y,w,h)
    if face == 'front':
        if y == 3 and 0 < x < w-1: c = O2
        if y in (4,5) and 1 < x < w-2: c = K                   # visor slit
        if y == 1 and x in (3,4): c = O3
    if face == 'top' and (x in (3,4) or y in (3,4)): c = O1
    return c
def chest(face,x,y,w,h):
    c = metal(face,x,y,w,h)
    if face == 'front':
        if y in (4,5,6) and x in (3,4): c = O2
        if y == 5 and x in (3,4): c = O3
        if y == 9: c = O1
    return c
def arm(face,x,y,w,h):
    c = metal(face,x,y,w,h)
    if y == 2: c = O2
    return c
def legs(face,x,y,w,h):
    c = metal(face,x,y,w,h)
    if y == 0: c = O2
    return c
def boot(face,x,y,w,h):
    if y < 7: return None
    c = metal(face,x,y,w,h)
    if y == 7: c = O2
    return c
l1 = Image.new("RGBA",(64,32),(0,0,0,0)); l2 = Image.new("RGBA",(64,32),(0,0,0,0))
armor_box(l1,0,0,8,8,8,helm); armor_box(l1,16,16,8,12,4,chest); armor_box(l1,40,16,4,12,4,arm); armor_box(l1,0,16,4,12,4,boot)
armor_box(l2,16,16,8,12,4,lambda f,x,y,w,h: (O2 if y==1 else (O3 if (y==1 and x in (3,4)) else metal(f,x,y,w,h))) )
armor_box(l2,0,16,4,12,4,legs)
d = os.path.join(RES,"models/armor"); os.makedirs(d, exist_ok=True)
l1.save(d+"/hallowite_layer_1.png"); l2.save(d+"/hallowite_layer_2.png")
print("sprites ok")

# contact sheet for a visual check
names = ["item/hallowite_sword","item/hallowite_pickaxe","item/hallowite_axe","item/hallowite_shovel","item/hallowite_hoe","item/hallowite_ingot","item/raw_hallowite",
         "item/hallowite_helmet","item/hallowite_chestplate","item/hallowite_leggings","item/hallowite_boots","item/gummy_bat","item/caramel_apple","item/ghost_marshmallow",
         "item/black_licorice","item/sour_worms","item/apple_flavored_chocolate_piece","item/pumpkin_bed","item/witch_bed","item/frankenstein_bed","item/ghost_bed",
         "block/hallowite_block","block/chocolate_log","block/chocolate_log_top","block/chocolate_leaves"]
sheet = Image.new("RGBA",(8*72,4*72),(70,70,84,255))
for i,n in enumerate(names):
    im = Image.open(RES+n+".png").resize((64,64),Image.NEAREST); sheet.paste(im,((i%8)*72+4,(i//8)*72+4),im)
sheet.save("/home/claude/gen/sprites_sheet.png")
