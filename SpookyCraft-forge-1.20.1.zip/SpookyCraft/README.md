# Urbanion's SpookyCraft (Forge 1.20.1)

Build: upload this zip + build-from-zip.yml to a GitHub repo, rename the yml to `.github/workflows/build.yml`,
then download the jar from Actions -> Artifacts.

## Test commands
- Town: `/locate structure spookycraft:trick_or_treat_town` or `/place structure spookycraft:trick_or_treat_town`
- Other structures: haunted_mansion, large_graveyard, pumpkin_farm, spooky_tower, witch_swamp_hut (same commands, prefix `spookycraft:`)
- Night (trick or treat, werewolf, Big Randy): `/time set 13000`
- Spawn eggs and everything else: creative tab "Urbanion's SpookyCraft"
- Halloween Forest = the Dark Forest biome (renamed + recolored + extra features). Find one with `/locate biome minecraft:dark_forest`
- UI theme off: config/spookycraft-client.toml -> uiTheme = false

`tools/` holds the scripts that generated the textures, models and structure files.
