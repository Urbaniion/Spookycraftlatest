package com.urbanion.spookycraft.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.entity.TrickOrTreatVillager;
import net.minecraft.client.model.VillagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Normal villager model, costume texture picked by the entity's variant. */
public class TrickOrTreatVillagerRenderer
        extends MobRenderer<TrickOrTreatVillager, VillagerModel<TrickOrTreatVillager>> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[TrickOrTreatVillager.VARIANTS];

    static {
        for (int i = 0; i < TEXTURES.length; i++) {
            TEXTURES[i] = new ResourceLocation(SpookyCraft.MODID,
                    "textures/entity/trick_or_treat_villager/costume_" + i + ".png");
        }
    }

    public TrickOrTreatVillagerRenderer(EntityRendererProvider.Context context) {
        super(context, new VillagerModel<>(context.bakeLayer(ModelLayers.VILLAGER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(TrickOrTreatVillager entity) {
        return TEXTURES[entity.getVariant()];
    }

    @Override
    protected void scale(TrickOrTreatVillager entity, PoseStack pose, float partialTick) {
        pose.scale(0.9375F, 0.9375F, 0.9375F);
    }
}
