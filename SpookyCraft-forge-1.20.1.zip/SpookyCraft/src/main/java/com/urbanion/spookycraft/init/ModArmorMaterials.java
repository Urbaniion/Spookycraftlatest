package com.urbanion.spookycraft.init;

import com.urbanion.spookycraft.SpookyCraft;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

/**
 * Masks (helmet only, 2 armor points each) and Hallowite armor (a bit stronger than netherite).
 * Defense array order: helmet, chestplate, leggings, boots.
 */
public enum ModArmorMaterials implements ArmorMaterial {
    DALLAS("mask_dallas", 15, new int[]{2, 0, 0, 0}, 12, 0.0F, 0.0F, null),
    WOLF("mask_wolf", 15, new int[]{2, 0, 0, 0}, 12, 0.0F, 0.0F, null),
    HOUSTON("mask_houston", 15, new int[]{2, 0, 0, 0}, 12, 0.0F, 0.0F, null),
    HOXTON("mask_hoxton", 15, new int[]{2, 0, 0, 0}, 12, 0.0F, 0.0F, null),
    CHAINS("mask_chains", 15, new int[]{2, 0, 0, 0}, 12, 0.0F, 0.0F, null),
    HALLOWITE("hallowite", 40, new int[]{4, 8, 7, 4}, 18, 3.5F, 0.1F,
            () -> Ingredient.of(ModItems.HALLOWITE_INGOT.get()));

    private static final int[] BASE_DURABILITY = {11, 16, 15, 13};

    private final String name;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final int enchantability;
    private final float toughness;
    private final float knockbackResistance;
    private final Supplier<Ingredient> repair;

    ModArmorMaterials(String name, int durabilityMultiplier, int[] defense, int enchantability,
                      float toughness, float knockbackResistance, Supplier<Ingredient> repair) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.enchantability = enchantability;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repair = repair;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return BASE_DURABILITY[type.ordinal()] * durabilityMultiplier;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return defense[type.ordinal()];
    }

    @Override
    public int getEnchantmentValue() {
        return enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return this == HALLOWITE ? SoundEvents.ARMOR_EQUIP_NETHERITE : SoundEvents.ARMOR_EQUIP_GENERIC;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return repair == null ? Ingredient.EMPTY : repair.get();
    }

    @Override
    public String getName() {
        return SpookyCraft.MODID + ":" + name;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockbackResistance;
    }
}
