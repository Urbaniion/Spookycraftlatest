package com.urbanion.spookycraft.init;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.block.DoorbellBlock;
import com.urbanion.spookycraft.block.HalloweenBedBlock;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, SpookyCraft.MODID);

    public static final RegistryObject<Block> DOORBELL = BLOCKS.register("doorbell",
            () -> new DoorbellBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD)
                    .strength(0.5F)
                    .sound(SoundType.WOOD)
                    .noOcclusion()
                    .pushReaction(PushReaction.DESTROY)));

    public static final RegistryObject<Block> HALLOWITE_BLOCK = BLOCKS.register("hallowite_block",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE)
                    .strength(50.0F, 1200.0F)
                    .requiresCorrectToolForDrops()
                    .sound(SoundType.NETHERITE_BLOCK)));

    public static final RegistryObject<Block> CHOCOLATE_LOG = BLOCKS.register("chocolate_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BROWN)
                    .strength(1.5F)
                    .sound(SoundType.WOOD)));

    public static final RegistryObject<Block> CHOCOLATE_LEAVES = BLOCKS.register("chocolate_leaves",
            () -> new LeavesBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BROWN)
                    .strength(0.2F)
                    .randomTicks()
                    .sound(SoundType.GRASS)
                    .noOcclusion()
                    .isValidSpawn((state, level, pos, type) -> false)
                    .isSuffocating((state, level, pos) -> false)
                    .isViewBlocking((state, level, pos) -> false)));

    private static BlockBehaviour.Properties bedProperties(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color)
                .sound(SoundType.WOOD)
                .strength(0.2F)
                .noOcclusion()
                .ignitedByLava()
                .pushReaction(PushReaction.DESTROY);
    }

    public static final RegistryObject<Block> PUMPKIN_BED = BLOCKS.register("pumpkin_bed",
            () -> new HalloweenBedBlock(DyeColor.ORANGE, bedProperties(MapColor.COLOR_ORANGE)));
    public static final RegistryObject<Block> WITCH_BED = BLOCKS.register("witch_bed",
            () -> new HalloweenBedBlock(DyeColor.PURPLE, bedProperties(MapColor.COLOR_PURPLE)));
    public static final RegistryObject<Block> FRANKENSTEIN_BED = BLOCKS.register("frankenstein_bed",
            () -> new HalloweenBedBlock(DyeColor.GREEN, bedProperties(MapColor.COLOR_GREEN)));
    public static final RegistryObject<Block> GHOST_BED = BLOCKS.register("ghost_bed",
            () -> new HalloweenBedBlock(DyeColor.WHITE, bedProperties(MapColor.SNOW)));
}
