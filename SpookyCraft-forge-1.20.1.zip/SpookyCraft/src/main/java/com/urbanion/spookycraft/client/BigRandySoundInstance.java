package com.urbanion.spookycraft.client;

import com.urbanion.spookycraft.entity.BigRandy;
import com.urbanion.spookycraft.init.ModSounds;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;

/** Big Randy's song: follows him around, loops, and fades out over 15 blocks (see sounds.json). */
public class BigRandySoundInstance extends AbstractTickableSoundInstance {
    private final BigRandy randy;

    public BigRandySoundInstance(BigRandy randy) {
        super(ModSounds.BIG_RANDY_SONG.get(), SoundSource.HOSTILE, SoundInstance.createUnseededRandom());
        this.randy = randy;
        this.looping = true;
        this.delay = 0;
        this.volume = 1.0F;
        this.pitch = 1.0F;
        this.attenuation = SoundInstance.Attenuation.LINEAR;
        this.x = randy.getX();
        this.y = randy.getY();
        this.z = randy.getZ();
    }

    @Override
    public void tick() {
        if (randy.isRemoved() || !randy.isAlive()) {
            stop();
            return;
        }
        this.x = randy.getX();
        this.y = randy.getY();
        this.z = randy.getZ();
    }
}
