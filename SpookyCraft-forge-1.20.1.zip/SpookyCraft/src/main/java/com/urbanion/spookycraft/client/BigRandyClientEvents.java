package com.urbanion.spookycraft.client;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.entity.BigRandy;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpookyCraft.MODID, value = Dist.CLIENT)
public class BigRandyClientEvents {
    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() && event.getEntity() instanceof BigRandy randy) {
            Minecraft.getInstance().getSoundManager().play(new BigRandySoundInstance(randy));
        }
    }
}
