package com.urbanion.spookycraft.entity;

import com.urbanion.spookycraft.util.SpookyTime;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;

/**
 * A villager in a Halloween costume. Uses the villager model with one of 5 costume textures.
 * Wanders around during the day and walks back home (where it spawned) at dusk.
 */
public class TrickOrTreatVillager extends PathfinderMob {
    public static final int VARIANTS = 5;
    private static final EntityDataAccessor<Integer> VARIANT =
            SynchedEntityData.defineId(TrickOrTreatVillager.class, EntityDataSerializers.INT);

    @Nullable
    private BlockPos home;
    private boolean answering;

    public TrickOrTreatVillager(EntityType<? extends TrickOrTreatVillager> type, Level level) {
        super(type, level);
        if (getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
            nav.setCanFloat(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.5D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(VARIANT, 0);
    }

    public int getVariant() {
        return Math.floorMod(entityData.get(VARIANT), VARIANTS);
    }

    public void setVariant(int variant) {
        entityData.set(VARIANT, Math.floorMod(variant, VARIANTS));
    }

    /** While a doorbell visit is running the normal wandering/looking goals are paused. */
    public void setAnswering(boolean answering) {
        this.answering = answering;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new PanicGoal(this, 0.8D));
        goalSelector.addGoal(2, new OpenDoorGoal(this, true));
        goalSelector.addGoal(3, new GoHomeGoal(this));
        goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.5D) {
            @Override
            public boolean canUse() {
                return !answering && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return !answering && super.canContinueToUse();
            }
        });
        goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0F) {
            @Override
            public boolean canUse() {
                return !answering && super.canUse();
            }
        });
        goalSelector.addGoal(6, new RandomLookAroundGoal(this) {
            @Override
            public boolean canUse() {
                return !answering && super.canUse();
            }
        });
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide && home == null) {
            home = blockPosition();
            restrictTo(home, 24);
        }
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable CompoundTag dataTag) {
        if (dataTag == null || !dataTag.contains("Variant")) {
            setVariant(random.nextInt(VARIANTS));
        }
        setPersistenceRequired();
        return super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        playSound(SoundEvents.VILLAGER_NO, 1.0F, 1.0F);
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant());
        if (home != null) {
            tag.putLong("Home", home.asLong());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("Variant"));
        if (tag.contains("Home")) {
            home = BlockPos.of(tag.getLong("Home"));
            restrictTo(home, 24);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VILLAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VILLAGER_DEATH;
    }

    /** At dusk: walk back to the spawn point (inside the house) and stay there until morning. */
    private static class GoHomeGoal extends Goal {
        private final TrickOrTreatVillager mob;
        private int recalc;

        GoHomeGoal(TrickOrTreatVillager mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return mob.home != null && !mob.answering && SpookyTime.isGoHomeTime(mob.level());
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void tick() {
            Vec3 target = Vec3.atBottomCenterOf(mob.home);
            if (mob.position().distanceToSqr(target) > 4.0D) {
                if (--recalc <= 0) {
                    recalc = 20;
                    mob.getNavigation().moveTo(target.x, target.y, target.z, 0.6D);
                }
            } else {
                mob.getNavigation().stop();
            }
        }
    }
}
