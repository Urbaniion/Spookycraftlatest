package com.urbanion.spookycraft.util;

import com.urbanion.spookycraft.init.ModItems;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** What a villager hands out on a Treat. */
public class TreatLoot {
    public static final float HALLOWITE_CHANCE = 0.015F; // very rare
    public static final float MASK_CHANCE = 0.08F;

    public static ItemStack roll(RandomSource random) {
        float r = random.nextFloat();
        if (r < HALLOWITE_CHANCE) {
            return new ItemStack(ModItems.RAW_HALLOWITE.get());
        }
        if (r < HALLOWITE_CHANCE + MASK_CHANCE) {
            var masks = ModItems.masks();
            return new ItemStack(masks[random.nextInt(masks.length)].get());
        }
        var candies = ModItems.candies();
        Item candy = candies[random.nextInt(candies.length)].get();
        return new ItemStack(candy, 1 + random.nextInt(3));
    }
}
