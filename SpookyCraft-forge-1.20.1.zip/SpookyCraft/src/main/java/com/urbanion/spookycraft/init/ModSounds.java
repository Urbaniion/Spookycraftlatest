package com.urbanion.spookycraft.init;

import com.urbanion.spookycraft.SpookyCraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SpookyCraft.MODID);

    public static final RegistryObject<SoundEvent> DOORBELL = SOUNDS.register("doorbell",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(SpookyCraft.MODID, "doorbell")));

    public static final RegistryObject<SoundEvent> BIG_RANDY_SONG = SOUNDS.register("big_randy_song",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(SpookyCraft.MODID, "big_randy_song")));
}
