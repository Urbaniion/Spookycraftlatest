package com.urbanion.spookycraft.client;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.entity.BigRandy;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class BigRandyRenderer extends MobRenderer<BigRandy, BigRandyModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(SpookyCraft.MODID, "textures/entity/big_randy/big_randy.png");
    private static final ResourceLocation EYES =
            new ResourceLocation(SpookyCraft.MODID, "textures/entity/big_randy/big_randy_eyes.png");

    public BigRandyRenderer(EntityRendererProvider.Context context) {
        super(context, new BigRandyModel(context.bakeLayer(ClientModEvents.BIG_RANDY_LAYER)), 1.2F);
        addLayer(new GlowingGlasses(this));
    }

    @Override
    public ResourceLocation getTextureLocation(BigRandy entity) {
        return TEXTURE;
    }

    private static class GlowingGlasses extends EyesLayer<BigRandy, BigRandyModel> {
        GlowingGlasses(RenderLayerParent<BigRandy, BigRandyModel> parent) {
            super(parent);
        }

        @Override
        public RenderType renderType() {
            return RenderType.eyes(EYES);
        }
    }
}
