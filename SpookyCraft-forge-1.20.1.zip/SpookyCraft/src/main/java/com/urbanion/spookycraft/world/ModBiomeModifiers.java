package com.urbanion.spookycraft.world;

import com.mojang.serialization.Codec;
import com.urbanion.spookycraft.SpookyCraft;
import net.minecraftforge.common.world.BiomeModifier;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBiomeModifiers {
    public static final DeferredRegister<Codec<? extends BiomeModifier>> SERIALIZERS =
            DeferredRegister.create(ForgeRegistries.Keys.BIOME_MODIFIER_SERIALIZERS, SpookyCraft.MODID);

    public static final RegistryObject<Codec<HalloweenForestModifier>> HALLOWEEN_FOREST =
            SERIALIZERS.register("halloween_forest", () -> HalloweenForestModifier.CODEC);
}
