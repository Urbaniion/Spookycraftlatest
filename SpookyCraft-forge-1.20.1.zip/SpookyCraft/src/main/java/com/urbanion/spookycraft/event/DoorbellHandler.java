package com.urbanion.spookycraft.event;

import com.urbanion.spookycraft.block.DoorbellBlock;
import com.urbanion.spookycraft.entity.TrickOrTreatVillager;
import com.urbanion.spookycraft.init.ModSounds;
import com.urbanion.spookycraft.util.SpookyTime;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class DoorbellHandler {
    static final String NEXT_VISIT_TAG = "spookycraft_next_visit";
    static final int VILLAGER_COOLDOWN_TICKS = 20 * 120; // a villager answers once every 2 minutes
    private static final Map<UUID, Long> LAST_RING = new HashMap<>();

    public static void clear() {
        LAST_RING.clear();
    }

    public static void ring(ServerLevel level, BlockPos bellPos, BlockState bellState, ServerPlayer player) {
        long now = level.getGameTime();
        Long last = LAST_RING.get(player.getUUID());
        if (last != null && now - last < 40) {
            return; // anti-spam
        }
        LAST_RING.put(player.getUUID(), now);

        // 1) ding-dong (always)
        level.playSound(null, bellPos, ModSounds.DOORBELL.get(), SoundSource.BLOCKS, 1.0F, 1.0F);

        // trick or treating only works from dusk until dawn
        if (!SpookyTime.isTrickOrTreatTime(level)) {
            actionBar(player, "It's too early for Trick or Treat... come back when the sun goes down!");
            return;
        }

        // 2) the player says "Trick or Treat!" in chat
        level.getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("chat.type.text", player.getDisplayName(), Component.literal("Trick or Treat!")),
                false);

        // 3) find the door this bell belongs to
        BlockPos doorPos = findDoor(level, bellPos);
        if (doorPos == null) {
            actionBar(player, "There is no door near this doorbell...");
            return;
        }
        BlockState doorState = level.getBlockState(doorPos);
        Direction out = outsideDirection(level, bellState, doorPos, doorState);

        // 4) look for villagers (normal or costumed) inside the house
        Vec3 doorCenter = Vec3.atCenterOf(doorPos);
        double ox = out.getStepX();
        double oz = out.getStepZ();
        AABB box = new AABB(doorPos).inflate(10.0D, 3.0D, 10.0D);
        List<PathfinderMob> inside = level.getEntitiesOfClass(PathfinderMob.class, box, m -> {
            if (!m.isAlive() || !(m instanceof Villager || m instanceof TrickOrTreatVillager)) {
                return false;
            }
            Vec3 d = m.position().subtract(doorCenter);
            return d.x * ox + d.z * oz < -0.3D && !VillageDoorbells.openToSky(level, m.blockPosition());
        });

        if (inside.isEmpty()) {
            actionBar(player, "Nobody seems to be home...");
            return;
        }

        PathfinderMob best = null;
        boolean anyOnCooldown = false;
        for (PathfinderMob m : inside) {
            boolean cooldown = m.getPersistentData().getLong(NEXT_VISIT_TAG) > now;
            if (cooldown || VisitManager.BUSY.contains(m.getUUID())) {
                anyOnCooldown = true;
                continue;
            }
            if (best == null || m.distanceToSqr(doorCenter) < best.distanceToSqr(doorCenter)) {
                best = m;
            }
        }
        if (best == null) {
            actionBar(player, anyOnCooldown
                    ? "They are not in the mood for more Halloween right now..."
                    : "Nobody seems to be home...");
            return;
        }

        VisitManager.start(level, best, player, doorPos, out);
    }

    private static BlockPos findDoor(ServerLevel level, BlockPos bellPos) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(bellPos.offset(-3, -3, -3), bellPos.offset(3, 3, 3))) {
            BlockState s = level.getBlockState(p);
            if (s.getBlock() instanceof DoorBlock && s.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                double d = p.distSqr(bellPos);
                if (d < bestDist) {
                    bestDist = d;
                    best = p.immutable();
                }
            }
        }
        return best;
    }

    private static Direction outsideDirection(ServerLevel level, BlockState bellState, BlockPos doorPos, BlockState doorState) {
        Direction doorFacing = doorState.getValue(DoorBlock.FACING);
        Direction bellFacing = bellState.getValue(DoorbellBlock.FACING);
        if (bellFacing.getAxis() == doorFacing.getAxis()) {
            return bellFacing; // the bell is on the same side of the wall as the player
        }
        Direction found = VillageDoorbells.findOutside(level, doorPos, doorFacing);
        return found != null ? found : doorFacing;
    }

    static void actionBar(ServerPlayer player, String text) {
        player.displayClientMessage(Component.literal(text), true);
    }
}
