package com.urbanion.spookycraft;

import com.mojang.logging.LogUtils;
import com.urbanion.spookycraft.init.ModBlocks;
import com.urbanion.spookycraft.init.ModEntities;
import com.urbanion.spookycraft.init.ModItems;
import com.urbanion.spookycraft.init.ModSounds;
import com.urbanion.spookycraft.init.ModTabs;
import com.urbanion.spookycraft.init.ModTiers;
import com.urbanion.spookycraft.world.ModBiomeModifiers;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.common.TierSortingRegistry;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

import java.util.List;

@Mod(SpookyCraft.MODID)
public class SpookyCraft {
    public static final String MODID = "spookycraft";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SpookyCraft() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
        ModBiomeModifiers.SERIALIZERS.register(bus);
        bus.addListener(this::commonSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> TierSortingRegistry.registerTier(
                ModTiers.HALLOWITE,
                new ResourceLocation(MODID, "hallowite"),
                List.<Object>of(Tiers.NETHERITE),
                List.<Object>of()));
    }
}
