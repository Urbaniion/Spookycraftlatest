package com.urbanion.spookycraft.init;

import com.urbanion.spookycraft.SpookyCraft;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SpookyCraft.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.spookycraft"))
                    .icon(() -> new ItemStack(ModItems.CANDY_CORN.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.DOORBELL.get());
                        for (var candy : ModItems.candies()) {
                            output.accept(candy.get());
                        }
                        output.accept(ModItems.APPLE_CHOCOLATE_PIECE.get());
                        output.accept(ModItems.CHOCOLATE_LOG.get());
                        output.accept(ModItems.CHOCOLATE_LEAVES.get());
                        for (var mask : ModItems.masks()) {
                            output.accept(mask.get());
                        }
                        output.accept(ModItems.RAW_HALLOWITE.get());
                        output.accept(ModItems.HALLOWITE_INGOT.get());
                        output.accept(ModItems.HALLOWITE_BLOCK.get());
                        output.accept(ModItems.HALLOWITE_SWORD.get());
                        output.accept(ModItems.HALLOWITE_PICKAXE.get());
                        output.accept(ModItems.HALLOWITE_AXE.get());
                        output.accept(ModItems.HALLOWITE_SHOVEL.get());
                        output.accept(ModItems.HALLOWITE_HOE.get());
                        output.accept(ModItems.HALLOWITE_HELMET.get());
                        output.accept(ModItems.HALLOWITE_CHESTPLATE.get());
                        output.accept(ModItems.HALLOWITE_LEGGINGS.get());
                        output.accept(ModItems.HALLOWITE_BOOTS.get());
                        output.accept(ModItems.PUMPKIN_BED.get());
                        output.accept(ModItems.WITCH_BED.get());
                        output.accept(ModItems.FRANKENSTEIN_BED.get());
                        output.accept(ModItems.GHOST_BED.get());
                        output.accept(ModItems.TRICK_OR_TREAT_VILLAGER_SPAWN_EGG.get());
                        output.accept(ModItems.WEREWOLF_SPAWN_EGG.get());
                        output.accept(ModItems.BIG_RANDY_SPAWN_EGG.get());
                    })
                    .build());
}
