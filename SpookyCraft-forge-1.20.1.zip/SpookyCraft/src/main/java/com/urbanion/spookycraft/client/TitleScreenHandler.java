package com.urbanion.spookycraft.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.urbanion.spookycraft.SpookyCraft;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Main menu: draws our own background picture (the panorama is made transparent in the resources),
 * and "Urbanion's SpookyCraft" with the real Minecraft font (orange fill, purple outline) instead of the logo.
 */
@Mod.EventBusSubscriber(modid = SpookyCraft.MODID, value = Dist.CLIENT)
public class TitleScreenHandler {
    private static final String TITLE = "Urbanion's SpookyCraft";
    private static final int ORANGE = 0xFFFF8A00;
    private static final int PURPLE = 0xFF5B1A9E;
    private static final ResourceLocation BACKGROUND =
            new ResourceLocation(SpookyCraft.MODID, "textures/gui/menu_background.png");
    private static final int BG_W = 1600;
    private static final int BG_H = 900;

    @SubscribeEvent
    public static void onRenderPre(ScreenEvent.Render.Pre event) {
        if (!(event.getScreen() instanceof TitleScreen screen)) {
            return;
        }
        GuiGraphics graphics = event.getGuiGraphics();
        int w = screen.width;
        int h = screen.height;
        // "cover" the whole screen: crop the picture instead of stretching it
        float screenAspect = (float) w / (float) h;
        float imageAspect = (float) BG_W / (float) BG_H;
        float u = 0, v = 0, uw = BG_W, vh = BG_H;
        if (screenAspect > imageAspect) {
            vh = BG_W / screenAspect;
            v = (BG_H - vh) / 2.0F;
        } else {
            uw = BG_H * screenAspect;
            u = (BG_W - uw) / 2.0F;
        }
        graphics.blit(BACKGROUND, 0, 0, w, h, u, v, Math.round(uw), Math.round(vh), BG_W, BG_H);
        graphics.fill(0, 0, w, h, 0x50100020); // slight purple tint so the buttons stay readable
    }

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post event) {
        if (!(event.getScreen() instanceof TitleScreen screen)) {
            return;
        }
        GuiGraphics graphics = event.getGuiGraphics();
        Font font = Minecraft.getInstance().font;

        int textWidth = font.width(TITLE);
        float scale = Math.min(3.0F, (screen.width * 0.85F) / textWidth);
        float x = (screen.width - textWidth * scale) / 2.0F;
        float y = 30.0F + (44.0F - 8.0F * scale) / 2.0F;

        PoseStack pose = graphics.pose();
        pose.pushPose();
        pose.translate(x, y, 0.0F);
        pose.scale(scale, scale, 1.0F);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx != 0 || dy != 0) {
                    graphics.drawString(font, TITLE, dx, dy, PURPLE, false);
                }
            }
        }
        graphics.drawString(font, TITLE, 0, 0, ORANGE, false);
        pose.popPose();
    }
}
