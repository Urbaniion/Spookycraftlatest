package com.urbanion.spookycraft.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.urbanion.spookycraft.ClientConfig;
import com.urbanion.spookycraft.SpookyCraft;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;

import java.io.InputStream;
import java.util.Map;

/**
 * Re-colors the vanilla GUI textures to orange and purple while the game loads them,
 * so nothing from vanilla has to be shipped. Can be turned off in the client config (uiTheme).
 */
public class UiThemeReloadListener implements ResourceManagerReloadListener {
    private enum Mode { WIDGETS, BACKGROUND, GRAYS }

    // {luminance, r, g, b}
    private static final int[][] PURPLE = {
            {0, 10, 4, 22}, {60, 40, 16, 72}, {139, 100, 56, 150},
            {198, 176, 136, 214}, {232, 236, 150, 60}, {255, 255, 190, 90}
    };
    private static final int[][] ORANGE = {
            {0, 40, 14, 0}, {100, 150, 70, 10}, {160, 230, 120, 20}, {255, 255, 215, 130}
    };
    private static final int[][] DARK_PURPLE = {
            {0, 12, 6, 24}, {100, 52, 24, 86}, {255, 90, 44, 140}
    };

    @Override
    public void onResourceManagerReload(ResourceManager manager) {
        boolean enabled = true;
        try {
            enabled = ClientConfig.UI_THEME.get();
        } catch (Exception ignored) {
            // config not loaded yet: use the default (on)
        }
        if (!enabled) {
            return;
        }
        TextureManager textures = Minecraft.getInstance().getTextureManager();
        try {
            // every GUI texture that is mostly gray gets the purple/orange palette (menus, icons, inventories, ...)
            Map<ResourceLocation, Resource> all =
                    manager.listResources("textures/gui", rl -> rl.getPath().endsWith(".png"));
            for (ResourceLocation rl : all.keySet()) {
                String path = rl.getPath();
                if (!rl.getNamespace().equals("minecraft") || path.contains("/title/") || path.contains("/sprites/")
                        || path.endsWith("/widgets.png") || path.contains("options_background")
                        || path.contains("dirt_background")) {
                    continue;
                }
                recolor(manager, textures, rl, Mode.GRAYS);
            }
            recolor(manager, textures, new ResourceLocation("textures/gui/widgets.png"), Mode.WIDGETS);
            recolor(manager, textures, new ResourceLocation("textures/gui/options_background.png"), Mode.BACKGROUND);
            recolor(manager, textures, new ResourceLocation("textures/gui/light_dirt_background.png"), Mode.BACKGROUND);
        } catch (Exception e) {
            SpookyCraft.LOGGER.warn("Could not apply the SpookyCraft UI theme", e);
        }
    }

    private static void recolor(ResourceManager manager, TextureManager textures, ResourceLocation loc, Mode mode) {
        NativeImage image;
        try (InputStream in = manager.getResourceOrThrow(loc).open()) {
            image = NativeImage.read(in);
        } catch (Exception e) {
            return; // texture doesn't exist in this version/pack: skip it
        }
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                int abgr = image.getPixelRGBA(x, y);
                int a = abgr >>> 24;
                if (a == 0) {
                    continue;
                }
                int r = abgr & 255;
                int g = (abgr >> 8) & 255;
                int b = (abgr >> 16) & 255;
                int lum = (int) (0.299F * r + 0.587F * g + 0.114F * b);
                int[] out;
                switch (mode) {
                    case WIDGETS -> {
                        boolean hoverRow = y >= 86 && y < 106 && image.getWidth() == 256;
                        out = ramp(lum, hoverRow ? ORANGE : PURPLE);
                    }
                    case BACKGROUND -> out = ramp(lum, DARK_PURPLE);
                    default -> {
                        int sat = Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
                        if (sat > 24) {
                            continue; // keep colored parts (flames, arrows, ...)
                        }
                        out = ramp(lum, PURPLE);
                    }
                }
                image.setPixelRGBA(x, y, (a << 24) | (out[2] << 16) | (out[1] << 8) | out[0]);
            }
        }
        textures.register(loc, new DynamicTexture(image));
    }

    private static int[] ramp(int lum, int[][] stops) {
        if (lum <= stops[0][0]) {
            return new int[]{stops[0][1], stops[0][2], stops[0][3]};
        }
        for (int i = 1; i < stops.length; i++) {
            if (lum <= stops[i][0]) {
                float t = (lum - stops[i - 1][0]) / (float) (stops[i][0] - stops[i - 1][0]);
                return new int[]{
                        Math.round(stops[i - 1][1] + t * (stops[i][1] - stops[i - 1][1])),
                        Math.round(stops[i - 1][2] + t * (stops[i][2] - stops[i - 1][2])),
                        Math.round(stops[i - 1][3] + t * (stops[i][3] - stops[i - 1][3]))};
            }
        }
        int[] last = stops[stops.length - 1];
        return new int[]{last[1], last[2], last[3]};
    }
}
