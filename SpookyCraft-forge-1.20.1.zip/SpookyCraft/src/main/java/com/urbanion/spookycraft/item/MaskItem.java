package com.urbanion.spookycraft.item;

import com.urbanion.spookycraft.init.ModArmorMaterials;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class MaskItem extends ArmorItem {
    /** Added to the 50% base chance of a Treat while wearing a mask. */
    public static final double TREAT_BONUS = 0.15D;

    public MaskItem(ModArmorMaterials material) {
        super(material, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1));
    }

    public static double treatBonus(Player player) {
        return player.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof MaskItem ? TREAT_BONUS : 0.0D;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("+15% chance of a Treat").withStyle(ChatFormatting.GOLD));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
