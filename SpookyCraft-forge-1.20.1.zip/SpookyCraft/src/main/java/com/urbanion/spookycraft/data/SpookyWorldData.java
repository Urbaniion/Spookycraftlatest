package com.urbanion.spookycraft.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** World-wide bookkeeping, e.g. Big Randy only shows up once per night. */
public class SpookyWorldData extends SavedData {
    private long lastRandyNight = -1L;

    public static SpookyWorldData get(ServerLevel anyLevel) {
        ServerLevel overworld = anyLevel.getServer().overworld();
        return overworld.getDataStorage().computeIfAbsent(
                SpookyWorldData::load, SpookyWorldData::new, "spookycraft_world");
    }

    public static SpookyWorldData load(CompoundTag tag) {
        SpookyWorldData data = new SpookyWorldData();
        data.lastRandyNight = tag.contains("LastRandyNight") ? tag.getLong("LastRandyNight") : -1L;
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("LastRandyNight", lastRandyNight);
        return tag;
    }

    public boolean randyAlreadyCameThisNight(long night) {
        return lastRandyNight == night;
    }

    public void markRandy(long night) {
        lastRandyNight = night;
        setDirty();
    }
}
