package com.urbanion.spookycraft.event;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.data.SpookyWorldData;
import com.urbanion.spookycraft.entity.BigRandy;
import com.urbanion.spookycraft.entity.Werewolf;
import com.urbanion.spookycraft.init.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * Rare night visitors around Trick or Treat Towns.
 * Werewolves: rare. Big Randy: very rare and at most once per night.
 */
@Mod.EventBusSubscriber(modid = SpookyCraft.MODID)
public class NightSpawner {
    private static final TagKey<Structure> TOWN =
            TagKey.create(Registries.STRUCTURE, new ResourceLocation(SpookyCraft.MODID, "trick_or_treat_town"));

    private static final float WEREWOLF_CHANCE = 0.015F; // per check (every 20 seconds)
    private static final float RANDY_CHANCE = 0.006F;    // per check (every 20 seconds)

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) {
            return;
        }
        if (player.tickCount % 400 != 0) { // every 20 seconds
            return;
        }
        ServerLevel level = player.serverLevel();
        if (level.dimension() != Level.OVERWORLD || level.isDay()) {
            return;
        }
        if (!isNearTown(level, player.blockPosition())) {
            return;
        }

        // Big Randy (once per night)
        long night = Math.floorDiv(level.getDayTime() - 12000L, 24000L);
        SpookyWorldData data = SpookyWorldData.get(level);
        if (!data.randyAlreadyCameThisNight(night) && level.random.nextFloat() < RANDY_CHANCE) {
            List<BigRandy> existing = level.getEntitiesOfClass(BigRandy.class, player.getBoundingBox().inflate(128.0D));
            if (existing.isEmpty() && spawnAround(level, player, ModEntities.BIG_RANDY.get(), 26.0D, 38.0D)) {
                data.markRandy(night);
                return;
            }
        }

        // Werewolf
        if (level.random.nextFloat() < WEREWOLF_CHANCE) {
            List<Werewolf> existing = level.getEntitiesOfClass(Werewolf.class, player.getBoundingBox().inflate(64.0D));
            if (existing.isEmpty()) {
                spawnAround(level, player, ModEntities.WEREWOLF.get(), 18.0D, 30.0D);
            }
        }
    }

    private static <T extends Monster> boolean spawnAround(ServerLevel level, ServerPlayer player,
                                                           EntityType<T> type, double minDist, double maxDist) {
        double angle = level.random.nextDouble() * Math.PI * 2.0D;
        double dist = minDist + level.random.nextDouble() * (maxDist - minDist);
        int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
        int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
        if (!level.hasChunkAt(new BlockPos(x, 64, z))) {
            return false;
        }
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        T mob = type.create(level);
        if (mob == null) {
            return false;
        }
        mob.moveTo(x + 0.5D, y, z + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
        if (!level.noCollision(mob)) {
            return false;
        }
        mob.finalizeSpawn(level, level.getCurrentDifficultyAt(mob.blockPosition()), MobSpawnType.EVENT, null, null);
        level.addFreshEntity(mob);
        return true;
    }

    private static boolean isNearTown(ServerLevel level, BlockPos pos) {
        int[][] offsets = {{0, 0}, {24, 0}, {-24, 0}, {0, 24}, {0, -24}};
        for (int[] o : offsets) {
            BlockPos p = pos.offset(o[0], 0, o[1]);
            if (level.hasChunkAt(p) && level.structureManager().getStructureWithPieceAt(p, TOWN).isValid()) {
                return true;
            }
        }
        return false;
    }
}
