package com.urbanion.spookycraft.event;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.entity.TrickOrTreatVillager;
import com.urbanion.spookycraft.entity.Werewolf;
import com.urbanion.spookycraft.init.ModEntities;
import com.urbanion.spookycraft.init.ModItems;
import com.urbanion.spookycraft.item.MaskItem;
import com.urbanion.spookycraft.util.TreatLoot;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.behavior.EntityTracker;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.WalkTarget;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Runs the "someone answers the door" sequence:
 * walk to the door -> open it -> look at the player -> Treat or Trick.
 */
@Mod.EventBusSubscriber(modid = SpookyCraft.MODID)
public class VisitManager {
    public static final Set<UUID> BUSY = new HashSet<>();
    private static final List<Visit> VISITS = new ArrayList<>();

    public static void start(ServerLevel level, PathfinderMob mob, ServerPlayer player, BlockPos door, Direction out) {
        BUSY.add(mob.getUUID());
        VISITS.add(new Visit(level, mob.getUUID(), player.getUUID(), door, out));
        DoorbellHandler.actionBar(player, "Someone is coming to the door...");
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || VISITS.isEmpty()) {
            return;
        }
        Iterator<Visit> it = VISITS.iterator();
        while (it.hasNext()) {
            Visit visit = it.next();
            if (visit.tick()) {
                visit.end();
                BUSY.remove(visit.mobId);
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        VISITS.clear();
        BUSY.clear();
        DoorbellHandler.clear();
    }

    private enum Phase { WALK, OPEN, REVEAL, CLOSE }

    private static class Visit {
        final ServerLevel level;
        final UUID mobId;
        final UUID playerId;
        final BlockPos door;
        final Direction out;
        final Vec3 spot; // just inside the door
        Phase phase = Phase.WALK;
        int timer = 0;
        boolean closeDoorAtEnd = false;
        boolean started = false;

        Visit(ServerLevel level, UUID mobId, UUID playerId, BlockPos door, Direction out) {
            this.level = level;
            this.mobId = mobId;
            this.playerId = playerId;
            this.door = door;
            this.out = out;
            this.spot = Vec3.atBottomCenterOf(door.relative(out.getOpposite()));
        }

        private PathfinderMob mob() {
            Entity e = level.getEntity(mobId);
            return e instanceof PathfinderMob m && m.isAlive() ? m : null;
        }

        void end() {
            if (level.getEntity(mobId) instanceof TrickOrTreatVillager t) {
                t.setAnswering(false);
            }
        }

        /** @return true when the visit is over */
        boolean tick() {
            ServerPlayer player = level.getServer().getPlayerList().getPlayer(playerId);
            PathfinderMob mob = mob();

            if (phase == Phase.CLOSE) {
                timer++;
                if (timer >= 80) {
                    if (closeDoorAtEnd) {
                        setDoorOpen(null, false);
                    }
                    return true;
                }
                return false;
            }

            if (mob == null || player == null || player.serverLevel() != level) {
                return true; // answerer gone or player left: abort
            }

            if (!started) {
                started = true;
                if (mob instanceof TrickOrTreatVillager t) {
                    t.setAnswering(true);
                }
            }

            switch (phase) {
                case WALK -> {
                    timer++;
                    if (mob.isSleeping()) {
                        mob.stopSleeping();
                    }
                    if (timer % 10 == 1) {
                        mob.getBrain().setMemory(MemoryModuleType.WALK_TARGET, new WalkTarget(spot, 0.6F, 1));
                        mob.getNavigation().moveTo(spot.x, spot.y, spot.z, 0.6D);
                    }
                    if (mob.position().distanceToSqr(spot) < 2.0D) {
                        phase = Phase.OPEN;
                        timer = 0;
                    } else if (timer > 300) {
                        // couldn't path there in time (15s): just put them behind the door
                        mob.moveTo(spot.x, spot.y, spot.z, mob.getYRot(), mob.getXRot());
                        phase = Phase.OPEN;
                        timer = 0;
                    }
                }
                case OPEN -> {
                    if (timer == 0) {
                        mob.getNavigation().stop();
                        mob.getBrain().eraseMemory(MemoryModuleType.WALK_TARGET);
                        setDoorOpen(mob, true);
                    }
                    mob.getBrain().setMemory(MemoryModuleType.LOOK_TARGET, new EntityTracker(player, true));
                    mob.getLookControl().setLookAt(player, 30.0F, 30.0F);
                    timer++;
                    if (timer >= 20) {
                        phase = Phase.REVEAL;
                        timer = 0;
                    }
                }
                case REVEAL -> {
                    double treatChance = 0.5D + MaskItem.treatBonus(player);
                    if (level.random.nextDouble() < treatChance) {
                        treat(mob, player);
                        closeDoorAtEnd = true;
                    } else {
                        trick(mob, player);
                    }
                    phase = Phase.CLOSE;
                    timer = 0;
                }
                default -> { }
            }
            return false;
        }

        private void setDoorOpen(Entity who, boolean open) {
            BlockState state = level.getBlockState(door);
            if (state.getBlock() instanceof DoorBlock doorBlock && state.getValue(DoorBlock.OPEN) != open) {
                doorBlock.setOpen(who, level, state, door, open);
            }
        }

        private void treat(PathfinderMob mob, ServerPlayer player) {
            ItemStack stack = TreatLoot.roll(level.random);
            int count = stack.getCount();
            Component name = stack.getHoverName();

            mob.getPersistentData().putLong(DoorbellHandler.NEXT_VISIT_TAG,
                    level.getGameTime() + DoorbellHandler.VILLAGER_COOLDOWN_TICKS);
            mob.playSound(SoundEvents.VILLAGER_YES, 1.0F, 1.0F);
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, mob.getX(), mob.getY() + 1.2D, mob.getZ(),
                    8, 0.4D, 0.4D, 0.4D, 0.0D);

            if (!player.getInventory().add(stack)) {
                player.drop(stack, false);
            }
            level.playSound(null, player.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.4F, 1.4F);
            player.displayClientMessage(Component.literal("Treat! You got " + count + "x ")
                    .append(name).append(Component.literal("!")), true);
        }

        private void trick(PathfinderMob victim, ServerPlayer player) {
            Mob mob;
            float roll = level.random.nextFloat();
            if (roll < 0.04F) {
                mob = ModEntities.WEREWOLF.get().create(level); // rare!
            } else if (roll < 0.36F) {
                mob = EntityType.ZOMBIE.create(level);
            } else if (roll < 0.68F) {
                mob = EntityType.SKELETON.create(level);
            } else {
                mob = EntityType.SPIDER.create(level);
            }
            if (mob == null) {
                return;
            }
            mob.moveTo(victim.getX(), victim.getY(), victim.getZ(), victim.getYRot(), victim.getXRot());
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(victim.blockPosition()),
                    MobSpawnType.EVENT, null, null);

            // Festive pumpkin head (also stops zombies/skeletons from burning in daylight)
            if (mob instanceof Zombie || mob instanceof Skeleton) {
                mob.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.CARVED_PUMPKIN));
                mob.setDropChance(EquipmentSlot.HEAD, 0.0F);
            }
            mob.setPersistenceRequired();
            mob.setTarget(player);

            level.sendParticles(ParticleTypes.POOF, victim.getX(), victim.getY() + 1.0D, victim.getZ(),
                    25, 0.3D, 0.5D, 0.3D, 0.02D);
            level.playSound(null, victim.blockPosition(), SoundEvents.ZOMBIE_VILLAGER_CONVERTED,
                    SoundSource.HOSTILE, 1.0F, 1.0F);

            victim.discard();
            level.addFreshEntity(mob);
            player.displayClientMessage(Component.literal("Trick! It turned into a ")
                    .append(mob.getType().getDescription()).append(Component.literal("!")), true);
        }
    }
}
