package com.urbanion.spookycraft.world;

import com.mojang.serialization.Codec;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.biome.AmbientParticleSettings;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraft.world.level.biome.Biomes;
import net.minecraftforge.common.world.BiomeModifier;
import net.minecraftforge.common.world.ModifiableBiomeInfo;

/**
 * Turns the Dark Forest into the "Halloween Forest": purple grass, orange leaves,
 * an orange-purple sky and fog, and drifting spores. (Extra trees, pumpkins and cobwebs
 * are added with the normal biome modifier JSON files.)
 */
public class HalloweenForestModifier implements BiomeModifier {
    public static final HalloweenForestModifier INSTANCE = new HalloweenForestModifier();
    public static final Codec<HalloweenForestModifier> CODEC = Codec.unit(INSTANCE);

    @Override
    public void modify(Holder<Biome> biome, Phase phase, ModifiableBiomeInfo.BiomeInfo.Builder builder) {
        if (phase != Phase.MODIFY || !biome.is(Biomes.DARK_FOREST.location())) {
            return;
        }
        BiomeSpecialEffects.Builder fx = builder.getSpecialEffects();
        fx.skyColor(0x4B1D7A)
                .fogColor(0xB3501E)
                .waterColor(0x6B3FA0)
                .waterFogColor(0x2A0F4A)
                .grassColorOverride(0x7A3FA8)
                .foliageColorOverride(0xE8761A)
                .ambientParticle(new AmbientParticleSettings(ParticleTypes.CRIMSON_SPORE, 0.01F));
    }

    @Override
    public Codec<? extends BiomeModifier> codec() {
        return CODEC;
    }
}
