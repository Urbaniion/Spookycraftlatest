package com.urbanion.spookycraft.data;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Remembers which village doors were already handled, so a removed doorbell never comes back. */
public class DoorbellSavedData extends SavedData {
    private final LongSet done = new LongOpenHashSet();

    public static DoorbellSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                DoorbellSavedData::load, DoorbellSavedData::new, "spookycraft_doorbells");
    }

    public static DoorbellSavedData load(CompoundTag tag) {
        DoorbellSavedData data = new DoorbellSavedData();
        for (long l : tag.getLongArray("done")) {
            data.done.add(l);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLongArray("done", done.toLongArray());
        return tag;
    }

    public boolean isDone(BlockPos pos) {
        return done.contains(pos.asLong());
    }

    public void markDone(BlockPos pos) {
        if (done.add(pos.asLong())) {
            setDirty();
        }
    }
}
