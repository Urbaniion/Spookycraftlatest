package com.urbanion.spookycraft.init;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.ForgeTier;
import net.minecraftforge.common.Tags;

public class ModTiers {
    /** A little stronger than netherite (netherite: 2031 uses, speed 9, +4 damage). */
    public static final ForgeTier HALLOWITE = new ForgeTier(
            4, 2400, 9.5F, 4.5F, 18,
            Tags.Blocks.NEEDS_NETHERITE_TOOL,
            () -> Ingredient.of(ModItems.HALLOWITE_INGOT.get()));
}
