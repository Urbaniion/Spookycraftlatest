package com.urbanion.spookycraft.init;

import com.urbanion.spookycraft.SpookyCraft;
import com.urbanion.spookycraft.item.MaskItem;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BedItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SpookyCraft.MODID);

    /** hunger = hunger points (2 points = 1 bar). Each effect: {effect, ticks, amplifier}. */
    private static Item candy(int hunger, Object[]... effects) {
        FoodProperties.Builder food = new FoodProperties.Builder()
                .nutrition(hunger).saturationMod(0.3F).alwaysEat().fast();
        for (Object[] e : effects) {
            MobEffect effect = (MobEffect) e[0];
            int ticks = (Integer) e[1];
            int amp = (Integer) e[2];
            food.effect(() -> new MobEffectInstance(effect, ticks, amp), 1.0F);
        }
        return new Item(new Item.Properties().food(food.build()));
    }

    private static Object[] fx(MobEffect effect, int seconds, int amplifier) {
        return new Object[]{effect, seconds * 20, amplifier};
    }

    // ---------------- blocks ----------------
    public static final RegistryObject<Item> DOORBELL = ITEMS.register("doorbell",
            () -> new BlockItem(ModBlocks.DOORBELL.get(), new Item.Properties()));
    public static final RegistryObject<Item> HALLOWITE_BLOCK = ITEMS.register("hallowite_block",
            () -> new BlockItem(ModBlocks.HALLOWITE_BLOCK.get(), new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> CHOCOLATE_LEAVES = ITEMS.register("chocolate_leaves",
            () -> new BlockItem(ModBlocks.CHOCOLATE_LEAVES.get(), new Item.Properties()));

    // Chocolate log: placeable AND edible (same effect as a Chocolate Bar, but 1 hunger bar more)
    public static final RegistryObject<Item> CHOCOLATE_LOG = ITEMS.register("chocolate_log",
            () -> new BlockItem(ModBlocks.CHOCOLATE_LOG.get(), new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(8).saturationMod(0.3F).alwaysEat().fast()
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 5 * 20, 1), 1.0F)
                            .build())));

    // ---------------- candies ----------------
    public static final RegistryObject<Item> CANDY_CORN = ITEMS.register("candy_corn",
            () -> candy(4, fx(MobEffects.REGENERATION, 10, 1)));                    // 2 bars, Regeneration II 10s
    public static final RegistryObject<Item> CHOCOLATE_BAR = ITEMS.register("chocolate_bar",
            () -> candy(6, fx(MobEffects.MOVEMENT_SPEED, 5, 1)));                   // 3 bars, Speed II 5s
    public static final RegistryObject<Item> LOLLIPOP = ITEMS.register("lollipop",
            () -> candy(2, fx(MobEffects.SATURATION, 10, 0)));                      // 1 bar, Saturation 10s
    public static final RegistryObject<Item> GUMMY_BAT = ITEMS.register("gummy_bat",
            () -> candy(2, fx(MobEffects.NIGHT_VISION, 60, 0)));                    // Night Vision 1 min
    public static final RegistryObject<Item> CARAMEL_APPLE = ITEMS.register("caramel_apple",
            () -> candy(6, fx(MobEffects.ABSORPTION, 20, 1)));                      // Absorption II 20s
    public static final RegistryObject<Item> GHOST_MARSHMALLOW = ITEMS.register("ghost_marshmallow",
            () -> candy(2, fx(MobEffects.INVISIBILITY, 20, 0), fx(MobEffects.SLOW_FALLING, 20, 0)));
    public static final RegistryObject<Item> BLACK_LICORICE = ITEMS.register("black_licorice",
            () -> candy(4, fx(MobEffects.DAMAGE_BOOST, 20, 0)));                    // Strength I 20s
    public static final RegistryObject<Item> SOUR_WORMS = ITEMS.register("sour_worms",
            () -> candy(2, fx(MobEffects.JUMP, 20, 1)));                            // Jump Boost II 20s
    public static final RegistryObject<Item> APPLE_CHOCOLATE_PIECE = ITEMS.register("apple_flavored_chocolate_piece",
            () -> candy(3, fx(MobEffects.MOVEMENT_SPEED, 4, 0)));

    public static RegistryObject<Item>[] candies() {
        @SuppressWarnings("unchecked")
        RegistryObject<Item>[] arr = new RegistryObject[]{CANDY_CORN, CHOCOLATE_BAR, LOLLIPOP, GUMMY_BAT,
                CARAMEL_APPLE, GHOST_MARSHMALLOW, BLACK_LICORICE, SOUR_WORMS};
        return arr;
    }

    // ---------------- masks ----------------
    public static final RegistryObject<Item> MASK_DALLAS = ITEMS.register("mask_dallas",
            () -> new MaskItem(ModArmorMaterials.DALLAS));
    public static final RegistryObject<Item> MASK_WOLF = ITEMS.register("mask_wolf",
            () -> new MaskItem(ModArmorMaterials.WOLF));
    public static final RegistryObject<Item> MASK_HOUSTON = ITEMS.register("mask_houston",
            () -> new MaskItem(ModArmorMaterials.HOUSTON));
    public static final RegistryObject<Item> MASK_HOXTON = ITEMS.register("mask_hoxton",
            () -> new MaskItem(ModArmorMaterials.HOXTON));
    public static final RegistryObject<Item> MASK_CHAINS = ITEMS.register("mask_chains",
            () -> new MaskItem(ModArmorMaterials.CHAINS));

    public static RegistryObject<Item>[] masks() {
        @SuppressWarnings("unchecked")
        RegistryObject<Item>[] arr = new RegistryObject[]{MASK_DALLAS, MASK_WOLF, MASK_HOUSTON, MASK_HOXTON, MASK_CHAINS};
        return arr;
    }

    // ---------------- hallowite ----------------
    public static final RegistryObject<Item> RAW_HALLOWITE = ITEMS.register("raw_hallowite",
            () -> new Item(new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> HALLOWITE_INGOT = ITEMS.register("hallowite_ingot",
            () -> new Item(new Item.Properties().fireResistant()));

    public static final RegistryObject<Item> HALLOWITE_SWORD = ITEMS.register("hallowite_sword",
            () -> new SwordItem(ModTiers.HALLOWITE, 3, -2.4F, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> HALLOWITE_PICKAXE = ITEMS.register("hallowite_pickaxe",
            () -> new PickaxeItem(ModTiers.HALLOWITE, 1, -2.8F, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> HALLOWITE_AXE = ITEMS.register("hallowite_axe",
            () -> new AxeItem(ModTiers.HALLOWITE, 5.0F, -3.0F, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> HALLOWITE_SHOVEL = ITEMS.register("hallowite_shovel",
            () -> new ShovelItem(ModTiers.HALLOWITE, 1.5F, -3.0F, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> HALLOWITE_HOE = ITEMS.register("hallowite_hoe",
            () -> new HoeItem(ModTiers.HALLOWITE, -4, 0.0F, new Item.Properties().fireResistant()));

    public static final RegistryObject<Item> HALLOWITE_HELMET = ITEMS.register("hallowite_helmet",
            () -> new ArmorItem(ModArmorMaterials.HALLOWITE, ArmorItem.Type.HELMET, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> HALLOWITE_CHESTPLATE = ITEMS.register("hallowite_chestplate",
            () -> new ArmorItem(ModArmorMaterials.HALLOWITE, ArmorItem.Type.CHESTPLATE, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> HALLOWITE_LEGGINGS = ITEMS.register("hallowite_leggings",
            () -> new ArmorItem(ModArmorMaterials.HALLOWITE, ArmorItem.Type.LEGGINGS, new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> HALLOWITE_BOOTS = ITEMS.register("hallowite_boots",
            () -> new ArmorItem(ModArmorMaterials.HALLOWITE, ArmorItem.Type.BOOTS, new Item.Properties().fireResistant()));

    // ---------------- beds ----------------
    public static final RegistryObject<Item> PUMPKIN_BED = ITEMS.register("pumpkin_bed",
            () -> new BedItem(ModBlocks.PUMPKIN_BED.get(), new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> WITCH_BED = ITEMS.register("witch_bed",
            () -> new BedItem(ModBlocks.WITCH_BED.get(), new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FRANKENSTEIN_BED = ITEMS.register("frankenstein_bed",
            () -> new BedItem(ModBlocks.FRANKENSTEIN_BED.get(), new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> GHOST_BED = ITEMS.register("ghost_bed",
            () -> new BedItem(ModBlocks.GHOST_BED.get(), new Item.Properties().stacksTo(1)));

    // ---------------- spawn eggs ----------------
    public static final RegistryObject<Item> TRICK_OR_TREAT_VILLAGER_SPAWN_EGG = ITEMS.register(
            "trick_or_treat_villager_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.TRICK_OR_TREAT_VILLAGER, 0xFF8A00, 0x5B1A9E, new Item.Properties()));
    public static final RegistryObject<Item> WEREWOLF_SPAWN_EGG = ITEMS.register(
            "werewolf_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.WEREWOLF, 0x4A3526, 0xFFD23F, new Item.Properties()));
    public static final RegistryObject<Item> BIG_RANDY_SPAWN_EGG = ITEMS.register(
            "big_randy_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BIG_RANDY, 0xE8C547, 0xE87BB6, new Item.Properties()));
}
