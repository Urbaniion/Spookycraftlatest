package com.urbanion.spookycraft.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * A normal bed (you can sleep in it, it sets your spawn, villagers can use it) that is drawn
 * with a regular block model instead of the vanilla bed renderer, so it can have its own design.
 */
public class HalloweenBedBlock extends BedBlock {
    public HalloweenBedBlock(DyeColor color, Properties properties) {
        super(color, properties);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return null;
    }
}
