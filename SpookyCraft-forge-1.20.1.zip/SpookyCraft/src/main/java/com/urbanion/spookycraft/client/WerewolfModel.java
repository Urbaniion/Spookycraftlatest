package com.urbanion.spookycraft.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.urbanion.spookycraft.entity.Werewolf;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Fully custom werewolf model (generated together with its texture by tools/modelgen.py). */
public class WerewolfModel extends HierarchicalModel<Werewolf> {
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart chest;
    private final ModelPart head;
    private final ModelPart snout;
    private final ModelPart jaw;
    private final ModelPart ear_l;
    private final ModelPart ear_r;
    private final ModelPart arm_r;
    private final ModelPart forearm_r;
    private final ModelPart hand_r;
    private final ModelPart arm_l;
    private final ModelPart forearm_l;
    private final ModelPart hand_l;
    private final ModelPart tail;
    private final ModelPart tail_tip;
    private final ModelPart thigh_r;
    private final ModelPart shin_r;
    private final ModelPart foot_r;
    private final ModelPart thigh_l;
    private final ModelPart shin_l;
    private final ModelPart foot_l;
    private static final float HIPS_Y = 6.8F;

    public WerewolfModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.chest = body.getChild("chest");
        this.head = chest.getChild("head");
        this.snout = head.getChild("snout");
        this.jaw = head.getChild("jaw");
        this.ear_l = head.getChild("ear_l");
        this.ear_r = head.getChild("ear_r");
        this.arm_r = chest.getChild("arm_r");
        this.forearm_r = arm_r.getChild("forearm_r");
        this.hand_r = forearm_r.getChild("hand_r");
        this.arm_l = chest.getChild("arm_l");
        this.forearm_l = arm_l.getChild("forearm_l");
        this.hand_l = forearm_l.getChild("hand_l");
        this.tail = body.getChild("tail");
        this.tail_tip = tail.getChild("tail_tip");
        this.thigh_r = body.getChild("thigh_r");
        this.shin_r = thigh_r.getChild("shin_r");
        this.foot_r = shin_r.getChild("foot_r");
        this.thigh_l = body.getChild("thigh_l");
        this.shin_l = thigh_l.getChild("shin_l");
        this.foot_l = shin_l.getChild("foot_l");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create()
                .texOffs(0, 18).addBox(-5.0F, -8.0F, -3.0F, 10.0F, 8.0F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 6.8F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition chest = body.addOrReplaceChild("chest",
                CubeListBuilder.create()
                .texOffs(0, 0).addBox(-7.0F, -10.0F, -4.0F, 14.0F, 10.0F, 8.0F)
                .texOffs(0, 32).addBox(-6.0F, -13.0F, -3.5F, 12.0F, 4.0F, 7.0F),
                PartPose.offsetAndRotation(0.0F, -8.0F, 0.0F, 0.38F, 0.0F, 0.0F));
        PartDefinition head = chest.addOrReplaceChild("head",
                CubeListBuilder.create()
                .texOffs(68, 0).addBox(-4.0F, -7.0F, -5.0F, 8.0F, 7.0F, 8.0F),
                PartPose.offsetAndRotation(0.0F, -10.0F, -1.5F, -0.3F, 0.0F, 0.0F));
        PartDefinition snout = head.addOrReplaceChild("snout",
                CubeListBuilder.create()
                .texOffs(88, 32).addBox(-2.5F, -4.0F, -10.0F, 5.0F, 4.0F, 5.0F),
                PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition jaw = head.addOrReplaceChild("jaw",
                CubeListBuilder.create()
                .texOffs(0, 43).addBox(-2.0F, 0.0F, -5.0F, 4.0F, 1.5F, 5.0F),
                PartPose.offsetAndRotation(0.0F, -0.5F, -5.0F, 0.12F, 0.0F, 0.0F));
        PartDefinition ear_l = head.addOrReplaceChild("ear_l",
                CubeListBuilder.create()
                .texOffs(18, 43).addBox(1.5F, -10.5F, -2.0F, 2.5F, 3.5F, 1.5F),
                PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.15F));
        PartDefinition ear_r = head.addOrReplaceChild("ear_r",
                CubeListBuilder.create()
                .texOffs(18, 43).mirror().addBox(-4.0F, -10.5F, -2.0F, 2.5F, 3.5F, 1.5F).mirror(false),
                PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.15F));
        PartDefinition arm_r = chest.addOrReplaceChild("arm_r",
                CubeListBuilder.create()
                .texOffs(44, 0).addBox(-3.0F, -2.0F, -3.0F, 6.0F, 10.0F, 6.0F),
                PartPose.offsetAndRotation(-9.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.08F));
        PartDefinition forearm_r = arm_r.addOrReplaceChild("forearm_r",
                CubeListBuilder.create()
                .texOffs(32, 18).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 9.0F, 5.0F),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, -0.5F, 0.0F, 0.0F));
        PartDefinition hand_r = forearm_r.addOrReplaceChild("hand_r",
                CubeListBuilder.create()
                .texOffs(64, 32).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 4.0F, 6.0F)
                .texOffs(28, 43).addBox(-2.5F, 4.0F, -3.2F, 1.0F, 3.0F, 1.0F)
                .texOffs(28, 43).addBox(-0.5F, 4.0F, -3.2F, 1.0F, 3.0F, 1.0F)
                .texOffs(28, 43).addBox(1.5F, 4.0F, -3.2F, 1.0F, 3.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, 9.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition arm_l = chest.addOrReplaceChild("arm_l",
                CubeListBuilder.create()
                .texOffs(44, 0).mirror().addBox(-3.0F, -2.0F, -3.0F, 6.0F, 10.0F, 6.0F).mirror(false),
                PartPose.offsetAndRotation(9.0F, -8.0F, 0.0F, 0.0F, 0.0F, -0.08F));
        PartDefinition forearm_l = arm_l.addOrReplaceChild("forearm_l",
                CubeListBuilder.create()
                .texOffs(32, 18).mirror().addBox(-2.5F, 0.0F, -2.5F, 5.0F, 9.0F, 5.0F).mirror(false),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, -0.5F, 0.0F, 0.0F));
        PartDefinition hand_l = forearm_l.addOrReplaceChild("hand_l",
                CubeListBuilder.create()
                .texOffs(64, 32).mirror().addBox(-3.0F, 0.0F, -3.0F, 6.0F, 4.0F, 6.0F).mirror(false)
                .texOffs(28, 43).addBox(-2.5F, 4.0F, -3.2F, 1.0F, 3.0F, 1.0F)
                .texOffs(28, 43).addBox(-0.5F, 4.0F, -3.2F, 1.0F, 3.0F, 1.0F)
                .texOffs(28, 43).addBox(1.5F, 4.0F, -3.2F, 1.0F, 3.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, 9.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition tail = body.addOrReplaceChild("tail",
                CubeListBuilder.create()
                .texOffs(70, 18).addBox(-1.8F, -1.8F, 0.0F, 3.6F, 3.6F, 9.0F),
                PartPose.offsetAndRotation(0.0F, -1.5F, 3.0F, 0.5F, 0.0F, 0.0F));
        PartDefinition tail_tip = tail.addOrReplaceChild("tail_tip",
                CubeListBuilder.create()
                .texOffs(108, 32).addBox(-1.4F, -1.4F, 0.0F, 2.8F, 2.8F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 0.0F, 9.0F, -0.25F, 0.0F, 0.0F));
        PartDefinition thigh_r = body.addOrReplaceChild("thigh_r",
                CubeListBuilder.create()
                .texOffs(100, 0).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 9.0F, 6.0F),
                PartPose.offsetAndRotation(-3.6F, 0.0F, 0.0F, -0.55F, 0.0F, 0.0F));
        PartDefinition shin_r = thigh_r.addOrReplaceChild("shin_r",
                CubeListBuilder.create()
                .texOffs(52, 18).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 9.0F, 5.0F),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 1.0F, 0.0F, 0.0F));
        PartDefinition foot_r = shin_r.addOrReplaceChild("foot_r",
                CubeListBuilder.create()
                .texOffs(38, 32).addBox(-2.5F, 0.0F, -6.0F, 5.0F, 3.0F, 8.0F)
                .texOffs(28, 43).addBox(-2.5F, 1.0F, -7.0F, 1.0F, 2.0F, 1.0F)
                .texOffs(28, 43).addBox(-0.5F, 1.0F, -7.0F, 1.0F, 2.0F, 1.0F)
                .texOffs(28, 43).addBox(1.5F, 1.0F, -7.0F, 1.0F, 2.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, -0.55F, 0.0F, 0.0F));
        PartDefinition thigh_l = body.addOrReplaceChild("thigh_l",
                CubeListBuilder.create()
                .texOffs(100, 0).mirror().addBox(-2.5F, -1.0F, -3.0F, 5.0F, 9.0F, 6.0F).mirror(false),
                PartPose.offsetAndRotation(3.6F, 0.0F, 0.0F, -0.55F, 0.0F, 0.0F));
        PartDefinition shin_l = thigh_l.addOrReplaceChild("shin_l",
                CubeListBuilder.create()
                .texOffs(52, 18).mirror().addBox(-2.0F, -1.0F, -2.5F, 4.0F, 9.0F, 5.0F).mirror(false),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 1.0F, 0.0F, 0.0F));
        PartDefinition foot_l = shin_l.addOrReplaceChild("foot_l",
                CubeListBuilder.create()
                .texOffs(38, 32).mirror().addBox(-2.5F, 0.0F, -6.0F, 5.0F, 3.0F, 8.0F).mirror(false)
                .texOffs(28, 43).addBox(-2.5F, 1.0F, -7.0F, 1.0F, 2.0F, 1.0F)
                .texOffs(28, 43).addBox(-0.5F, 1.0F, -7.0F, 1.0F, 2.0F, 1.0F)
                .texOffs(28, 43).addBox(1.5F, 1.0F, -7.0F, 1.0F, 2.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, -0.55F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() {
        return root;
    }

    @Override
    public void setupAnim(Werewolf entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        root.getAllParts().forEach(ModelPart::resetPose);
        float s = limbSwing * 0.55F;
        float a = Math.min(1.0F, limbSwingAmount * 1.4F);
        float run = Mth.cos(s);

        // look direction
        head.yRot = Mth.clamp(netHeadYaw, -50.0F, 50.0F) * ((float) Math.PI / 180F) * 0.8F;
        head.xRot += headPitch * ((float) Math.PI / 180F) * 0.8F;

        // gallop: legs swing opposite, knees bend, body bobs
        thigh_r.xRot += run * 0.95F * a;
        thigh_l.xRot -= run * 0.95F * a;
        shin_r.xRot += Math.max(0.0F, -run) * 0.9F * a;
        shin_l.xRot += Math.max(0.0F, run) * 0.9F * a;
        foot_r.xRot -= Math.max(0.0F, -run) * 0.5F * a;
        foot_l.xRot -= Math.max(0.0F, run) * 0.5F * a;
        body.y = HIPS_Y - Math.abs(run) * 1.4F * a;
        body.xRot += 0.08F * a;
        chest.yRot = run * 0.12F * a;
        chest.xRot += Mth.sin(ageInTicks * 0.08F) * 0.025F;

        // arms
        if (entity.isAggressive()) {
            float swing = Mth.sin(entity.getAttackAnim(0.0F) * (float) Math.PI);
            arm_r.xRot = -1.35F - swing * 0.9F + run * 0.15F * a;
            arm_l.xRot = -1.35F - swing * 0.9F - run * 0.15F * a;
            arm_r.zRot = 0.18F;
            arm_l.zRot = -0.18F;
            forearm_r.xRot = -0.25F;
            forearm_l.xRot = -0.25F;
            jaw.xRot = 0.55F + Mth.sin(ageInTicks * 0.6F) * 0.06F;
        } else {
            arm_r.xRot += -run * 0.8F * a;
            arm_l.xRot += run * 0.8F * a;
            jaw.xRot = 0.1F + Mth.sin(ageInTicks * 0.1F) * 0.02F;
        }

        // ears twitch, tail wags
        ear_l.zRot += Mth.sin(ageInTicks * 0.13F) * 0.05F;
        ear_r.zRot -= Mth.sin(ageInTicks * 0.11F) * 0.05F;
        tail.yRot = Mth.sin(ageInTicks * 0.1F) * 0.12F + Mth.cos(s) * 0.3F * a;
        tail_tip.yRot = Mth.sin(ageInTicks * 0.1F - 0.8F) * 0.25F;
    }
}
